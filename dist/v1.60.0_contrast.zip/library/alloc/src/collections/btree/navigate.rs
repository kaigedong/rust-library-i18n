use core::borrow::Borrow;
use core::hint;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

// `front` and `back` are always both `None` or both `Some`. <br>`front` 和 `back` 始终都是 `None` 或都是 `Some`。<br>
pub struct LeafRange<BorrowType, K, V> {
    front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<'a, K: 'a, V: 'a> Clone for LeafRange<marker::Immut<'a>, K, V> {
    fn clone(&self) -> Self {
        LeafRange { front: self.front.clone(), back: self.back.clone() }
    }
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Temporarily takes out another, immutable equivalent of the same range. <br>暂时取出另一个相同范围的不可变值。<br>
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<'a, K, V> LeafRange<marker::Immut<'a>, K, V> {
    #[inline]
    pub fn next_checked(&mut self) -> Option<(&'a K, &'a V)> {
        self.perform_next_checked(|kv| kv.into_kv())
    }

    #[inline]
    pub fn next_back_checked(&mut self) -> Option<(&'a K, &'a V)> {
        self.perform_next_back_checked(|kv| kv.into_kv())
    }
}

impl<'a, K, V> LeafRange<marker::ValMut<'a>, K, V> {
    #[inline]
    pub fn next_checked(&mut self) -> Option<(&'a K, &'a mut V)> {
        self.perform_next_checked(|kv| unsafe { ptr::read(kv) }.into_kv_valmut())
    }

    #[inline]
    pub fn next_back_checked(&mut self) -> Option<(&'a K, &'a mut V)> {
        self.perform_next_back_checked(|kv| unsafe { ptr::read(kv) }.into_kv_valmut())
    }
}

impl<BorrowType: marker::BorrowType, K, V> LeafRange<BorrowType, K, V> {
    /// If possible, extract some result from the following KV and move to the edge beyond it. <br>如果可能，从下面的 KV 中提取一些结果并移动到超出它的 edge。<br>
    fn perform_next_checked<F, R>(&mut self, f: F) -> Option<R>
    where
        F: Fn(&Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>) -> R,
    {
        if self.is_empty() {
            None
        } else {
            super::mem::replace(self.front.as_mut().unwrap(), |front| {
                let kv = front.next_kv().ok().unwrap();
                let result = f(&kv);
                (kv.next_leaf_edge(), Some(result))
            })
        }
    }

    /// If possible, extract some result from the preceding KV and move to the edge beyond it. <br>如果可能，从前面的 KV 中提取一些结果并移动到超出它的 edge。<br>
    fn perform_next_back_checked<F, R>(&mut self, f: F) -> Option<R>
    where
        F: Fn(&Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>) -> R,
    {
        if self.is_empty() {
            None
        } else {
            super::mem::replace(self.back.as_mut().unwrap(), |back| {
                let kv = back.next_back_kv().ok().unwrap();
                let result = f(&kv);
                (kv.next_back_leaf_edge(), Some(result))
            })
        }
    }
}

enum LazyLeafHandle<BorrowType, K, V> {
    Root(NodeRef<BorrowType, K, V, marker::LeafOrInternal>), // not yet descended <br>还没有下降<br>
    Edge(Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>),
}

impl<'a, K: 'a, V: 'a> Clone for LazyLeafHandle<marker::Immut<'a>, K, V> {
    fn clone(&self) -> Self {
        match self {
            LazyLeafHandle::Root(root) => LazyLeafHandle::Root(*root),
            LazyLeafHandle::Edge(edge) => LazyLeafHandle::Edge(*edge),
        }
    }
}

impl<BorrowType, K, V> LazyLeafHandle<BorrowType, K, V> {
    fn reborrow(&self) -> LazyLeafHandle<marker::Immut<'_>, K, V> {
        match self {
            LazyLeafHandle::Root(root) => LazyLeafHandle::Root(root.reborrow()),
            LazyLeafHandle::Edge(edge) => LazyLeafHandle::Edge(edge.reborrow()),
        }
    }
}

// `front` and `back` are always both `None` or both `Some`. <br>`front` 和 `back` 始终都是 `None` 或都是 `Some`。<br>
pub struct LazyLeafRange<BorrowType, K, V> {
    front: Option<LazyLeafHandle<BorrowType, K, V>>,
    back: Option<LazyLeafHandle<BorrowType, K, V>>,
}

impl<'a, K: 'a, V: 'a> Clone for LazyLeafRange<marker::Immut<'a>, K, V> {
    fn clone(&self) -> Self {
        LazyLeafRange { front: self.front.clone(), back: self.back.clone() }
    }
}

impl<BorrowType, K, V> LazyLeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LazyLeafRange { front: None, back: None }
    }

    /// Temporarily takes out another, immutable equivalent of the same range. <br>暂时取出另一个相同范围的不可变值。<br>
    pub fn reborrow(&self) -> LazyLeafRange<marker::Immut<'_>, K, V> {
        LazyLeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<'a, K, V> LazyLeafRange<marker::Immut<'a>, K, V> {
    #[inline]
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.init_front().unwrap().next_unchecked() }
    }

    #[inline]
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.init_back().unwrap().next_back_unchecked() }
    }
}

impl<'a, K, V> LazyLeafRange<marker::ValMut<'a>, K, V> {
    #[inline]
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.init_front().unwrap().next_unchecked() }
    }

    #[inline]
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.init_back().unwrap().next_back_unchecked() }
    }
}

impl<K, V> LazyLeafRange<marker::Dying, K, V> {
    fn take_front(
        &mut self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>> {
        match self.front.take()? {
            LazyLeafHandle::Root(root) => Some(root.first_leaf_edge()),
            LazyLeafHandle::Edge(edge) => Some(edge),
        }
    }

    #[inline]
    pub unsafe fn deallocating_next_unchecked(
        &mut self,
    ) -> Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV> {
        debug_assert!(self.front.is_some());
        let front = self.init_front().unwrap();
        unsafe { front.deallocating_next_unchecked() }
    }

    #[inline]
    pub unsafe fn deallocating_next_back_unchecked(
        &mut self,
    ) -> Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV> {
        debug_assert!(self.back.is_some());
        let back = self.init_back().unwrap();
        unsafe { back.deallocating_next_back_unchecked() }
    }

    #[inline]
    pub fn deallocating_end(&mut self) {
        if let Some(front) = self.take_front() {
            front.deallocating_end()
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> LazyLeafRange<BorrowType, K, V> {
    fn init_front(
        &mut self,
    ) -> Option<&mut Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>> {
        if let Some(LazyLeafHandle::Root(root)) = &self.front {
            self.front = Some(LazyLeafHandle::Edge(unsafe { ptr::read(root) }.first_leaf_edge()));
        }
        match &mut self.front {
            None => None,
            Some(LazyLeafHandle::Edge(edge)) => Some(edge),
            // SAFETY: the code above would have replaced it. <br>上面的代码将取代它。<br>
            Some(LazyLeafHandle::Root(_)) => unsafe { hint::unreachable_unchecked() },
        }
    }

    fn init_back(
        &mut self,
    ) -> Option<&mut Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>> {
        if let Some(LazyLeafHandle::Root(root)) = &self.back {
            self.back = Some(LazyLeafHandle::Edge(unsafe { ptr::read(root) }.last_leaf_edge()));
        }
        match &mut self.back {
            None => None,
            Some(LazyLeafHandle::Edge(edge)) => Some(edge),
            // SAFETY: the code above would have replaced it. <br>上面的代码将取代它。<br>
            Some(LazyLeafHandle::Root(_)) => unsafe { hint::unreachable_unchecked() },
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Finds the distinct leaf edges delimiting a specified range in a tree. <br>查找限定树中指定范围的不同叶 edges。<br>
    ///
    /// If such distinct edges exist, returns them in ascending order, meaning that a non-zero number of calls to `next_unchecked` on the `front` of the result and/or calls to `next_back_unchecked` on the `back` of the result will eventually reach the same edge. <br>如果存在这种不同的 edges，则按升序返回它们，这意味着在结果的 `front` 上对 `next_unchecked` 的非零调用次数或者对结果的 `back` 上的 `next_back_unchecked` 调用最终将达到相同的 edge。<br>
    ///
    ///
    /// If there are no such edges, i.e., if the tree contains no key within the range, returns an empty `front` and `back`. <br>如果没有这样的 edges，即，如果树不包含范围内的键，则返回空的 `front` 和 `back`。<br>
    ///
    /// # Safety
    /// Unless `BorrowType` is `Immut`, do not use the handles to visit the same KV twice. <br>除非 `BorrowType` 是 `Immut`，否则不要使用句柄两次访问同一个 KV。<br>
    ///
    ///
    ///
    ///
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LazyLeafRange<BorrowType, K, V> {
    LazyLeafRange {
        front: Some(LazyLeafHandle::Root(root1)),
        back: Some(LazyLeafHandle::Root(root2)),
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Finds the pair of leaf edges delimiting a specific range in a tree. <br>查找在树中划定特定范围的一对叶子 edges。<br>
    ///
    /// The result is meaningful only if the tree is ordered by key, like the tree in a `BTreeMap` is. <br>仅当按键对树进行排序 (如 `BTreeMap` 中的树) 时，结果才有意义。<br>
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SAFETY: our borrow type is immutable. <br>我们的借用类型是不可变。<br>
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Finds the pair of leaf edges delimiting an entire tree. <br>查找界定整个树的一对叶子 edges。<br>
    pub fn full_range(self) -> LazyLeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Splits a unique reference into a pair of leaf edges delimiting a specified range. <br>将一个唯一的 quot 拆分为一对指定范围的叶子 edges。<br>
    /// The result are non-unique references allowing (some) mutation, which must be used carefully. <br>结果是非唯一引用，允许 (some) 可变的，必须谨慎使用。<br>
    ///
    /// The result is meaningful only if the tree is ordered by key, like the tree in a `BTreeMap` is. <br>仅当按键对树进行排序 (如 `BTreeMap` 中的树) 时，结果才有意义。<br>
    ///
    ///
    /// # Safety
    /// Do not use the duplicate handles to visit the same KV twice. <br>请勿使用重复的句柄访问同一 KV 两次。<br>
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Splits a unique reference into a pair of leaf edges delimiting the full range of the tree. <br>将唯一的 quot 拆分为一对叶子 edges，它们界定了树的整个范围。<br>
    /// The results are non-unique references allowing mutation (of values only), so must be used with care. <br>结果是非唯一引用，允许可变的 (仅值)，因此必须小心使用。<br>
    ///
    pub fn full_range(self) -> LazyLeafRange<marker::ValMut<'a>, K, V> {
        // We duplicate the root NodeRef here -- we will never visit the same KV twice, and never end up with overlapping value references. <br>我们在这里复制根 NodeRef - 我们将永远不会访问同一 KV 两次，也永远不会出现重叠的引用值。<br>
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Splits a unique reference into a pair of leaf edges delimiting the full range of the tree. <br>将唯一的 quot 拆分为一对叶子 edges，它们界定了树的整个范围。<br>
    /// The results are non-unique references allowing massively destructive mutation, so must be used with the utmost care. <br>结果是非唯一引用，允许大规模破坏性可变的，因此必须格外小心使用。<br>
    ///
    pub fn full_range(self) -> LazyLeafRange<marker::Dying, K, V> {
        // We duplicate the root NodeRef here -- we will never access it in a way that overlaps references obtained from the root. <br>我们在这里复制根 NodeRef - 我们将永远不会以与从根获得的引用重叠的方式访问它。<br>
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Given a leaf edge handle, returns [`Result::Ok`] with a handle to the neighboring KV on the right side, which is either in the same leaf node or in an ancestor node. <br>给定叶子 edge 句柄，将 [`Result::Ok`] 及其句柄返回到右侧的相邻 KV，该相邻 KV 在同一叶子节点中或在祖先节点中。<br>
    ///
    /// If the leaf edge is the last one in the tree, returns [`Result::Err`] with the root node. <br>如果叶子 edge 是树中的最后一个叶子，则返回带有根节点的 [`Result::Err`]。<br>
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Given a leaf edge handle, returns [`Result::Ok`] with a handle to the neighboring KV on the left side, which is either in the same leaf node or in an ancestor node. <br>给定叶子 edge 句柄，将 [`Result::Ok`] 及其句柄返回到左侧的相邻 KV，该相邻 KV 在同一叶子节点中或在祖先节点中。<br>
    ///
    /// If the leaf edge is the first one in the tree, returns [`Result::Err`] with the root node. <br>如果叶子 edge 是树中的第一个叶子，则返回带有根节点的 [`Result::Err`]。<br>
    fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Given an internal edge handle, returns [`Result::Ok`] with a handle to the neighboring KV on the right side, which is either in the same internal node or in an ancestor node. <br>给定内部 edge 句柄，将 [`Result::Ok`] 及其句柄返回到右侧的相邻 KV，该相邻 KV 在同一内部节点中或在祖先节点中。<br>
    ///
    /// If the internal edge is the last one in the tree, returns [`Result::Err`] with the root node. <br>如果内部 edge 是树中的最后一个，则返回带有根节点的 [`Result::Err`]。<br>
    fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Given a leaf edge handle into a dying tree, returns the next leaf edge on the right side, and the key-value pair in between, if they exist. <br>给定 dying 树的叶子 edge 句柄，返回右侧的下一个叶子 edge，以及中间的键值对 (如果它们存在)。<br>
    ///
    ///
    /// If the given edge is the last one in a leaf, this method deallocates the leaf, as well as any ancestor nodes whose last edge was reached. <br>如果给定的 edge 是叶子中的最后一个，则此方法将释放叶子以及到达最后一个 edge 的所有祖先节点。<br>
    /// This implies that if no more key-value pair follows, the entire tree will have been deallocated and there is nothing left to return. <br>这意味着如果没有更多的键值对跟随，整个树将被释放并且没有任何东西可以返回。<br>
    ///
    /// # Safety
    /// - The given edge must not have been previously returned by counterpart `deallocating_next_back`. <br>给定的 edge 一定不是先前由对方 `deallocating_next_back` 返回的。<br>
    /// - The returned KV handle is only valid to access the key and value, and only valid until the next call to a `deallocating_` method. <br>返回的 KV 句柄仅对访问键和值有效，并且仅在下一次调用 `deallocating_` 方法之前有效。<br>
    ///
    ///
    ///
    ///
    unsafe fn deallocating_next(
        self,
    ) -> Option<(Self, Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV>)>
    {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Some((unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)),
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Given a leaf edge handle into a dying tree, returns the next leaf edge on the left side, and the key-value pair in between, if they exist. <br>给定 dying 树的叶子 edge 句柄，返回左侧的下一个叶子 edge，以及中间的键值对 (如果它们存在)。<br>
    ///
    /// If the given edge is the first one in a leaf, this method deallocates the leaf, as well as any ancestor nodes whose first edge was reached. <br>如果给定的 edge 是叶子中的第一个，则此方法释放叶子节点，以及到达第一个 edge 的任何祖先节点。<br>
    ///
    /// This implies that if no more key-value pair follows, the entire tree will have been deallocated and there is nothing left to return. <br>这意味着如果没有更多的键值对跟随，整个树将被释放并且没有任何东西可以返回。<br>
    ///
    /// # Safety
    /// - The given edge must not have been previously returned by counterpart `deallocating_next`. <br>给定的 edge 一定不是先前由对方 `deallocating_next` 返回的。<br>
    /// - The returned KV handle is only valid to access the key and value, and only valid until the next call to a `deallocating_` method. <br>返回的 KV 句柄仅对访问键和值有效，并且仅在下一次调用 `deallocating_` 方法之前有效。<br>
    ///
    ///
    ///
    ///
    unsafe fn deallocating_next_back(
        self,
    ) -> Option<(Self, Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV>)>
    {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Some((unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)),
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates a pile of nodes from the leaf up to the root. <br>释放从叶子到根的一堆节点。<br>
    /// This is the only way to deallocate the remainder of a tree after `deallocating_next` and `deallocating_next_back` have been nibbling at both sides of the tree, and have hit the same edge. <br>这是在 `deallocating_next` 和 `deallocating_next_back` 一直在树的两边蚕食并且击中了相同的 edge 之后，重新分配树的其余部分的唯一方法。<br>
    /// As it is intended only to be called when all keys and values have been returned, no cleanup is done on any of the keys or values. <br>由于仅在返回所有键和值后才调用它，因此不会对任何键或值进行清理。<br>
    ///
    ///
    ///
    fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Moves the leaf edge handle to the next leaf edge and returns references to the key and value in between. <br>将叶子 edge 句柄移动到下一个叶子 edge，并在其中的键和值之间返回引用。<br>
    ///
    ///
    /// # Safety
    /// There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv().ok().unwrap();
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Moves the leaf edge handle to the previous leaf edge and returns references to the key and value in between. <br>将叶子 edge 句柄移动到上一个叶子 edge，并在其中的键和值返回 quot。<br>
    ///
    ///
    /// # Safety
    /// There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv().ok().unwrap();
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Moves the leaf edge handle to the next leaf edge and returns references to the key and value in between. <br>将叶子 edge 句柄移动到下一个叶子 edge，并在其中的键和值之间返回引用。<br>
    ///
    ///
    /// # Safety
    /// There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv().ok().unwrap();
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Doing this last is faster, according to benchmarks. <br>根据基准测试，这样做的最后速度更快。<br>
        kv.into_kv_valmut()
    }

    /// Moves the leaf edge handle to the previous leaf and returns references to the key and value in between. <br>将叶子 edge 句柄移动到上一个叶子，并在其中的键和值之间返回 quot。<br>
    ///
    ///
    /// # Safety
    /// There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv().ok().unwrap();
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Doing this last is faster, according to benchmarks. <br>根据基准测试，这样做的最后速度更快。<br>
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Moves the leaf edge handle to the next leaf edge and returns the key and value in between, deallocating any node left behind while leaving the corresponding edge in its parent node dangling. <br>将叶子 edge 句柄移动到下一个叶子 edge，并返回它们之间的键和值，重新分配留下的任何节点，同时将对应的 edge 保留在其父子节点中。<br>
    ///
    ///
    /// # Safety
    /// - There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    /// - That KV was not previously returned by counterpart `deallocating_next_back_unchecked` on any copy of the handles being used to traverse the tree. <br>该 KV 之前没有由对应的 `deallocating_next_back_unchecked` 在用于遍历树的句柄的任何副本上返回。<br>
    ///
    /// The only safe way to proceed with the updated handle is to compare it, drop it, or call this method or counterpart `deallocating_next_back_unchecked` again. <br>处理更新后的句柄的唯一安全方法是比较它，丢弃它，或再次调用此方法或对应的 `deallocating_next_back_unchecked`。<br>
    ///
    ///
    ///
    ///
    unsafe fn deallocating_next_unchecked(
        &mut self,
    ) -> Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV> {
        super::mem::replace(self, |leaf_edge| unsafe { leaf_edge.deallocating_next().unwrap() })
    }

    /// Moves the leaf edge handle to the previous leaf edge and returns the key and value in between, deallocating any node left behind while leaving the corresponding edge in its parent node dangling. <br>将叶子 edge 句柄移动到上一个叶子 edge，并返回它们之间的键和值，重新分配留下的任何节点，同时将对应的 edge 保留在其父子节点中。<br>
    ///
    ///
    /// # Safety
    /// - There must be another KV in the direction travelled. <br>在行进方向上必须有另一个 KV。<br>
    /// - That leaf edge was not previously returned by counterpart `deallocating_next_unchecked` on any copy of the handles being used to traverse the tree. <br>该叶子 edge 之前没有由对应的 `deallocating_next_unchecked` 在用于遍历树的句柄的任何副本上返回。<br>
    ///
    /// The only safe way to proceed with the updated handle is to compare it, drop it, or call this method or counterpart `deallocating_next_unchecked` again. <br>处理更新后的句柄的唯一安全方法是比较它，丢弃它，或再次调用此方法或对应的 `deallocating_next_unchecked`。<br>
    ///
    ///
    ///
    ///
    unsafe fn deallocating_next_back_unchecked(
        &mut self,
    ) -> Handle<NodeRef<marker::Dying, K, V, marker::LeafOrInternal>, marker::KV> {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Returns the leftmost leaf edge in or underneath a node - in other words, the edge you need first when navigating forward (or last when navigating backward). <br>返回节点内或节点下最左边的叶子 edge - 换句话说，向前导航时需要首先使用的 edge (向后导航时则需要最后的 edge)。<br>
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Returns the rightmost leaf edge in or underneath a node - in other words, the edge you need last when navigating forward (or first when navigating backward). <br>返回节点内或节点下最右边的叶子 edge - 换句话说，向前导航时需要最后一个 edge (向后导航时需要第一个 edge)。<br>
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visits leaf nodes and internal KVs in order of ascending keys, and also visits internal nodes as a whole in a depth first order, meaning that internal nodes precede their individual KVs and their child nodes. <br>按键升序访问叶子节点和内部 KV，还按深度优先顺序访问整个内部节点，这意味着内部节点先于其各个 KV 和其子节点。<br>
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calculates the number of elements in a (sub)tree. <br>计算 (子) 树中的元素数。<br>
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Returns the leaf edge closest to a KV for forward navigation. <br>返回最接近 KV 的叶子 edge，以进行前向导航。<br>
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Returns the leaf edge closest to a KV for backward navigation. <br>返回最接近 KV 的叶子 edge，以进行向后导航。<br>
    fn next_back_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}
