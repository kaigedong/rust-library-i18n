use super::super::super::windows::*;
use super::mystd::os::windows::prelude::*;
use super::{coff, mmap, Library, LibrarySegment, OsString};
use alloc::vec;
use alloc::vec::Vec;
use core::mem;
use core::mem::MaybeUninit;

// For loading native libraries on Windows, see some discussion on rust-lang/rust#71060 for the various strategies here. <br>要在 Windows 上加载原生库，请参见 rust-lang/rust#71060 上有关各种策略的一些讨论。<br>
//
pub(super) fn native_libraries() -> Vec<Library> {
    let mut ret = Vec::new();
    unsafe {
        add_loaded_images(&mut ret);
    }
    return ret;
}

unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
    let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
    if snap == INVALID_HANDLE_VALUE {
        return;
    }

    let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
    me.dwSize = mem::size_of_val(&me) as DWORD;
    if Module32FirstW(snap, &mut me) == TRUE {
        loop {
            if let Some(lib) = load_library(&me) {
                ret.push(lib);
            }

            if Module32NextW(snap, &mut me) != TRUE {
                break;
            }
        }
    }

    CloseHandle(snap);
}

unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
    let pos = me
        .szExePath
        .iter()
        .position(|i| *i == 0)
        .unwrap_or(me.szExePath.len());
    let name = OsString::from_wide(&me.szExePath[..pos]);

    // MinGW libraries currently don't support ASLR (rust-lang/rust#16514), but DLLs can still be relocated around in the address space. <br>MinGW 库当前不支持 ASLR (rust-lang/rust#16514)，但是 DLL 仍可以在地址空间中重新定位。<br>
    // It appears that addresses in debug info are all as-if this library was loaded at its "image base", which is a field in its COFF file headers. <br>如果该库是在其 "image base" 处加载的，则调试信息中的地址似乎全部都作为该库的 COFF 文件头中的一个字段。<br>
    // Since this is what debuginfo seems to list we parse the symbol table and store addresses as if the library was loaded at "image base" as well. <br>由于这是 debuginfo 似乎列出的内容，因此我们解析符号表并存储地址，就像该库也已在 "image base" 上加载一样。<br>
    //
    // The library may not be loaded at "image base", however. <br>但是，该库可能未在 "image base" 上加载。<br>
    // (presumably something else may be loaded there?) This is where the `bias` field comes into play, and we need to figure out the value of `bias` here. <br>(可能在那里加载了其他内容？) 这是 `bias` 字段起作用的地方，我们需要在这里计算 `bias` 的值。<br> Unfortunately though it's not clear how to acquire this from a loaded module. <br>不幸的是，尽管目前尚不清楚如何从已加载的模块中获取此信息。<br>
    // What we do have, however, is the actual load address (`modBaseAddr`). <br>但是，我们要做的是实际的加载地址 (`modBaseAddr`)。<br>
    //
    // As a bit of a cop-out for now we mmap the file, read the file header information, then drop the mmap. <br>现在，作为一点补偿，我们对文件进行 mmap，读取文件头信息，然后丢弃 mmap。<br> This is wasteful because we'll probably reopen the mmap later, but this should work well enough for now. <br>这很浪费，因为我们稍后可能会重新打开 mmap，但这现在应该可以正常工作了。<br>
    //
    // Once we have the `image_base` (desired load location) and the `base_addr` (actual load location) we can fill in the `bias` (difference between the actual and desired) and then the stated address of each segment is the `image_base` since that's what the file says. <br>一旦有了 `image_base` (所需的加载位置) 和 `base_addr` (实际的加载位置)，我们就可以填写 `bias` (实际值与期望值之差)，然后每个段的指定地址就是 `image_base`，因为这就是文件所说的。<br>
    //
    //
    // For now it appears that unlike ELF/MachO we can make do with one segment per library, using `modBaseSize` as the whole size. <br>现在看来，与 ELF/MachO 不同，我们可以使用 `modBaseSize` 作为整个大小来处理每个库一个段。<br>
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    let mmap = mmap(name.as_ref())?;
    let image_base = coff::get_image_base(&mmap)?;
    let base_addr = me.modBaseAddr as usize;
    Some(Library {
        name,
        bias: base_addr.wrapping_sub(image_base),
        segments: vec![LibrarySegment {
            stated_virtual_memory_address: image_base,
            len: me.modBaseSize as usize,
        }],
    })
}
