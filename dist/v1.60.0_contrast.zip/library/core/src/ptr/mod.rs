//! Manually manage memory through raw pointers. <br>通过裸指针手动管理内存。<br>
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Many functions in this module take raw pointers as arguments and read from or write to them. <br>该模块中的许多函数都将裸指针作为参数，并对其进行读取或写入。<br> For this to be safe, these pointers must be *valid*. <br>为了安全起见，这些指针必须是 *valid*。<br>
//! Whether a pointer is valid depends on the operation it is used for (read or write), and the extent of the memory that is accessed (i.e., how many bytes are read/written). <br>指针是否有效取决于指针用于 (读或写) 的操作以及所访问的内存范围 (即 read/written 多少个字节)。<br>
//! Most functions use `*mut T` and `*const T` to access only a single value, in which case the documentation omits the size and implicitly assumes it to be `size_of::<T>()` bytes. <br>大多数函数使用 `*mut T` 和 `*const T` 来访问单个值，在这种情况下，文档将忽略该大小，并隐式地假定其为 `size_of::<T>()` 字节。<br>
//!
//! The precise rules for validity are not determined yet. <br>有效性的确切规则尚未确定。<br> The guarantees that are provided at this point are very minimal: <br>此时提供的保证非常小：<br>
//!
//! * A [null] pointer is *never* valid, not even for accesses of [size zero][zst]. <br>[null] 指针从来都是无效的，甚至对于 [大小为零][zst] 的访问也是无效的。<br>
//! * For a pointer to be valid, it is necessary, but not always sufficient, that the pointer be *dereferenceable*: the memory range of the given size starting at the pointer must all be within the bounds of a single allocated object. <br>为了使指针有效，有必要 (但并不总是足够) 使指针 *可引用*: 从指针开始的给定大小的内存范围必须全部在单个已分配对象的范围内。<br>
//! Note that in Rust, every (stack-allocated) variable is considered a separate allocated object. <br>请注意，在 Rust 中，每个 (stack-allocated) 变量都被视为一个单独的分配对象。<br>
//! * Even for operations of [size zero][zst], the pointer must not be pointing to deallocated memory, i.e., deallocation makes pointers invalid even for zero-sized operations. <br>即使对于 [大小为零][zst] 的操作，指针也不得指向已释放的内存，即，即使对于大小为零的操作，释放也会使指针无效。<br>
//! However, casting any non-zero integer *literal* to a pointer is valid for zero-sized accesses, even if some memory happens to exist at that address and gets deallocated. <br>但是，将任何非零整数 *字面量* 强制转换为指针对于零大小的访问都是有效的，即使该地址恰好存在一些内存并被释放了。<br>
//! This corresponds to writing your own allocator: allocating zero-sized objects is not very hard. <br>这相当于编写自己的分配器：分配零大小的对象不是很困难。<br>
//! The canonical way to obtain a pointer that is valid for zero-sized accesses is [`NonNull::dangling`]. <br>获得对零大小访问有效的指针的规范方法是 [`NonNull::dangling`]。<br>
//! * All accesses performed by functions in this module are *non-atomic* in the sense of [atomic operations] used to synchronize between threads. <br>在用于在线程之间同步的 [原子操作][atomic operations] 的意义上，此模块中的函数执行的所有访问都是非原子的。<br>
//! This means it is undefined behavior to perform two concurrent accesses to the same location from different threads unless both accesses only read from memory. <br>这意味着从两个不同的线程对同一位置执行两次并发访问是一种未定义的行为，除非两个访问均仅从内存中读取。<br>
//! Notice that this explicitly includes [`read_volatile`] and [`write_volatile`]: Volatile accesses cannot be used for inter-thread synchronization. <br>请注意，这明确包含 [`read_volatile`] 和 [`write_volatile`]: 易失性访问不能用于线程间同步。<br>
//! * The result of casting a reference to a pointer is valid for as long as the underlying object is live and no reference (just raw pointers) is used to access the same memory. <br>只要底层对象处于活动状态，并且不使用引用 (仅仅是裸指针) 来访问同一内存，则转换对指针的引用的结果就是有效的。<br>
//!
//! These axioms, along with careful use of [`offset`] for pointer arithmetic, are enough to correctly implement many useful things in unsafe code. <br>这些公理，以及仔细地使用 [`offset`] 进行指针运算，足以在不安全的代码中正确实现许多有用的东西。<br> Stronger guarantees will be provided eventually, as the [aliasing] rules are being determined. <br>随着 [aliasing] 规则的确定，最终将提供更强有力的保证。<br>
//! For more information, see the [book] as well as the section in the reference devoted to [undefined behavior][ub]. <br>有关更多信息，请参见 [书籍][book] 以及专门针对 [未定义的行为][ub] 的引用中的部分。<br>
//!
//! ## Alignment
//!
//! Valid raw pointers as defined above are not necessarily properly aligned (where "proper" alignment is defined by the pointee type, i.e., `*const T` must be aligned to `mem::align_of::<T>()`). <br>上面定义的有效裸指针不一定正确对齐 (其中 "proper" 对齐由 pointee 类型定义，即 `*const T` 必须与 `mem::align_of::<T>()` 对齐)。<br>
//! However, most functions require their arguments to be properly aligned, and will explicitly state this requirement in their documentation. <br>但是，大多数函数要求其参数正确对齐，并将在其文档中明确说明此要求。<br>
//! Notable exceptions to this are [`read_unaligned`] and [`write_unaligned`]. <br>[`read_unaligned`] 和 [`write_unaligned`] 除外。<br>
//!
//! When a function requires proper alignment, it does so even if the access has size 0, i.e., even if memory is not actually touched. <br>当一个函数需要适当的对齐时，即使访问的大小为 0，即实际上没有触摸到内存，它也需要进行适当的对齐。<br> Consider using [`NonNull::dangling`] in such cases. <br>在这种情况下，请考虑使用 [`NonNull::dangling`]。<br>
//!
//! ## Allocated object <br>分配对象<br>
//!
//! For several operations, such as [`offset`] or field projections (`expr.field`), the notion of an "allocated object" becomes relevant. <br>对于一些操作，例如 [`offset`] 或 projection (`expr.field`)，"allocated object" 的概念变得相关。<br> An allocated object is a contiguous region of memory. <br>分配的对象是一个连续的内存区域。<br>
//! Common examples of allocated objects include stack-allocated variables (each variable is a separate allocated object), heap allocations (each allocation created by the global allocator is a separate allocated object), and `static` variables. <br>分配对象的常见示例包括栈分配变量 (每个变量都是一个单独的分配对象)、堆分配 (每个分配器创建的分配都是一个单独的分配对象) 和 `static` 变量。<br>
//!
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

mod metadata;
pub(crate) use metadata::PtrRepr;
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executes the destructor (if any) of the pointed-to value. <br>执行指向值的析构函数 (如果有)。<br>
///
/// This is semantically equivalent to calling [`ptr::read`] and discarding the result, but has the following advantages: <br>从语义上讲，这等效于调用 [`ptr::read`] 并丢弃结果，但是具有以下优点：<br>
///
/// * It is *required* to use `drop_in_place` to drop unsized types like trait objects, because they can't be read out onto the stack and dropped normally. <br>强制要求使用 `drop_in_place` 丢弃未定义大小的类型 (例如 trait 对象)，因为它们无法被读取到栈上并且无法正常丢弃。<br>
///
/// * It is friendlier to the optimizer to do this over [`ptr::read`] when dropping manually allocated memory (e.g., in the implementations of `Box`/`Rc`/`Vec`), as the compiler doesn't need to prove that it's sound to elide the copy. <br>当丢弃手动分配的内存时 (例如，在 `Box`/`Rc`/`Vec` 的实现中)，通过 [`ptr::read`] 进行此操作对优化器来说更友好，因为编译器不需要证明丢弃副本是合理的。<br>
///
///
/// * It can be used to drop [pinned] data when `T` is not `repr(packed)` (pinned data must not be moved before it is dropped). <br>当 `T` 不是 `repr(packed)` 时，可用于丢弃 [固定][pinned] 数据 (在丢弃固定的数据之前，不得移动固定的数据)。<br>
///
/// Unaligned values cannot be dropped in place, they must be copied to an aligned location first using [`ptr::read_unaligned`]. <br>未对齐的值不能被直接丢弃，必须先使用 [`ptr::read_unaligned`] 将它们复制到对齐的位置。<br> For packed structs, this move is done automatically by the compiler. <br>对于包装的结构体，此移动由编译器自动完成。<br>
/// This means the fields of packed structs are not dropped in-place. <br>这意味着已打包结构的字段不会被原地丢弃。<br>
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `to_drop` must be [valid] for both reads and writes. <br>对于读取和写入，`to_drop` 必须是 [有效][valid]。<br>
///
/// * `to_drop` must be properly aligned. <br>`to_drop` 必须正确对齐。<br>
///
/// * The value `to_drop` points to must be valid for dropping, which may mean it must uphold additional invariants - this is type-dependent. <br>`to_drop` 指向的值必须对丢弃有效，这可能意味着它必须支持其他不变量 - 这与类型有关。<br>
///
/// Additionally, if `T` is not [`Copy`], using the pointed-to value after calling `drop_in_place` can cause undefined behavior. <br>此外，如果 `T` 不是 [`Copy`]，则在调用 `drop_in_place` 之后使用指向的值可能会导致未定义的行为。<br> Note that `*to_drop = foo` counts as a use because it will cause the value to be dropped again. <br>请注意，`*to_drop = foo` 被视为使用，因为它将导致该值再次被丢弃。<br>
/// [`write()`] can be used to overwrite data without causing it to be dropped. <br>[`write()`] 可用于覆盖数据，而不会导致数据被丢弃。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Manually remove the last item from a vector: <br>从 vector 手动删除最后一个项：<br>
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Get a raw pointer to the last element in `v`. <br>获取指向 `v` 中最后一个元素的裸指针。<br>
///     let ptr = &mut v[1] as *mut _;
///     // Shorten `v` to prevent the last item from being dropped. <br>缩短 `v`，以防止丢弃最后一个项。<br>
///     // We do that first, to prevent issues if the `drop_in_place` below panics. <br>我们首先这样做是为了防止 `drop_in_place` 低于 panics。<br>
///     v.set_len(1);
///     // Without a call `drop_in_place`, the last item would never be dropped, and the memory it manages would be leaked. <br>如果没有调用 `drop_in_place`，则最后一个项将永远不会被删除，并且它管理的内存也会泄漏。<br>
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Ensure that the last item was dropped. <br>确保丢弃了最后一项。<br>
/// assert!(weak.upgrade().is_none());
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code here does not matter - this is replaced by the real drop glue by the compiler. <br>这里的代码并不重要 - 编译器会将其替换为真正的 drop glue。<br>
    //

    // SAFETY: see comment above <br>请看上面的注释<br>
    unsafe { drop_in_place(to_drop) }
}

/// Creates a null raw pointer. <br>创建一个空的裸指针。<br>
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null"]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Creates a null mutable raw pointer. <br>创建一个空的可变裸露指针。<br>
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null_mut"]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

/// Forms a raw slice from a pointer and a length. <br>根据指针和长度形成原始切片。<br>
///
/// The `len` argument is the number of **elements**, not the number of bytes. <br>`len` 参数是 **元素** 的数量，而不是字节数。<br>
///
/// This function is safe, but actually using the return value is unsafe. <br>此函数是安全的，但实际上使用返回值是不安全的。<br>
/// See the documentation of [`slice::from_raw_parts`] for slice safety requirements. <br>有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。<br>
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // create a slice pointer when starting out with a pointer to the first element <br>从指向第一个元素的指针开始创建切片指针<br>
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    from_raw_parts(data.cast(), len)
}

/// Performs the same functionality as [`slice_from_raw_parts`], except that a raw mutable slice is returned, as opposed to a raw immutable slice. <br>执行与 [`slice_from_raw_parts`] 相同的功能，但返回的是原始可变切片，而不是原始的不可变切片。<br>
///
///
/// See the documentation of [`slice_from_raw_parts`] for more details. <br>有关更多详细信息，请参见 [`slice_from_raw_parts`] 的文档。<br>
///
/// This function is safe, but actually using the return value is unsafe. <br>此函数是安全的，但实际上使用返回值是不安全的。<br>
/// See the documentation of [`slice::from_raw_parts_mut`] for slice safety requirements. <br>有关切片的安全要求，请参见 [`slice::from_raw_parts_mut`] 的文档。<br>
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assign a value at an index in the slice <br>在切片中的索引处分配值<br>
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps the values at two mutable locations of the same type, without deinitializing either. <br>在相同类型的两个可变位置交换值，而无需取消初始化任何一个。<br>
///
/// But for the following two exceptions, this function is semantically equivalent to [`mem::swap`]: <br>但是对于以下两个例外，此函数在语义上等效于 [`mem::swap`]：<br>
///
///
/// * It operates on raw pointers instead of references. <br>它对裸指针而不是引用进行操作。<br>
/// When references are available, [`mem::swap`] should be preferred. <br>如果引用可用，则应首选 [`mem::swap`]。<br>
///
/// * The two pointed-to values may overlap. <br>两个指向的值可能会重叠。<br>
/// If the values do overlap, then the overlapping region of memory from `x` will be used. <br>如果值确实重叠，则将使用 `x` 的内存重叠区域。<br>
/// This is demonstrated in the second example below. <br>在下面的第二个示例中对此进行了演示。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * Both `x` and `y` must be [valid] for both reads and writes. <br>对于读取和写入，`x` 和 `y` 都必须为 [有效][valid] 的。<br>
///
/// * Both `x` and `y` must be properly aligned. <br>`x` 和 `y` 必须正确对齐。<br>
///
/// Note that even if `T` has size `0`, the pointers must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Swapping two non-overlapping regions: <br>交换两个不重叠的区域：<br>
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // this is `array[0..2]` <br>这是 `array[0..2]`<br>
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // this is `array[2..4]` <br>这是 `array[2..4]`<br>
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Swapping two overlapping regions: <br>交换两个重叠的区域：<br>
///
/// ```
/// use std::ptr;
///
/// let mut array: [i32; 4] = [0, 1, 2, 3];
///
/// let array_ptr: *mut i32 = array.as_mut_ptr();
///
/// let x = array_ptr as *mut [i32; 3]; // this is `array[0..3]` <br>这是 `array[0..3]`<br>
/// let y = unsafe { array_ptr.add(1) } as *mut [i32; 3]; // this is `array[1..4]` <br>这是 `array[1..4]`<br>
///
/// unsafe {
///     ptr::swap(x, y);
///     // The indices `1..3` of the slice overlap between `x` and `y`. <br>切片的索引 `1..3` 在 `x` 和 `y` 之间重叠。<br>
///     // Reasonable results would be for to them be `[2, 3]`, so that indices `0..3` are `[1, 2, 3]` (matching `y` before the `swap`); <br>合理的结果将是 `[2, 3]`，因此索引 `0..3` 为 `[1, 2, 3]` (与 `swap` 匹配的 `y`) ；<br> or for them to be `[0, 1]` so that indices `1..4` are `[0, 1, 2]` (matching `x` before the `swap`). <br>或将它们设为 `[0, 1]`，以使索引 `1..4` 为 `[0, 1, 2]` (与 `swap` 之前的 `x` 匹配)。<br>
/////
///     // This implementation is defined to make the latter choice. <br>定义此实现是为了做出后一种选择。<br>
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Give ourselves some scratch space to work with. <br>给自己一些工作的空间。<br>
    // We do not have to worry about drops: `MaybeUninit` does nothing when dropped. <br>我们不必担心丢弃: `MaybeUninit` 在丢弃时什么也不做。<br>
    let mut tmp = MaybeUninit::<T>::uninit();

    // Perform the swap <br>执行交换<br>
    // SAFETY: the caller must guarantee that `x` and `y` are valid for writes and properly aligned. <br>调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。<br>
    // `tmp` cannot be overlapping either `x` or `y` because `tmp` was just allocated on the stack as a separate allocated object. <br>`tmp` 不能与 `x` 或 `y` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配。<br>
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` and `y` may overlap <br>`x` 和 `y` 可能重叠<br>
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Swaps `count * size_of::<T>()` bytes between the two regions of memory beginning at `x` and `y`. <br>从 `x` 和 `y` 开始在两个内存区域之间交换 `count * size_of::<T>()` 字节。<br>
/// The two regions must *not* overlap. <br>这两个区域必须 *不能* 重叠。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * Both `x` and `y` must be [valid] for both reads and writes of `count <br>`x` 和 `y` 都必须 [有效][valid] 才能读取和写入 `count<br> *
///   size_of::<T>()` bytes. <br>size_of::<T>()` 个字节。<br>
///
/// * Both `x` and `y` must be properly aligned. <br>`x` 和 `y` 必须正确对齐。<br>
///
/// * The region of memory beginning at `x` with a size of `count <br>从 `x` 开始的内存区域，大小为 `count<br> *
///   size_of::<T>()` bytes must *not* overlap with the region of memory beginning at `y` with the same size. <br>size_of::<T>()` 字节不得与以 `y` 开始且大小相同的内存区域重叠。<br>
///
/// Note that even if the effectively copied size (`count * size_of::<T>()`) is `0`, the pointers must be non-null and properly aligned. <br>请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。<br>
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: the caller must guarantee that `x` and `y` are valid for writes and properly aligned. <br>调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。<br>
    //
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub(crate) const unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // NOTE(eddyb) SPIR-V's Logical addressing model doesn't allow for arbitrary reinterpretation of values as (chunkable) byte arrays, and the loop in the block optimization in `swap_nonoverlapping_bytes` is hard to rewrite back into the (unoptimized) direct swapping implementation, so we disable it. <br>SPIR-V 的逻辑寻址模型不允许将值任意重新解释为 (chunkable) 字节数组，并且 `swap_nonoverlapping_bytes` 中块优化中的循环很难重写回 (unoptimized) 直接交换实现，因此我们禁用它。<br>
    //
    // FIXME(eddyb) the block optimization also prevents MIR optimizations from understanding `mem::replace`, `Option::take`, etc. - a better overall solution might be to make `swap_nonoverlapping` into an intrinsic, which a backend can choose to implement using the block optimization, or not. <br>块优化也阻止了 MIR 优化对 `mem::replace`、`Option::take` 等的理解 - 更好的整体解决方案可能是将 `swap_nonoverlapping` 变成一个内部函数，后端可以选择使用块优化来实现或不实现。<br>
    //
    //
    //
    //
    //
    #[cfg(not(target_arch = "spirv"))]
    {
        // Only apply the block optimization in `swap_nonoverlapping_bytes` for types at least as large as the block size, to avoid pessimizing codegen. <br>仅对至少与块大小一样大的类型应用 `swap_nonoverlapping_bytes` 中的块优化，以避免对 codegen 产生负面影响。<br>
        //
        if mem::size_of::<T>() >= 32 {
            // SAFETY: the caller must uphold the safety contract for `swap_nonoverlapping`. <br>调用者必须遵守 `swap_nonoverlapping` 的安全保证。<br>
            unsafe { swap_nonoverlapping(x, y, 1) };
            return;
        }
    }

    // Direct swapping, for the cases not going through the block optimization. <br>直接交换，用于未经过块优化的情况。<br>
    // SAFETY: the caller must guarantee that `x` and `y` are valid for writes, properly aligned, and non-overlapping. <br>调用者必须保证 `x` 和 `y` 对于写入有效，正确对齐且不重叠。<br>
    //
    unsafe {
        let z = read(x);
        copy_nonoverlapping(y, x, 1);
        write(y, z);
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // The approach here is to utilize simd to swap x & y efficiently. <br>这里的方法是利用 simd 有效地交换 x 和 y。<br>
    // Testing reveals that swapping either 32 bytes or 64 bytes at a time is most efficient for Intel Haswell E processors. <br>测试表明，一次交换 32 字节或 64 字节对于 Intel Haswell E 处理器是最有效的。<br>
    // LLVM is more able to optimize if we give a struct a #[repr(simd)], even if we don't actually use this struct directly. <br>如果我们实际上不直接使用该结构体，则 LLVM 更能够优化 #[repr(simd)]。<br>
    //
    //
    // FIXME repr(simd) broken on emscripten and redox <br>repr(simd) 在 emscripten  和 redox 上损坏<br>
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop through x & y, copying them `Block` at a time The optimizer should unroll the loop fully for most types N.B. <br>遍历 x 和 y，一次复制 `Block` 优化器应针对大多数类型的 NB 完全展开循环<br>
    // We can't use a for loop as the `range` impl calls `mem::swap` recursively <br>我们不能使用 for 循环，因为 `range` impl 递归调用 `mem::swap`<br>
    //
    let mut i = 0;
    while i + block_size <= len {
        // Create some uninitialized memory as scratch space Declaring `t` here avoids aligning the stack when this loop is unused <br>创建一些未初始化的内存作为暂存空间在此声明 `t` 可以避免在未使用此循环时对齐栈<br>
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: As `i < len`, and as the caller must guarantee that `x` and `y` are valid for `len` bytes, `x + i` and `y + i` must be valid addresses, which fulfills the safety contract for `add`. <br>作为 `i < len`，并且由于调用者必须保证 `x` 和 `y` 对于 `len` 字节有效，因此 `x + i` 和 `y + i` 必须是有效地址，这满足了 `add` 的安全保证。<br>
        //
        //
        // Also, the caller must guarantee that `x` and `y` are valid for writes, properly aligned, and non-overlapping, which fulfills the safety contract for `copy_nonoverlapping`. <br>同样，调用者必须保证 `x` 和 `y` 对于写入有效，正确对齐且不重叠，从而满足 `copy_nonoverlapping` 的安全保证。<br>
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Swap a block of bytes of x & y, using t as a temporary buffer This should be optimized into efficient SIMD operations where available <br>将 t 用作临时缓冲区交换 x&y 字节的字节块。应将其优化为有效的 SIMD 操作 (如果可用)<br>
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Swap any remaining bytes <br>交换所有剩余字节<br>
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: see previous safety comment. <br>请参见之前的安全注释。<br>
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Moves `src` into the pointed `dst`, returning the previous `dst` value. <br>将 `src` 移至指定的 `dst`，返回先前的 `dst` 值。<br>
///
/// Neither value is dropped. <br>这两个值都不会被丢弃。<br>
///
/// This function is semantically equivalent to [`mem::replace`] except that it operates on raw pointers instead of references. <br>该函数在语义上等效于 [`mem::replace`]，除了它在裸指针上而不是在引用上运行。<br>
/// When references are available, [`mem::replace`] should be preferred. <br>如果引用可用，则应首选 [`mem::replace`]。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for both reads and writes. <br>对于读取和写入，`dst` 必须是 [有效的][valid]。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br>
///
/// * `dst` must point to a properly initialized value of type `T`. <br>`dst` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` would have the same effect without requiring the unsafe block. <br>`mem::replace` 将具有相同的效果，而无需 unsafe 块。<br>
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_replace", issue = "83164")]
pub const unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: the caller must guarantee that `dst` is valid to be cast to a mutable reference (valid for writes, aligned, initialized), and cannot overlap `src` since `dst` must point to a distinct allocated object. <br>调用者必须保证 `dst` 有效，可以强制转换为变量引用 (对写入，对齐，初始化有效)，并且不能与 `src` 重叠，因为 `dst` 必须指向不同的分配对象。<br>
    //
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // cannot overlap <br>不能重叠<br>
    }
    src
}

/// Reads the value from `src` without moving it. <br>从 `src` 读取值而不移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must be properly aligned. <br>`src` 必须正确对齐。<br> Use [`read_unaligned`] if this is not the case. <br>如果不是这种情况，请使用 [`read_unaligned`]。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually implement [`mem::swap`]: <br>手动实现 [`mem::swap`]：<br>
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Create a bitwise copy of the value at `a` in `tmp`. <br>在 `tmp` 中的 `a` 处创建值的按位副本。<br>
///         let tmp = ptr::read(a);
///
///         // Exiting at this point (either by explicitly returning or by calling a function which panics) would cause the value in `tmp` to be dropped while the same value is still referenced by `a`. <br>此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。<br>
///         // This could trigger undefined behavior if `T` is not `Copy`. <br>如果 `T` 不是 `Copy`，则可能触发未定义的行为。<br>
/////
/////
///
///         // Create a bitwise copy of the value at `b` in `a`. <br>在 `a` 中的 `b` 处创建值的按位副本。<br>
///         // This is safe because mutable references cannot alias. <br>这是安全的，因为可变引用不能使用别名。<br>
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // As above, exiting here could trigger undefined behavior because the same value is referenced by `a` and `b`. <br>如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。<br>
/////
///
///         // Move `tmp` into `b`. <br>将 `tmp` 移至 `b`。<br>
///         ptr::write(b, tmp);
///
///         // `tmp` has been moved (`write` takes ownership of its second argument), so nothing is dropped implicitly here. <br>`tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。<br>
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ownership of the Returned Value <br>归还值的所有权<br>
///
/// `read` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>`read` 创建 `T` 的按位副本，无论 `T` 是否为 [`Copy`]。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can violate memory safety. <br>如果 `T` 不是 [`Copy`]，则同时使用返回的值和 `*src` 的值可能会违反内存安全性。<br>
/// Note that assigning to `*src` counts as a use because it will attempt to drop the value at `*src`. <br>请注意，将分配给 `*src` 视为一种用途，因为它将尝试丢弃 `*src` 处的值。<br>
///
/// [`write()`] can be used to overwrite data without causing it to be dropped. <br>[`write()`] 可用于覆盖数据，而不会导致数据被丢弃。<br>
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` now points to the same underlying memory as `s`. <br>`s2` 现在指向与 `s` 相同的底层内存。<br>
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Assigning to `s2` causes its original value to be dropped. <br>分配给 `s2` 会导致其原始值被丢弃。<br>
///     // Beyond this point, `s` must no longer be used, as the underlying memory has been freed. <br>除此之外，由于已释放底层内存，因此不能再使用 `s`。<br>
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Assigning to `s` would cause the old value to be dropped again, resulting in undefined behavior. <br>分配给 `s` 将导致旧值再次被丢弃，从而导致未定义的行为。<br>
/////
///     // s = String::from("bar");  // ERROR <br>// 错误<br>
///
///     // `ptr::write` can be used to overwrite a value without dropping it. <br>`ptr::write` 可用于覆盖一个值而无需丢弃它。<br>
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    // We are calling the intrinsics directly to avoid function calls in the generated code as `intrinsics::copy_nonoverlapping` is a wrapper function. <br>我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。<br>
    //
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: the caller must guarantee that `src` is valid for reads. <br>调用者必须保证 `src` 对于读取有效。<br>
    // `src` cannot overlap `tmp` because `tmp` was just allocated on the stack as a separate allocated object. <br>`src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。<br>
    //
    //
    // Also, since we just wrote a valid value into `tmp`, it is guaranteed to be properly initialized. <br>另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。<br>
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Reads the value from `src` without moving it. <br>从 `src` 读取值而不移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// Unlike [`read`], `read_unaligned` works with unaligned pointers. <br>与 [`read`] 不同，`read_unaligned` 使用未对齐的指针。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Like [`read`], `read_unaligned` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_unaligned` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空。<br>
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## On `packed` structs <br>在 `packed` 结构体上<br>
///
/// Attempting to create a raw pointer to an `unaligned` struct field with an expression such as `&packed.unaligned as *const FieldType` creates an intermediate unaligned reference before converting that to a raw pointer. <br>尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。<br>
///
/// That this reference is temporary and immediately cast is inconsequential as the compiler always expects references to be properly aligned. <br>引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。<br>
/// As a result, using `&packed.unaligned as *const FieldType` causes immediate *undefined behavior* in your program. <br>结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。<br>
///
/// Instead you must use the [`ptr::addr_of!`](addr_of) macro to create the pointer. <br>相反，您必须使用 [`ptr::addr_of!`](addr_of) 宏来创建指针。<br> You may use that returned pointer together with this function. <br>您可以将返回的指针与此函数一起使用。<br>
///
/// An example of what not to do and how this relates to `read_unaligned` is: <br>一个不执行的操作以及它与 `read_unaligned` 的关系的示例是：<br>
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// // Take the address of a 32-bit integer which is not aligned. <br>取一个未对齐的 32 位整数的地址。<br>
/// // In contrast to `&packed.unaligned as *const _`, this has no undefined behavior. <br>与 `&packed.unaligned as *const _` 相比，它没有未定义的行为。<br>
/// let unaligned = std::ptr::addr_of!(packed.unaligned);
///
/// let v = unsafe { std::ptr::read_unaligned(unaligned) };
/// assert_eq!(v, 0x01020304);
/// ```
///
/// Accessing unaligned fields directly with e.g. `packed.unaligned` is safe however. <br>但是，例如使用 `packed.unaligned` 直接访问未对齐的字段是安全的。<br>
///
/// # Examples
///
/// Read a usize value from a byte buffer: <br>从字节缓冲区读取 usize 值：<br>
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: the caller must guarantee that `src` is valid for reads. <br>调用者必须保证 `src` 对于读取有效。<br>
    // `src` cannot overlap `tmp` because `tmp` was just allocated on the stack as a separate allocated object. <br>`src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。<br>
    //
    //
    // Also, since we just wrote a valid value into `tmp`, it is guaranteed to be properly initialized. <br>另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。<br>
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
///
/// `write` does not drop the contents of `dst`. <br>`write` 不会丢弃 `dst` 的内容。<br>
/// This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// This is appropriate for initializing uninitialized memory, or overwriting memory that has previously been [`read`] from. <br>这适用于初始化未初始化的内存，或覆盖以前是 [`read`] 的内存。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br> Use [`write_unaligned`] if this is not the case. <br>如果不是这种情况，请使用 [`write_unaligned`]。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manually implement [`mem::swap`]: <br>手动实现 [`mem::swap`]：<br>
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Create a bitwise copy of the value at `a` in `tmp`. <br>在 `tmp` 中的 `a` 处创建值的按位副本。<br>
///         let tmp = ptr::read(a);
///
///         // Exiting at this point (either by explicitly returning or by calling a function which panics) would cause the value in `tmp` to be dropped while the same value is still referenced by `a`. <br>此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。<br>
///         // This could trigger undefined behavior if `T` is not `Copy`. <br>如果 `T` 不是 `Copy`，则可能触发未定义的行为。<br>
/////
/////
///
///         // Create a bitwise copy of the value at `b` in `a`. <br>在 `a` 中的 `b` 处创建值的按位副本。<br>
///         // This is safe because mutable references cannot alias. <br>这是安全的，因为可变引用不能使用别名。<br>
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // As above, exiting here could trigger undefined behavior because the same value is referenced by `a` and `b`. <br>如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。<br>
/////
///
///         // Move `tmp` into `b`. <br>将 `tmp` 移至 `b`。<br>
///         ptr::write(b, tmp);
///
///         // `tmp` has been moved (`write` takes ownership of its second argument), so nothing is dropped implicitly here. <br>`tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。<br>
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write<T>(dst: *mut T, src: T) {
    // We are calling the intrinsics directly to avoid function calls in the generated code as `intrinsics::copy_nonoverlapping` is a wrapper function. <br>我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。<br>
    //
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: the caller must guarantee that `dst` is valid for writes. <br>调用者必须保证 `dst` 对写入有效。<br>
    // `dst` cannot overlap `src` because the caller has mutable access to `dst` while `src` is owned by this function. <br>`dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。<br>
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
///
/// Unlike [`write()`], the pointer may be unaligned. <br>与 [`write()`] 不同，指针可能未对齐。<br>
///
/// `write_unaligned` does not drop the contents of `dst`. <br>`write_unaligned` 不会丢弃 `dst` 的内容。<br> This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// This is appropriate for initializing uninitialized memory, or overwriting memory that has previously been read with [`read_unaligned`]. <br>这适用于初始化未初始化的内存，或覆盖以前用 [`read_unaligned`] 读取的内存。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空。<br>
///
/// [valid]: self#safety
///
/// ## On `packed` structs <br>在 `packed` 结构体上<br>
///
/// Attempting to create a raw pointer to an `unaligned` struct field with an expression such as `&packed.unaligned as *const FieldType` creates an intermediate unaligned reference before converting that to a raw pointer. <br>尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。<br>
///
/// That this reference is temporary and immediately cast is inconsequential as the compiler always expects references to be properly aligned. <br>引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。<br>
/// As a result, using `&packed.unaligned as *const FieldType` causes immediate *undefined behavior* in your program. <br>结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。<br>
///
/// Instead you must use the [`ptr::addr_of_mut!`](addr_of_mut) macro to create the pointer. <br>相反，您必须使用 [`ptr::addr_of_mut!`](addr_of_mut) 宏来创建指针。<br> You may use that returned pointer together with this function. <br>您可以将返回的指针与此函数一起使用。<br>
///
/// An example of how to do it and how this relates to `write_unaligned` is: <br>如何做到这一点以及这与 `write_unaligned` 的关系的一个例子是：<br>
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// // Take the address of a 32-bit integer which is not aligned. <br>取一个未对齐的 32 位整数的地址。<br>
/// // In contrast to `&packed.unaligned as *mut _`, this has no undefined behavior. <br>与 `&packed.unaligned as *mut _` 相比，它没有未定义的行为。<br>
/// let unaligned = std::ptr::addr_of_mut!(packed.unaligned);
///
/// unsafe { std::ptr::write_unaligned(unaligned, 42) };
///
/// assert_eq!({packed.unaligned}, 42); // `{...}` forces copying the field instead of creating a reference. <br>`{...}` 强制复制字段而不是创建引用。<br>
/// ```
///
/// Accessing unaligned fields directly with e.g. `packed.unaligned` is safe however (as can be seen in the `assert_eq!` above). <br>然而，直接使用例如 `packed.unaligned` 访问未对齐的字段是安全的 (如上面的 `assert_eq!` 所示)。<br>
///
/// # Examples
///
/// Write a usize value to a byte buffer: <br>将 usize 值写入字节缓冲区：<br>
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: the caller must guarantee that `dst` is valid for writes. <br>调用者必须保证 `dst` 对写入有效。<br>
    // `dst` cannot overlap `src` because the caller has mutable access to `dst` while `src` is owned by this function. <br>`dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。<br>
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // We are calling the intrinsic directly to avoid function calls in the generated code. <br>我们直接调用内部函数以避免在生成的代码中进行函数调用。<br>
        intrinsics::forget(src);
    }
}

/// Performs a volatile read of the value from `src` without moving it. <br>对 `src` 的值进行易失性读取，而无需移动它。<br> This leaves the memory in `src` unchanged. <br>这将使 `src` 中的内存保持不变。<br>
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
///
/// # Notes
///
/// Rust does not currently have a rigorously and formally defined memory model, so the precise semantics of what "volatile" means here is subject to change over time. <br>Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。<br>
/// That being said, the semantics will almost always end up pretty similar to [C11's definition of volatile][c11]. <br>话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。<br>
///
/// The compiler shouldn't change the relative order or number of volatile memory operations. <br>编译器不应更改易失性存储器操作的相对顺序或数量。<br>
/// However, volatile memory operations on zero-sized types (e.g., if a zero-sized type is passed to `read_volatile`) are noops and may be ignored. <br>但是，零大小类型 (例如，如果将零大小类型传递给 `read_volatile`) 上的易失性存储器操作为无操作，可以忽略。<br>
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads. <br>`src` 必须是 [有效的][valid] 才能读取。<br>
///
/// * `src` must be properly aligned. <br>`src` 必须正确对齐。<br>
///
/// * `src` must point to a properly initialized value of type `T`. <br>`src` 必须指向 `T` 类型的正确初始化值。<br>
///
/// Like [`read`], `read_volatile` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_volatile` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using both the returned value and the value at `*src` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。<br>
/// However, storing non-[`Copy`] types in volatile memory is almost certainly incorrect. <br>但是，几乎可以肯定地将非 [`Copy`] 类型存储在易失性存储器中。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Just like in C, whether an operation is volatile has no bearing whatsoever on questions involving concurrent access from multiple threads. <br>就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。<br> Volatile accesses behave exactly like non-atomic accesses in that regard. <br>在这方面，易失性访问的行为与非原子访问完全相同。<br>
///
/// In particular, a race between a `read_volatile` and any write operation to the same location is undefined behavior. <br>特别是，`read_volatile` 与任何对同一位置的写操作之间的争夺是未定义的行为。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Not panicking to keep codegen impact smaller. <br>不要 panic，以保持代码生成的影响较小。<br>
        abort();
    }
    // SAFETY: the caller must uphold the safety contract for `volatile_load`. <br>调用者必须遵守 `volatile_load` 的安全保证。<br>
    unsafe { intrinsics::volatile_load(src) }
}

/// Performs a volatile write of a memory location with the given value without reading or dropping the old value. <br>使用给定值对存储单元执行易失性写操作，而无需读取或丢弃旧值。<br>
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
///
/// `write_volatile` does not drop the contents of `dst`. <br>`write_volatile` 不会丢弃 `dst` 的内容。<br> This is safe, but it could leak allocations or resources, so care should be taken not to overwrite an object that should be dropped. <br>这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。<br>
///
/// Additionally, it does not drop `src`. <br>此外，它不会丢弃 `src`。<br> Semantically, `src` is moved into the location pointed to by `dst`. <br>在语义上，`src` 被移到 `dst` 指向的位置。<br>
///
/// # Notes
///
/// Rust does not currently have a rigorously and formally defined memory model, so the precise semantics of what "volatile" means here is subject to change over time. <br>Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。<br>
/// That being said, the semantics will almost always end up pretty similar to [C11's definition of volatile][c11]. <br>话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。<br>
///
/// The compiler shouldn't change the relative order or number of volatile memory operations. <br>编译器不应更改易失性存储器操作的相对顺序或数量。<br>
/// However, volatile memory operations on zero-sized types (e.g., if a zero-sized type is passed to `write_volatile`) are noops and may be ignored. <br>但是，零大小类型 (例如，如果将零大小类型传递给 `write_volatile`) 上的易失性存储器操作为无操作，可以忽略。<br>
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes. <br>`dst` 必须是 [有效的][valid] 才能写入。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br>
///
/// Note that even if `T` has size `0`, the pointer must be non-null and properly aligned. <br>请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。<br>
///
/// [valid]: self#safety
///
/// Just like in C, whether an operation is volatile has no bearing whatsoever on questions involving concurrent access from multiple threads. <br>就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。<br> Volatile accesses behave exactly like non-atomic accesses in that regard. <br>在这方面，易失性访问的行为与非原子访问完全相同。<br>
///
/// In particular, a race between a `write_volatile` and any other operation (reading or writing) on the same location is undefined behavior. <br>特别是，`write_volatile` 与同一位置上的任何其他操作 (读取或写入) 之间的争夺是未定义的行为。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Not panicking to keep codegen impact smaller. <br>不要 panic，以保持代码生成的影响较小。<br>
        abort();
    }
    // SAFETY: the caller must uphold the safety contract for `volatile_store`. <br>调用者必须遵守 `volatile_store` 的安全保证。<br>
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Align pointer `p`. <br>对齐指针 `p`。<br>
///
/// Calculate offset (in terms of elements of `stride` stride) that has to be applied to pointer `p` so that pointer `p` would get aligned to `a`. <br>计算必须应用于指针 `p` 的偏移量 (根据 `stride` 步幅)，以便指针 `p` 与 `a` 对齐。<br>
///
/// Note: This implementation has been carefully tailored to not panic. <br>此实现已针对非 panic 进行了精心设计。<br> It is UB for this to panic. <br>到 panic 是 UB。<br>
/// The only real change that can be made here is change of `INV_TABLE_MOD_16` and associated constants. <br>此处唯一可以进行的更改是 `INV_TABLE_MOD_16` 及其关联常量的更改。<br>
///
/// If we ever decide to make it possible to call the intrinsic with `a` that is not a power-of-two, it will probably be more prudent to just change to a naive implementation rather than trying to adapt this to accommodate that change. <br>如果我们决定可以使用不是二次幂的 `a` 来调用内部函数，那么可能更谨慎的做法是只更改为一个简单的实现，而不是尝试调整它以适应这种更改。<br>
///
///
/// Any questions go to @nagisa. <br>如有任何疑问，请发送至 @nagisa。<br>
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direct use of these intrinsics improves codegen significantly at opt-level <= <br>直接使用这些内部函数可以显着提高 codegen 在 opt-level <=<br>
    // 1, where the method versions of these operations are not inlined. <br>1，其中未内联这些操作的方法版本。<br>
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calculate multiplicative modular inverse of `x` modulo `m`. <br>计算 `x` 模 `m` 的乘法模逆。<br>
    ///
    /// This implementation is tailored for `align_offset` and has following preconditions: <br>此实现是针对 `align_offset` 量身定制的，并具有以下先决条件：<br>
    ///
    /// * `m` is a power-of-two; <br>`m` 是二的幂；<br>
    /// * `x < m`; (if `x ≥ m`, pass in `x % m` instead) <br>(如果使用 `x ≥ m`，请改为传入 `x % m`)<br>
    ///
    /// Implementation of this function shall not panic. <br>此函数的实现不得为 panic。<br> Ever.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse table modulo 2⁴ = 16. <br>乘模逆矩阵模 2⁴=16。<br>
        ///
        /// Note, that this table does not contain values where inverse does not exist (i.e., for `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.) <br>注意，该表不包含不存在反值的值 (例如，对于 `0⁻¹ mod 16`，`2⁻¹ mod 16` 等)。<br>
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo for which the `INV_TABLE_MOD_16` is intended. <br>`INV_TABLE_MOD_16` 的模数。<br>
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` is required to be a power-of-two, hence non-zero. <br>`m` 必须为 2 的幂，因此不能为零。<br>
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // We iterate "up" using the following formula: <br>我们使用以下公式迭代 "up"：<br>
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2 - xy) ≡ 1 (mod 2²ⁿ)  $$
            //
            // until 2²ⁿ ≥ m. <br>直到 2²ⁿ ≥ m。<br> Then we can reduce to our desired `m` by taking the result `mod m`. <br>然后，我们可以通过取结果 `mod m` 减少到所需的 `m`。<br>
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y = y * (2 - xy) mod n
                //
                // Note, that we use wrapping operations here intentionally – the original formula uses e.g., subtraction `mod n`. <br>注意，这里我们有意使用包装操作 - 原始公式使用减法 `mod n`。<br>
                // It is entirely fine to do them `mod usize::MAX` instead, because we take the result `mod n` at the end anyway. <br>改用 `mod usize::MAX` 完全可以，因为无论如何我们将结果 `mod n` 放在最后。<br>
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` is a power-of-two, therefore non-zero. <br>`a` 为 2 的幂，因此非零。<br>
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case can be computed more simply through `-p (mod a)`, but doing so inhibits LLVM's ability to select instructions like `lea`. <br>`stride == 1` case 可以通过 `-p (mod a)` 更简单地计算，但这样做会抑制 LLVM 选择像 `lea` 这样的指令的能力。<br> Instead we compute <br>相反，我们计算<br>
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // which distributes operations around the load-bearing, but pessimizing `and` sufficiently for LLVM to be able to utilize the various optimizations it knows about. <br>它围绕承重来分配操作，但是对 `and` 进行了充分的模拟，以使 LLVM 能够利用它所了解的各种优化。<br>
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Already aligned. <br>已经对齐。<br> Yay!
        return 0;
    } else if stride == 0 {
        // If the pointer is not aligned, and the element is zero-sized, then no amount of elements will ever align the pointer. <br>如果指针未对齐，并且元素大小为零，则将没有任何元素可以对齐指针。<br>
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a is power-of-two hence non-zero. <br>a 是 2 的幂，因此非零。<br> stride == 0 case is handled above. <br>stride == 0 情况已在上面处理。<br>
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow has an upper-bound that’s at most the number of bits in a usize. <br>gcdpow 有一个上限，最多是 usize 中的位数。<br>
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd is always greater or equal to 1. <br>gcd 始终大于或等于 1。<br>
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // This branch solves for the following linear congruence equation: <br>该分支求解以下线性同余方程：<br>
        //
        // ` p + so = 0 mod a `
        //
        // `p` here is the pointer value, `s` - stride of `T`, `o` offset in `T`s, and `a` - the requested alignment. <br>这里的 `p` 是指针值，`s`-`T` 的步幅，`T` 中的 `o` 偏移量，以及 `a` - 请求的对齐方式。<br>
        //
        // With `g = gcd(a, s)`, and the above condition asserting that `p` is also divisible by `g`, we can denote `a' = a/g`, `s' = s/g`, `p' = p/g`, then this becomes equivalent to: <br>使用 `g = gcd(a, s)`，并且上面的条件断言 `p` 也可以被 `g` 整除，我们可以表示 `a' = a/g`，`s' = s/g`，`p' = p/g`，那么它等效于：<br>
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // The first term is "the relative alignment of `p` to `a`" (divided by the `g`), the second term is "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (again divided by `g`). <br>第一项是 "the relative alignment of `p` to `a`" (除以 `g`)，第二项是 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (再次除以 `g`)。<br>
        //
        // Division by `g` is necessary to make the inverse well formed if `a` and `s` are not co-prime. <br>如果 `a` 和 `s` 不是互质的，则 `g` 的除法对于使逆结构良好是必要的。<br>
        //
        // Furthermore, the result produced by this solution is not "minimal", so it is necessary to take the result `o mod lcm(s, a)`. <br>此外，此解决方案产生的结果不是 "minimal"，因此必须获得结果 `o mod lcm(s, a)`。<br> We can replace `lcm(s, a)` with just a `a'`. <br>我们可以只用 `a'` 代替 `lcm(s, a)`。<br>
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` is non-zero. <br>`a2` 不为零。<br>
        // Shifting `a` by `gcdpow` cannot shift out any of the set bits in `a` (of which it has exactly one). <br>将 `a` 移位 `gcdpow` 不能移出 `a` 中的任何设置位 (其中只有一位)。<br>
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` has an upper-bound not greater than the number of trailing 0-bits in `a`. <br>`gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。<br>
        // Furthermore, the subtraction cannot overflow, because `a2 = a >> gcdpow` will always be strictly greater than `(p % a) >> gcdpow`. <br>此外，减法不会溢出，因为 `a2 = a >> gcdpow` 将始终严格大于 `(p % a) >> gcdpow`。<br>
        //
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` is a power-of-two, as proven above. <br>如上所述，`a2` 是 2 的幂。<br>
        // `s2` is strictly less than `a2` because `(s % a) >> gcdpow` is strictly less than `a >> gcdpow`. <br>`s2` 严格小于 `a2`，因为 `(s % a) >> gcdpow` 严格小于 `a >> gcdpow`。<br>
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Cannot be aligned at all. <br>根本无法对齐。<br>
    usize::MAX
}

/// Compares raw pointers for equality. <br>比较裸指针是否相等。<br>
///
/// This is the same as using the `==` operator, but less generic: <br>这与使用 `==` 运算符相同，但泛型较少：<br>
/// the arguments have to be `*const T` raw pointers, not anything that implements `PartialEq`. <br>参数必须是 `*const T` 裸指针，而不是任何实现 `PartialEq` 的东西。<br>
///
/// This can be used to compare `&T` references (which coerce to `*const T` implicitly) by their address rather than comparing the values they point to (which is what the `PartialEq for &T` implementation does). <br>这可用于按地址比较 `&T` 引用 (隐式强制为 `*const T`)，而不是比较它们指向的值 (`PartialEq for &T` 实现的作用)。<br>
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Slices are also compared by their length (fat pointers): <br>切片还通过它们的长度 (胖指针) 进行比较：<br>
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits are also compared by their implementation: <br>还可以通过 traits 的实现进行比较：<br>
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pointers have equal addresses. <br>指针具有相等的地址。<br>
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objects have equal addresses, but `Trait` has different implementations. <br>对象具有相等的地址，但是 `Trait` 具有不同的实现。<br>
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Converting the reference to a `*const u8` compares by address. <br>将引用转换为 `*const u8` 时，将按地址进行比较。<br>
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash a raw pointer. <br>散列一个裸指针。<br>
///
/// This can be used to hash a `&T` reference (which coerces to `*const T` implicitly) by its address rather than the value it points to (which is what the `Hash for &T` implementation does). <br>这可用于通过其地址而不是其指向的值 (`Hash for &T` 实现的作用) 对 `&T` 引用 (隐式强制为 `*const T`) 进行哈希处理。<br>
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls for function pointers <br>函数指针的 Impls<br>
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: The intermediate cast as usize is required for AVR so that the address space of the source function pointer is preserved in the final function pointer. <br>AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。<br>
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: The intermediate cast as usize is required for AVR so that the address space of the source function pointer is preserved in the final function pointer. <br>AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。<br>
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // No variadic functions with 0 parameters <br>没有参数为 0 的可变参数函数<br>
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Create a `const` raw pointer to a place, without creating an intermediate reference. <br>创建一个 `const` 裸指针到一个位置，而无需创建中间引用。<br>
///
/// Creating a reference with `&`/`&mut` is only allowed if the pointer is properly aligned and points to initialized data. <br>仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。<br>
/// For cases where those requirements do not hold, raw pointers should be used instead. <br>对于那些不满足要求的情况，应改用裸指针。<br>
/// However, `&expr as *const _` creates a reference before casting it to a raw pointer, and that reference is subject to the same rules as all other references. <br>但是，`&expr as *const _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。<br>
///
/// This macro can create a raw pointer *without* creating a reference first. <br>该宏可以创建一个裸指针，而无需先创建一个引用。<br>
///
/// Note, however, that the `expr` in `addr_of!(expr)` is still subject to all the usual rules. <br>但是请注意，`addr_of!(expr)` 中的 `expr` 仍受所有常规规则的约束。<br>
/// In particular, `addr_of!(*ptr::null())` is Undefined Behavior because it dereferences a null pointer. <br>特别是，`addr_of!(*ptr::null())` 是未定义行为，因为它解引用空指针。<br>
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` would create an unaligned reference, and thus be Undefined Behavior! <br>`&packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！<br>
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
/// See [`addr_of_mut`] for how to create a pointer to unininitialized data. <br>有关如何创建指向未初始化数据的指针，请参见 [`addr_of_mut`]。<br>
/// Doing that with `addr_of` would not make much sense since one could only read the data, and that would be Undefined Behavior. <br>用 `addr_of` 这样做没有多大意义，因为人们只能读取数据，这将是未定义行为。<br>
///
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Create a `mut` raw pointer to a place, without creating an intermediate reference. <br>创建一个 `mut` 裸指针到一个位置，而无需创建中间引用。<br>
///
/// Creating a reference with `&`/`&mut` is only allowed if the pointer is properly aligned and points to initialized data. <br>仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。<br>
/// For cases where those requirements do not hold, raw pointers should be used instead. <br>对于那些不满足要求的情况，应改用裸指针。<br>
/// However, `&mut expr as *mut _` creates a reference before casting it to a raw pointer, and that reference is subject to the same rules as all other references. <br>但是，`&mut expr as *mut _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。<br>
///
/// This macro can create a raw pointer *without* creating a reference first. <br>该宏可以创建一个裸指针，而无需先创建一个引用。<br>
///
/// Note, however, that the `expr` in `addr_of_mut!(expr)` is still subject to all the usual rules. <br>但请注意，`addr_of_mut!(expr)` 中的 `expr` 仍受所有常规规则的约束。<br>
/// In particular, `addr_of_mut!(*ptr::null_mut())` is Undefined Behavior because it dereferences a null pointer. <br>特别是，`addr_of_mut!(*ptr::null_mut())` 是未定义行为，因为它解引用空指针。<br>
///
/// # Examples
///
/// **Creating a pointer to unaligned data: <br>创建指向未对齐数据的指针：<br>**
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` would create an unaligned reference, and thus be Undefined Behavior! <br>`&mut packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！<br>
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forces copying the field instead of creating a reference. <br>`{...}` 强制复制字段而不是创建引用。<br>
/// ```
///
/// **Creating a pointer to uninitialized data: <br>创建指向未初始化数据的指针：<br>**
///
/// ```rust
/// use std::{ptr, mem::MaybeUninit};
///
/// struct Demo {
///     field: bool,
/// }
///
/// let mut uninit = MaybeUninit::<Demo>::uninit();
/// // `&uninit.as_mut().field` would create a reference to an uninitialized `bool`, and thus be Undefined Behavior! <br>`&uninit.as_mut().field` 会创建一个对未初始化的 `bool` 的引用，因此是未定义的行为！<br>
/////
/// let f1_ptr = unsafe { ptr::addr_of_mut!((*uninit.as_mut_ptr()).field) };
/// unsafe { f1_ptr.write(true); }
/// let init = unsafe { uninit.assume_init() };
/// ```
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}
