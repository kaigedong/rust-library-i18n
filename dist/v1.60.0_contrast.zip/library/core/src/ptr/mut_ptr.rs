use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Returns `true` if the pointer is null. <br>如果指针为空，则返回 `true`。<br>
    ///
    /// Note that unsized types have many possible null pointers, as only the raw data pointer is considered, not their length, vtable, etc. <br>请注意，未定义大小的类型具有许多可能的空指针，因为仅考虑原始数据指针，而不考虑其长度，vtable 等。<br>
    /// Therefore, two pointers that are null may still not compare equal to each other. <br>因此，两个为空的指针可能仍不能相互比较相等。<br>
    ///
    /// ## Behavior during const evaluation <br>常量评估期间的行为<br>
    ///
    /// When this function is used during const evaluation, it may return `false` for pointers that turn out to be null at runtime. <br>在 const 评估期间使用此函数时，对于在运行时结果为空的指针，它可能返回 `false`。<br>
    /// Specifically, when a pointer to some memory is offset beyond its bounds in such a way that the resulting pointer is null, the function will still return `false`. <br>具体来说，当指向某个内存的指针超出其范围的偏移量 (使结果指针为空) 时，函数仍将返回 `false`。<br>
    ///
    /// There is no way for CTFE to know the absolute position of that memory, so we cannot tell if the pointer is null or not. <br>CTFE 无法知道该内存的绝对位置，因此我们无法确定指针是否为空。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Compare via a cast to a thin pointer, so fat pointers are only considering their "data" part for null-ness. <br>通过对瘦指针进行强制转换进行比较，因此胖指针仅考虑其 "data" 部分是否为空。<br>
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Casts to a pointer of another type. <br>强制转换为另一种类型的指针。<br>
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline(always)]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Changes constness without changing the type. <br>更改常量而不更改类型。<br>
    ///
    /// This is a bit safer than `as` because it wouldn't silently change the type if the code is refactored. <br>这比 `as` 安全一点，因为如果重构代码，它不会默默地改变类型。<br>
    ///
    /// While not strictly required (`*mut T` coerces to `*const T`), this is provided for symmetry with `as_mut()` on `*const T` and may have documentation value if used instead of implicit coercion. <br>虽然不是严格要求 (`*mut T` 强制转换为 `*const T`)，但这是为了与 `*const T` 上的 `as_mut()` 保持对称而提供的，如果使用它来代替隐式强制，则可能具有文档值。<br>
    ///
    ///
    ///
    #[unstable(feature = "ptr_const_cast", issue = "92675")]
    #[rustc_const_unstable(feature = "ptr_const_cast", issue = "92675")]
    pub const fn as_const(self) -> *const T {
        self as _
    }

    /// Casts a pointer to its raw bits. <br>将指针强制转换为原始位。<br>
    ///
    /// This is equivalent to `as usize`, but is more specific to enhance readability. <br>这等效于 `as usize`，但更具体以增强可读性。<br>
    /// The inverse method is [`from_bits`](#method.from_bits-1). <br>相反的方法是 [`from_bits`](#method.from_bits-1)。<br>
    ///
    /// In particular, `*p as usize` and `p as usize` will both compile for pointers to numeric types but do very different things, so using this helps emphasize that reading the bits was intentional. <br>特别是，`*p as usize` 和 `p as usize` 都会编译指向数字类型的指针，但做的事情却截然不同，因此使用它有助于强调读取位是有意的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_to_from_bits)]
    /// let mut array = [13, 42];
    /// let mut it = array.iter_mut();
    /// let p0: *mut i32 = it.next().unwrap();
    /// assert_eq!(<*mut _>::from_bits(p0.to_bits()), p0);
    /// let p1: *mut i32 = it.next().unwrap();
    /// assert_eq!(p1.to_bits() - p0.to_bits(), 4);
    /// ```
    ///
    #[unstable(feature = "ptr_to_from_bits", issue = "91126")]
    pub fn to_bits(self) -> usize
    where
        T: Sized,
    {
        self as usize
    }

    /// Creates a pointer from its raw bits. <br>从其原始位创建一个指针。<br>
    ///
    /// This is equivalent to `as *mut T`, but is more specific to enhance readability. <br>这等效于 `as *mut T`，但更具体以增强可读性。<br>
    /// The inverse method is [`to_bits`](#method.to_bits-1). <br>相反的方法是 [`to_bits`](#method.to_bits-1)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_to_from_bits)]
    /// use std::ptr::NonNull;
    /// let dangling: *mut u8 = NonNull::dangling().as_ptr();
    /// assert_eq!(<*mut u8>::from_bits(1), dangling);
    /// ```
    #[unstable(feature = "ptr_to_from_bits", issue = "91126")]
    pub fn from_bits(bits: usize) -> Self
    where
        T: Sized,
    {
        bits as Self
    }

    /// Decompose a (possibly wide) pointer into its address and metadata components. <br>将指针 (可能是宽指针) 分解为其地址和元数据组件。<br>
    ///
    /// The pointer can be later reconstructed with [`from_raw_parts_mut`]. <br>以后可以使用 [`from_raw_parts_mut`] 重建指针。<br>
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Returns `None` if the pointer is null, or else returns a shared reference to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回 `Some` 中包装的值的共享引用。<br> If the value may be uninitialized, [`as_uninit_ref`] must be used instead. <br>如果该值可能未初始化，则必须改用 [`as_uninit_ref`]。<br>
    ///
    /// For the mutable counterpart see [`as_mut`]. <br>对于可变的对应物，请参见 [`as_mut`]。<br>
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * The pointer must point to an initialized instance of `T`. <br>指针必须指向 `T` 的初始化实例。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    /// (The part about being initialized is not yet fully decided, but until it is, the only safe approach is to ensure that they are indeed initialized.) <br>(关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-unchecked version <br>空未经检查的版本<br>
    ///
    /// If you are sure the pointer can never be null and are looking for some kind of `as_ref_unchecked` that returns the `&T` instead of `Option<&T>`, know that you can dereference the pointer directly. <br>如果确定指针永远不会为空，并且正在寻找某种返回 `&T` 而不是 `Option<&T>` 的 `as_ref_unchecked`，请知道您可以直接引用该指针。<br>
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    #[inline]
    pub const unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: the caller must guarantee that `self` is valid for a reference if it isn't null. <br>调用者必须保证 `self` 对于引用有效 (如果它不为 null)。<br>
        //
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returns `None` if the pointer is null, or else returns a shared reference to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回 `Some` 中包装的值的共享引用。<br>
    /// In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the mutable counterpart see [`as_uninit_mut`]. <br>对于可变的对应物，请参见 [`as_uninit_mut`]。<br>
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calculates the offset from a pointer. <br>计算与指针的偏移量。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset, **in bytes**, cannot overflow an `isize`. <br>计算的偏移量 (以字节为单位) 不会使 `isize` 溢出。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum, **in bytes** must fit in a usize. <br>也就是说，无限精度总和 (以字节为单位) 必须适合于 usize。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_offset`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_offset`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline(always)]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        // The obtained pointer is valid for writes since the caller must guarantee that it points to the same allocated object as `self`. <br>获得的指针对于写入有效，因为调用者必须保证它指向的对象与 `self` 相同。<br>
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_offset((y as isize) - (x as isize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_offset((y as isize) - (x as isize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`offset`], this method basically delays the requirement of staying within the same allocated object: [`offset`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`offset`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`offset`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_offset` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_offset` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`offset`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`offset`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` is always the same as `x`. <br>例如，`x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`offset`]: #method.offset
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements <br>使用裸指针以两个元素为增量进行迭代<br>
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline(always)]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: the `arith_offset` intrinsic has no prerequisites to be called. <br>`arith_offset` 内部函数没有要调用的先决条件。<br>
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Returns `None` if the pointer is null, or else returns a unique reference to the value wrapped in `Some`. <br>如果指针为 null，则返回 `None`，否则返回 `Some` 中包装的值的唯一引用。<br> If the value may be uninitialized, [`as_uninit_mut`] must be used instead. <br>如果该值可能未初始化，则必须改用 [`as_uninit_mut`]。<br>
    ///
    /// For the shared counterpart see [`as_ref`]. <br>有关共享副本，请参见 [`as_ref`]。<br>
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * The pointer must point to an initialized instance of `T`. <br>指针必须指向 `T` 的初始化实例。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    /// (The part about being initialized is not yet fully decided, but until it is, the only safe approach is to ensure that they are indeed initialized.) <br>(关于初始化的部分尚未完全决定，但是直到确定之前，唯一安全的方法是确保它们确实被初始化。)<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // It'll print: "[4, 2, 3]". <br>它会打印: "[4, 2, 3]"。<br>
    /// ```
    ///
    /// # Null-unchecked version <br>空未经检查的版本<br>
    ///
    /// If you are sure the pointer can never be null and are looking for some kind of `as_mut_unchecked` that returns the `&mut T` instead of `Option<&mut T>`, know that you can dereference the pointer directly. <br>如果确定指针永远不会为空，并且正在寻找某种返回 `&mut T` 而不是 `Option<&mut T>` 的 `as_mut_unchecked`，请知道您可以直接引用该指针。<br>
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // It'll print: "[4, 2, 3]". <br>它会打印: "[4, 2, 3]"。<br>
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    #[inline]
    pub const unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: the caller must guarantee that `self` is be valid for a mutable reference if it isn't null. <br>如果 `self` 不为 null，则调用者必须保证 `self` 对变量引用有效。<br>
        //
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Returns `None` if the pointer is null, or else returns a unique reference to the value wrapped in `Some`. <br>如果指针为 null，则返回 `None`，否则返回 `Some` 中包装的值的唯一引用。<br>
    /// In contrast to [`as_mut`], this does not require that the value has to be initialized. <br>与 [`as_mut`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the shared counterpart see [`as_uninit_ref`]. <br>有关共享副本，请参见 [`as_uninit_ref`]。<br>
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be properly aligned. <br>指针必须正确对齐。<br>
    ///
    /// * It must be "dereferenceable" in the sense defined in [the module documentation]. <br>在 [模块的文档][the module documentation] 中定义的含义上，它必须是 "dereferenceable"。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: the caller must guarantee that `self` meets all the requirements for a reference. <br>调用者必须保证 `self` 满足引用的所有要求。<br>
        //
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Returns whether two pointers are guaranteed to be equal. <br>返回两个指针是否保证相等。<br>
    ///
    /// At runtime this function behaves like `self == other`. <br>在运行时，此函数的行为类似于 `self == other`。<br>
    /// However, in some contexts (e.g., compile-time evaluation), it is not always possible to determine equality of two pointers, so this function may spuriously return `false` for pointers that later actually turn out to be equal. <br>但是，在某些情况下 (例如，编译时评估)，并非总是可以确定两个指针是否相等，因此此函数可能会虚假地返回 `false` 来表示后来实际上相等的指针。<br>
    ///
    /// But when it returns `true`, the pointers are guaranteed to be equal. <br>但是，当它返回 `true` 时，保证指针是相等的。<br>
    ///
    /// This function is the mirror of [`guaranteed_ne`], but not its inverse. <br>该函数是 [`guaranteed_ne`] 的镜像，但不是其反函数。<br> There are pointer comparisons for which both functions return `false`. <br>有两个指针返回 `false` 的指针比较。<br>
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// The return value may change depending on the compiler version and unsafe code might not rely on the result of this function for soundness. <br>返回值可能会根据编译器版本而改变，并且不安全的代码可能不依赖于这个函数的结果来保证稳健性。<br>
    /// It is suggested to only use this function for performance optimizations where spurious `false` return values by this function do not affect the outcome, but just the performance. <br>建议仅将此函数用于性能优化，在这种情况下，此函数的虚假 `false` 返回值不会影响结果，而只会影响性能。<br>
    /// The consequences of using this method to make runtime and compile-time code behave differently have not been explored. <br>尚未探讨使用此方法使运行时和编译时代码表现不同的后果。<br>
    /// This method should not be used to introduce such differences, and it should also not be stabilized before we have a better understanding of this issue. <br>不应使用这种方法来引入这种差异，并且在我们对这个问题有更好的理解之前，也不应使其稳定。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Returns whether two pointers are guaranteed to be unequal. <br>返回两个指针是否保证不相等。<br>
    ///
    /// At runtime this function behaves like `self != other`. <br>在运行时，此函数的行为类似于 `self != other`。<br>
    /// However, in some contexts (e.g., compile-time evaluation), it is not always possible to determine the inequality of two pointers, so this function may spuriously return `false` for pointers that later actually turn out to be unequal. <br>但是，在某些情况下 (例如，编译时评估)，并非总是可以确定两个指针的不相等性，因此此函数可能会虚假地返回 `false` 来表示后来实际上不相等的指针。<br>
    ///
    /// But when it returns `true`, the pointers are guaranteed to be unequal. <br>但是，当它返回 `true` 时，保证指针是不相等的。<br>
    ///
    /// This function is the mirror of [`guaranteed_eq`], but not its inverse. <br>该函数是 [`guaranteed_eq`] 的镜像，但不是其反函数。<br> There are pointer comparisons for which both functions return `false`. <br>有两个指针返回 `false` 的指针比较。<br>
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// The return value may change depending on the compiler version and unsafe code might not rely on the result of this function for soundness. <br>返回值可能会根据编译器版本而改变，并且不安全的代码可能不依赖于这个函数的结果来保证稳健性。<br>
    /// It is suggested to only use this function for performance optimizations where spurious `false` return values by this function do not affect the outcome, but just the performance. <br>建议仅将此函数用于性能优化，在这种情况下，此函数的虚假 `false` 返回值不会影响结果，而只会影响性能。<br>
    /// The consequences of using this method to make runtime and compile-time code behave differently have not been explored. <br>尚未探讨使用此方法使运行时和编译时代码表现不同的后果。<br>
    /// This method should not be used to introduce such differences, and it should also not be stabilized before we have a better understanding of this issue. <br>不应使用这种方法来引入这种差异，并且在我们对这个问题有更好的理解之前，也不应使其稳定。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Calculates the distance between two pointers. <br>计算两个指针之间的距离。<br> The returned value is in units of T: the distance in bytes is divided by `mem::size_of::<T>()`. <br>返回的值以 T 为单位：以字节为单位的距离除以 `mem::size_of::<T>()`。<br>
    ///
    /// This function is the inverse of [`offset`]. <br>该函数是 [`offset`] 的逆函数。<br>
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and other pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和其他指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * Both pointers must be *derived from* a pointer to the same object. <br>两个指针必须是指向同一对象的指针的 *derived。<br>
    ///   (See below for an example.) <br>(请参见下面的示例。)<br>
    ///
    /// * The distance between the pointers, in bytes, must be an exact multiple of the size of `T`. <br>指针之间的距离 (以字节为单位) 必须是 `T` 大小的精确倍数。<br>
    ///
    /// * The distance between the pointers, **in bytes**, cannot overflow an `isize`. <br>指针之间的距离 (以字节为单位) 不会溢出 `isize`。<br>
    ///
    /// * The distance being in bounds cannot rely on "wrapping around" the address space. <br>该距离不能依赖于 "wrapping around" 地址空间。<br>
    ///
    /// Rust types are never larger than `isize::MAX` and Rust allocations never wrap around the address space, so two pointers within some value of any Rust type `T` will always satisfy the last two conditions. <br>Rust 类型从不大于 `isize::MAX`，并且 Rust 分配从不环绕地址空间，因此，任何 Rust 类型 `T` 的某个值内的两个指针将始终满足最后两个条件。<br>
    ///
    /// The standard library also generally ensures that allocations never reach a size where an offset is a concern. <br>标准库通常还确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `ptr_into_vec.offset_from(vec.as_ptr())` always satisfies the last two conditions. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不超过 `isize::MAX` 字节，因此 `ptr_into_vec.offset_from(vec.as_ptr())` 始终满足最后两个条件。<br>
    ///
    /// Most platforms fundamentally can't even construct such a large allocation. <br>从根本上说，大多数平台甚至都无法构建如此大的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    /// (Note that [`offset`] and [`add`] also have a similar limitation and hence cannot be used on such large allocations either.) <br>(请注意，[`offset`] 和 [`add`] 也具有类似的限制，因此也不能在如此大的分配上使用。)<br>
    ///
    /// [`add`]: #method.add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Panics
    ///
    /// This function panics if `T` is a Zero-Sized Type ("ZST"). <br>如果 `T` 是零大小类型 ("ZST")，则此函数 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Incorrect* usage: <br>*不正确* 用法：<br>
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Make ptr2_other an "alias" of ptr2, but derived from ptr1. <br>将 ptr2_other 设置为 ptr2 的 "alias"，但从 ptr1 派生。<br>
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Since ptr2_other and ptr2 are derived from pointers to different objects, computing their offset is undefined behavior, even though they point to the same address! <br>由于 ptr2_other 和 ptr2 是从指向不同对象的指针派生的，因此即使它们指向相同的地址，计算其偏移量也是未定义的行为！<br>
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefined Behavior <br>未定义的行为<br>
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "92980")]
    #[inline(always)]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset_from`. <br>调用者必须遵守 `offset_from` 的安全保证。<br>
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Calculates the offset from a pointer (convenience for `.offset(count as isize)`). <br>计算与指针的偏移量 (`.offset(count as isize)` 的便利性)。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset, **in bytes**, cannot overflow an `isize`. <br>计算的偏移量 (以字节为单位) 不会使 `isize` 溢出。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum must fit in a `usize`. <br>也就是说，无限精度的总和必须符合 `usize`。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_add`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_add`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline(always)]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { self.offset(count as isize) }
    }

    /// Calculates the offset from a pointer (convenience for `.offset((count as isize).wrapping_neg())`). <br>计算与指针的偏移量 (`.offset((count as isize).wrapping_neg())` 的便利性)。<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// If any of the following conditions are violated, the result is Undefined Behavior: <br>如果违反以下任一条件，则结果为未定义行为：<br>
    ///
    /// * Both the starting and resulting pointer must be either in bounds or one byte past the end of the same [allocated object]. <br>起始指针和结果指针都必须在边界内或在同一个 [分配对象][allocated object] 的末尾之后一个字节。<br>
    ///
    /// * The computed offset cannot exceed `isize::MAX` **bytes**. <br>计算的偏移量不能超过 `isize::MAX` 个 **字节**。<br>
    ///
    /// * The offset being in bounds cannot rely on "wrapping around" the address space. <br>偏移量不能依赖 "wrapping around" 地址空间。<br> That is, the infinite-precision sum must fit in a usize. <br>也就是说，无限精度的总和必须符合使用大小。<br>
    ///
    /// The compiler and standard library generally tries to ensure allocations never reach a size where an offset is a concern. <br>编译器和标准库通常会尝试确保分配永远不会达到需要考虑偏移量的大小。<br>
    /// For instance, `Vec` and `Box` ensure they never allocate more than `isize::MAX` bytes, so `vec.as_ptr().add(vec.len()).sub(vec.len())` is always safe. <br>例如，`Vec` 和 `Box` 确保它们分配的字节数永远不会超过 `isize::MAX` 字节，因此 `vec.as_ptr().add(vec.len()).sub(vec.len())` 始终是安全的。<br>
    ///
    /// Most platforms fundamentally can't even construct such an allocation. <br>从根本上说，大多数平台甚至都无法构造这样的分配。<br>
    /// For instance, no known 64-bit platform can ever serve a request for 2<sup>63</sup> bytes due to page-table limitations or splitting the address space. <br>例如，由于页表的限制或地址空间的分割，没有已知的 64 位平台可以满足 2 <sup>63</sup> 字节的请求。<br>
    /// However, some 32-bit and 16-bit platforms may successfully serve a request for more than `isize::MAX` bytes with things like Physical Address Extension. <br>但是，某些 32 位和 16 位平台可能通过物理地址扩展之类的东西成功地为超过 `isize::MAX` 字节的请求提供服务。<br>
    ///
    /// As such, memory acquired directly from allocators or memory mapped files *may* be too large to handle with this function. <br>因此，直接从分配器获取的内存或内存映射文件 *可能* 太大而无法使用此函数进行处理。<br>
    ///
    /// Consider using [`wrapping_sub`] instead if these constraints are difficult to satisfy. <br>如果这些约束难以满足，请考虑使用 [`wrapping_sub`]。<br>
    /// The only advantage of this method is that it enables more aggressive compiler optimizations. <br>此方法的唯一优点是，它可以实现更积极的编译器优化。<br>
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `offset`. <br>调用者必须遵守 `offset` 的安全保证。<br>
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    /// (convenience for `.wrapping_offset(count as isize)`) <br>(为 `.wrapping_offset(count as isize)` 带来的便利)<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_add((y as usize) - (x as usize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_add((y as usize) - (x as usize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`add`], this method basically delays the requirement of staying within the same allocated object: [`add`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`add`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`add`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_add` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_add` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`add`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`add`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_add(o).wrapping_sub(o)` is always the same as `x`. <br>例如，`x.wrapping_add(o).wrapping_sub(o)` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`add`]: #method.add
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements <br>使用裸指针以两个元素为增量进行迭代<br>
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // This loop prints "1, 3, 5, " <br>此循环打印 "1, 3, 5, "<br>
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline(always)]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calculates the offset from a pointer using wrapping arithmetic. <br>使用换行算法计算与指针的偏移量。<br>
    /// (convenience for `.wrapping_offset((count as isize).wrapping_neg())`) <br>(为 `.wrapping_offset((count as isize).wrapping_neg())` 带来的便利)<br>
    ///
    /// `count` is in units of T; <br>`count` 以 T 为单位；<br> e.g., a `count` of 3 represents a pointer offset of `3 * size_of::<T>()` bytes. <br>例如，`count` 为 3 表示 `3 * size_of::<T>()` 字节的指针偏移量。<br>
    ///
    /// # Safety
    ///
    /// This operation itself is always safe, but using the resulting pointer is not. <br>此操作本身始终是安全的，但使用结果指针则不安全。<br>
    ///
    /// The resulting pointer "remembers" the [allocated object] that `self` points to; <br>结果指针 "remembers" 是 `self` 指向的 [分配对象][allocated object]；<br> it must not be used to read or write other allocated objects. <br>它不得用于读取或写入其他分配的对象。<br>
    ///
    /// In other words, `let z = x.wrapping_sub((x as usize) - (y as usize))` does *not* make `z` the same as `y` even if we assume `T` has size `1` and there is no overflow: `z` is still attached to the object `x` is attached to, and dereferencing it is Undefined Behavior unless `x` and `y` point into the same allocated object. <br>换句话说，即使我们假设 `T` 的大小为 `1` 并且没有溢出，`let z = x.wrapping_sub((x as usize) - (y as usize))` 不会使 `z` 与 `y` 相同: `z` 仍附加到对象 `x` 所附加的对象，并且解引用它是 Undefined Behavior，除非 `x` 和 `y` 指向同一分配的对象。<br>
    ///
    /// Compared to [`sub`], this method basically delays the requirement of staying within the same allocated object: [`sub`] is immediate Undefined Behavior when crossing object boundaries; <br>与 [`sub`] 相比，此方法从根本上延迟了留在同一分配对象内的需求: [`sub`] 是跨越对象边界时的立即未定义行为；<br> `wrapping_sub` produces a pointer but still leads to Undefined Behavior if a pointer is dereferenced when it is out-of-bounds of the object it is attached to. <br>`wrapping_sub` 产生一个指针，但如果指针超出其附加对象的范围而被解引用，则仍会导致未定义行为。<br>
    /// [`sub`] can be optimized better and is thus preferable in performance-sensitive code. <br>[`sub`] 可以更好地优化，因此在性能敏感的代码中更可取。<br>
    ///
    /// The delayed check only considers the value of the pointer that was dereferenced, not the intermediate values used during the computation of the final result. <br>延迟检查仅考虑解引用的指针的值，而不考虑最终结果计算期间使用的中间值。<br>
    /// For example, `x.wrapping_add(o).wrapping_sub(o)` is always the same as `x`. <br>例如，`x.wrapping_add(o).wrapping_sub(o)` 始终与 `x` 相同。<br> In other words, leaving the allocated object and then re-entering it later is permitted. <br>换句话说，允许离开已分配的对象，然后在以后重新输入它。<br>
    ///
    /// [`sub`]: #method.sub
    /// [allocated object]: crate::ptr#allocated-object
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // Iterate using a raw pointer in increments of two elements (backwards) <br>使用裸指针以两个元素 (backwards) 为增量进行迭代<br>
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // This loop prints "5, 3, 1, " <br>此循环打印 "5, 3, 1, "<br>
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Sets the pointer value to `ptr`. <br>将指针值设置为 `ptr`。<br>
    ///
    /// In case `self` is a (fat) pointer to an unsized type, this operation will only affect the pointer part, whereas for (thin) pointers to sized types, this has the same effect as a simple assignment. <br>如果 `self` 是指向未定义大小类型的 (fat) 指针，则此操作将仅影响指针部分，而对于指向已确定大小类型的 (thin) 指针，其作用与简单分配相同。<br>
    ///
    /// The resulting pointer will have provenance of `val`, i.e., for a fat pointer, this operation is semantically the same as creating a new fat pointer with the data pointer value of `val` but the metadata of `self`. <br>生成的指针将具有 `val` 的出处，即对于胖指针，此操作在语义上与使用 `val` 的数据指针值但 `self` 的元数据创建新的胖指针相同。<br>
    ///
    ///
    /// # Examples
    ///
    /// This function is primarily useful for allowing byte-wise pointer arithmetic on potentially fat pointers: <br>此函数主要用于允许对潜在的胖指针进行按字节指针算术运算：<br>
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = arr.as_mut_ptr() as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // will print "3" <br>将打印 "3"<br>
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SAFETY: In case of a thin pointer, this operations is identical to a simple assignment. <br>对于细指针，此操作与简单分配相同。<br>
        // In case of a fat pointer, with the current fat pointer layout implementation, the first field of such a pointer is always the data pointer, which is likewise assigned. <br>对于胖指针，在当前胖指针布局实现中，此类指针的第一个字段始终是数据指针，该指针同样被分配。<br>
        //
        //
        unsafe { *thin = val };
        self
    }

    /// Reads the value from `self` without moving it. <br>从 `self` 读取值而不移动它。<br>
    /// This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// See [`ptr::read`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read`]。<br>
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline(always)]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for ``. <br>调用者必须遵守 `` 的安全保证 ''。<br>
        unsafe { read(self) }
    }

    /// Performs a volatile read of the value from `self` without moving it. <br>对 `self` 的值进行易失性读取，而无需移动它。<br> This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
    ///
    ///
    /// See [`ptr::read_volatile`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read_volatile`]。<br>
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `read_volatile`. <br>调用者必须遵守 `read_volatile` 的安全保证。<br>
        unsafe { read_volatile(self) }
    }

    /// Reads the value from `self` without moving it. <br>从 `self` 读取值而不移动它。<br>
    /// This leaves the memory in `self` unchanged. <br>这将使 `self` 中的内存保持不变。<br>
    ///
    /// Unlike `read`, the pointer may be unaligned. <br>与 `read` 不同，指针可能未对齐。<br>
    ///
    /// See [`ptr::read_unaligned`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::read_unaligned`]。<br>
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline(always)]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `read_unaligned`. <br>调用者必须遵守 `read_unaligned` 的安全保证。<br>
        unsafe { read_unaligned(self) }
    }

    /// Copies `count * size_of<T>` bytes from `self` to `dest`. <br>将 `count * size_of<T>` 字节从 `self` 复制到 `dest`。<br>
    /// The source and destination may overlap. <br>源和目标可能会重叠。<br>
    ///
    /// NOTE: this has the *same* argument order as [`ptr::copy`]. <br>这与 [`ptr::copy`] 具有相同的参数顺序。<br>
    ///
    /// See [`ptr::copy`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy`]。<br>
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy`. <br>调用者必须遵守 `copy` 的安全保证。<br>
        unsafe { copy(self, dest, count) }
    }

    /// Copies `count * size_of<T>` bytes from `self` to `dest`. <br>将 `count * size_of<T>` 字节从 `self` 复制到 `dest`。<br>
    /// The source and destination may *not* overlap. <br>源和目标可能 *不* 重叠。<br>
    ///
    /// NOTE: this has the *same* argument order as [`ptr::copy_nonoverlapping`]. <br>这与 [`ptr::copy_nonoverlapping`] 具有相同的参数顺序。<br>
    ///
    /// See [`ptr::copy_nonoverlapping`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy_nonoverlapping`]。<br>
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy_nonoverlapping`. <br>调用者必须遵守 `copy_nonoverlapping` 的安全保证。<br>
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copies `count * size_of<T>` bytes from `src` to `self`. <br>将 `count * size_of<T>` 字节从 `src` 复制到 `self`。<br>
    /// The source and destination may overlap. <br>源和目标可能会重叠。<br>
    ///
    /// NOTE: this has the *opposite* argument order of [`ptr::copy`]. <br>这具有 [`ptr::copy`] 的 *相反* 参数顺序。<br>
    ///
    /// See [`ptr::copy`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy`]。<br>
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy`. <br>调用者必须遵守 `copy` 的安全保证。<br>
        unsafe { copy(src, self, count) }
    }

    /// Copies `count * size_of<T>` bytes from `src` to `self`. <br>将 `count * size_of<T>` 字节从 `src` 复制到 `self`。<br>
    /// The source and destination may *not* overlap. <br>源和目标可能 *不* 重叠。<br>
    ///
    /// NOTE: this has the *opposite* argument order of [`ptr::copy_nonoverlapping`]. <br>这具有 [`ptr::copy_nonoverlapping`] 的 *相反* 参数顺序。<br>
    ///
    /// See [`ptr::copy_nonoverlapping`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::copy_nonoverlapping`]。<br>
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `copy_nonoverlapping`. <br>调用者必须遵守 `copy_nonoverlapping` 的安全保证。<br>
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Executes the destructor (if any) of the pointed-to value. <br>执行指向值的析构函数 (如果有)。<br>
    ///
    /// See [`ptr::drop_in_place`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::drop_in_place`]。<br>
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: the caller must uphold the safety contract for `drop_in_place`. <br>调用者必须遵守 `drop_in_place` 的安全保证。<br>
        unsafe { drop_in_place(self) }
    }

    /// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
    ///
    ///
    /// See [`ptr::write`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::write`]。<br>
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
    #[inline(always)]
    pub const unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `write`. <br>调用者必须遵守 `write` 的安全保证。<br>
        unsafe { write(self, val) }
    }

    /// Invokes memset on the specified pointer, setting `count * size_of::<T>()` bytes of memory starting at `self` to `val`. <br>在指定的指针上调用 memset，将 `self` 开始的 `count * size_of::<T>()` 内存字节设置为 `val`。<br>
    ///
    ///
    /// See [`ptr::write_bytes`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::write_bytes`]。<br>
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
    #[inline(always)]
    pub const unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `write_bytes`. <br>调用者必须遵守 `write_bytes` 的安全保证。<br>
        unsafe { write_bytes(self, val, count) }
    }

    /// Performs a volatile write of a memory location with the given value without reading or dropping the old value. <br>使用给定值对存储单元执行易失性写操作，而无需读取或丢弃旧值。<br>
    ///
    /// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elided or reordered by the compiler across other volatile operations. <br>易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。<br>
    ///
    ///
    /// See [`ptr::write_volatile`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::write_volatile`]。<br>
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `write_volatile`. <br>调用者必须遵守 `write_volatile` 的安全保证。<br>
        unsafe { write_volatile(self, val) }
    }

    /// Overwrites a memory location with the given value without reading or dropping the old value. <br>用给定值覆盖存储位置，而无需读取或丢弃旧值。<br>
    ///
    ///
    /// Unlike `write`, the pointer may be unaligned. <br>与 `write` 不同，指针可能未对齐。<br>
    ///
    /// See [`ptr::write_unaligned`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::write_unaligned`]。<br>
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
    #[inline(always)]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `write_unaligned`. <br>调用者必须遵守 `write_unaligned` 的安全保证。<br>
        unsafe { write_unaligned(self, val) }
    }

    /// Replaces the value at `self` with `src`, returning the old value, without dropping either. <br>用 `src` 替换 `self` 处的值，返回旧值，但不丢弃任何一个。<br>
    ///
    ///
    /// See [`ptr::replace`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::replace`]。<br>
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline(always)]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `replace`. <br>调用者必须遵守 `replace` 的安全保证。<br>
        unsafe { replace(self, src) }
    }

    /// Swaps the values at two mutable locations of the same type, without deinitializing either. <br>在相同类型的两个可变位置交换值，而无需取消初始化任何一个。<br>
    /// They may overlap, unlike `mem::swap` which is otherwise equivalent. <br>它们可能重叠，这与 `mem::swap` 不同，后者在其他方面是等效的。<br>
    ///
    /// See [`ptr::swap`] for safety concerns and examples. <br>有关安全性问题和示例，请参见 [`ptr::swap`]。<br>
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_swap", issue = "83163")]
    #[inline(always)]
    pub const unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: the caller must uphold the safety contract for `swap`. <br>调用者必须遵守 `swap` 的安全保证。<br>
        unsafe { swap(self, with) }
    }

    /// Computes the offset that needs to be applied to the pointer in order to make it aligned to `align`. <br>计算为使其与 `align` 对齐而需要应用到指针的偏移量。<br>
    ///
    /// If it is not possible to align the pointer, the implementation returns `usize::MAX`. <br>如果无法对齐指针，则实现将返回 `usize::MAX`。<br>
    /// It is permissible for the implementation to *always* return `usize::MAX`. <br>允许实现 *始终* 返回 `usize::MAX`。<br>
    /// Only your algorithm's performance can depend on getting a usable offset here, not its correctness. <br>只有算法的性能可以取决于此处是否可获得可用的偏移量，而不取决于其正确性。<br>
    ///
    /// The offset is expressed in number of `T` elements, and not bytes. <br>偏移量以 `T` 元素的数量表示，而不是以字节表示。<br> The value returned can be used with the `wrapping_add` method. <br>返回的值可以与 `wrapping_add` 方法一起使用。<br>
    ///
    /// There are no guarantees whatsoever that offsetting the pointer will not overflow or go beyond the allocation that the pointer points into. <br>不能保证偏移指针不会溢出或超出指针所指向的分配范围。<br>
    ///
    /// It is up to the caller to ensure that the returned offset is correct in all terms other than alignment. <br>调用者应确保返回的偏移量在对齐方式以外的所有方面都是正确的。<br>
    ///
    /// # Panics
    ///
    /// The function panics if `align` is not a power-of-two. <br>如果 `align` 不是 2 的幂，则函数 panics。<br>
    ///
    /// # Examples
    ///
    /// Accessing adjacent `u8` as `u16` <br>将相邻的 `u8` 作为 `u16` 进行访问<br>
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // while the pointer can be aligned via `offset`, it would point outside the allocation <br>虽然指针可以通过 `offset` 对齐，但它会指向分配之外<br>
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_align_offset", issue = "90962")]
    pub const fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }

        fn rt_impl<T>(p: *mut T, align: usize) -> usize {
            // SAFETY: `align` has been checked to be a power of 2 above <br>`align` 已被检查为 2 以上的幂<br>
            unsafe { align_offset(p, align) }
        }

        const fn ctfe_impl<T>(_: *mut T, _: usize) -> usize {
            usize::MAX
        }

        // SAFETY:
        // It is permisseble for `align_offset` to always return `usize::MAX`, algorithm correctness can not depend on `align_offset` returning non-max values. <br>允许 `align_offset` 总是返回 `usize::MAX`，算法正确性不能依赖于 `align_offset` 返回的非最大值。<br>
        //
        //
        // As such the behaviour can't change after replacing `align_offset` with `usize::MAX`, only performance can. <br>因此，将 `align_offset` 替换为 `usize::MAX` 后，行为无法改变，只有性能会改变。<br>
        unsafe { intrinsics::const_eval_select((self, align), ctfe_impl, rt_impl) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Returns the length of a raw slice. <br>返回原始切片的长度。<br>
    ///
    /// The returned value is the number of **elements**, not the number of bytes. <br>返回的值是 **元素** 的数量，而不是字节数。<br>
    ///
    /// This function is safe, even when the raw slice cannot be cast to a slice reference because the pointer is null or unaligned. <br>即使原始切片由于指针为空或未对齐而无法转换为切片引用，此函数也是安全的。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline(always)]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        metadata(self)
    }

    /// Returns a raw pointer to the slice's buffer. <br>将裸指针返回到切片的缓冲区。<br>
    ///
    /// This is equivalent to casting `self` to `*mut T`, but more type-safe. <br>这等效于将 `self` 强制转换为 `*mut T`，但类型安全性更高。<br>
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline(always)]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Returns a raw pointer to an element or subslice, without doing bounds checking. <br>将裸指针返回到元素或子切片，而不进行边界检查。<br>
    ///
    /// Calling this method with an out-of-bounds index or when `self` is not dereferenceable is *[undefined behavior]* even if the resulting pointer is not used. <br>使用越界索引或当 `self` 不可解引用时调用此方法是 *[未定义行为][undefined behavior]*，即使未使用结果指针。<br>
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline(always)]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: the caller ensures that `self` is dereferenceable and `index` in-bounds. <br>调用者确保 `self` 是可解引用的，并且 `index` 在边界内。<br>
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Returns `None` if the pointer is null, or else returns a shared slice to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回共享切片到 `Some` 中包装的值。<br>
    /// In contrast to [`as_ref`], this does not require that the value has to be initialized. <br>与 [`as_ref`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the mutable counterpart see [`as_uninit_slice_mut`]. <br>对于可变的对应物，请参见 [`as_uninit_slice_mut`]。<br>
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be [valid] for reads for `ptr.len() * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>指针必须为 [有效][valid] 的，才能读取许多字节的 `ptr.len() * mem::size_of::<T>()`，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
    ///
    ///     * The entire memory range of this slice must be contained within a single [allocated object]! <br>整个内存范围必须包含在单个 [分配对象][allocated object] 内！<br>
    ///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
    ///
    ///     * The pointer must be aligned even for zero-length slices. <br>即使对于零长度的切片，指针也必须对齐。<br>
    ///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
    ///
    ///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
    ///
    /// * The total size `ptr.len() * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。<br>
    ///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get mutated (except inside `UnsafeCell`). <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能被可变的 (`UnsafeCell` 内部除外)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// See also [`slice::from_raw_parts`][]. <br>另请参见 [`slice::from_raw_parts`][]。<br>
    ///
    /// [valid]: crate::ptr#safety
    /// [allocated object]: crate::ptr#allocated-object
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: the caller must uphold the safety contract for `as_uninit_slice`. <br>调用者必须遵守 `as_uninit_slice` 的安全保证。<br>
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Returns `None` if the pointer is null, or else returns a unique slice to the value wrapped in `Some`. <br>如果指针为空，则返回 `None`，否则返回一个唯一的切片到 `Some` 中包装的值。<br>
    /// In contrast to [`as_mut`], this does not require that the value has to be initialized. <br>与 [`as_mut`] 相比，这不需要将该值初始化。<br>
    ///
    /// For the shared counterpart see [`as_uninit_slice`]. <br>有关共享副本，请参见 [`as_uninit_slice`]。<br>
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// When calling this method, you have to ensure that *either* the pointer is null *or* all of the following is true: <br>调用此方法时，您必须确保要么指针是空的，要么以下所有内容都为 true：<br>
    ///
    /// * The pointer must be [valid] for reads and writes for `ptr.len() * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>指针必须是 [有效][valid] 的才能进行 `ptr.len() * mem::size_of::<T>()` 多个字节的读取和写入，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
    ///
    ///     * The entire memory range of this slice must be contained within a single [allocated object]! <br>整个内存范围必须包含在单个 [分配对象][allocated object] 内！<br>
    ///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
    ///
    ///     * The pointer must be aligned even for zero-length slices. <br>即使对于零长度的切片，指针也必须对齐。<br>
    ///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
    ///
    ///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
    ///
    /// * The total size `ptr.len() * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `ptr.len() * mem::size_of::<T>()` 不能大于 `isize::MAX`。<br>
    ///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
    ///
    /// * You must enforce Rust's aliasing rules, since the returned lifetime `'a` is arbitrarily chosen and does not necessarily reflect the actual lifetime of the data. <br>您必须执行 Rust 的别名规则，因为返回的生命周期 `'a` 是任意选择的，不一定反映数据的实际生命周期。<br>
    ///   In particular, for the duration of this lifetime, the memory the pointer points to must not get accessed (read or written) through any other pointer. <br>特别是，在此生命周期的持续时间内，指针所指向的内存一定不能通过任何其他指针进行访问 (读取或写入)。<br>
    ///
    /// This applies even if the result of this method is unused! <br>即使未使用此方法的结果也是如此！<br>
    ///
    /// See also [`slice::from_raw_parts_mut`][]. <br>另请参见 [`slice::from_raw_parts_mut`][]。<br>
    ///
    /// [valid]: crate::ptr#safety
    /// [allocated object]: crate::ptr#allocated-object
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    #[rustc_const_unstable(feature = "const_ptr_as_ref", issue = "91822")]
    pub const unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: the caller must uphold the safety contract for `as_uninit_slice_mut`. <br>调用者必须遵守 `as_uninit_slice_mut` 的安全保证。<br>
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Equality for pointers <br>指针的相等<br>
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline(always)]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline(always)]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline(always)]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline(always)]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline(always)]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline(always)]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}
