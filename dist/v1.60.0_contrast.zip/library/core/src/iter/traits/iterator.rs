use crate::cmp::{self, Ordering};
use crate::ops::{ChangeOutputType, ControlFlow, FromResidual, Residual, Try};

use super::super::try_process;
use super::super::TrustedRandomAccessNoCoerce;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// An interface for dealing with iterators. <br>用于处理迭代器的接口。<br>
///
/// This is the main iterator trait. <br>这是主要的迭代器 trait。<br>
/// For more about the concept of iterators generally, please see the [module-level documentation]. <br>有关一般迭代器概念的更多信息，请参见 [模块级文档][module-level documentation]。<br>
/// In particular, you may want to know how to [implement `Iterator`][impl]. <br>特别是，您可能想知道如何 [实现 `Iterator`][impl]。<br>
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(notable_trait)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// The type of the elements being iterated over. <br>被迭代的元素的类型。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Advances the iterator and returns the next value. <br>推进迭代器并返回下一个值。<br>
    ///
    /// Returns [`None`] when iteration is finished. <br>迭代完成后返回 [`None`]。<br>
    /// Individual iterator implementations may choose to resume iteration, and so calling `next()` again may or may not eventually start returning [`Some(Item)`] again at some point. <br>各个迭代器的实现可能选择恢复迭代，因此再次调用 `next()` 可能会或可能不会最终在某个时候开始再次返回 [`Some(Item)`]。<br>
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A call to next() returns the next value... <br>调用 next() 返回下一个值...<br>
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... and then None once it's over. <br>然后，一旦结束，就再也没有。<br>
    /// assert_eq!(None, iter.next());
    ///
    /// // More calls may or may not return `None`. <br>更多调用可能会也可能不会返回 `None`。<br> Here, they always will. <br>在这里，他们总是会的。<br>
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Returns the bounds on the remaining length of the iterator. <br>返回迭代器剩余长度的界限。<br>
    ///
    /// Specifically, `size_hint()` returns a tuple where the first element is the lower bound, and the second element is the upper bound. <br>具体来说，`size_hint()` 返回一个元组，其中第一个元素是下界，第二个元素是上界。<br>
    ///
    /// The second half of the tuple that is returned is an <code>[Option]<[usize]></code>. <br>返回的元组的后半部分是 <code>[Option]<[usize]></code>。<br>
    /// A [`None`] here means that either there is no known upper bound, or the upper bound is larger than [`usize`]. <br>这里的 [`None`] 表示没有已知的上限，或者该上限大于 [`usize`]。<br>
    ///
    /// # Implementation notes <br>实现说明<br>
    ///
    /// It is not enforced that an iterator implementation yields the declared number of elements. <br>没有强制要求迭代器实现产生声明数量的元素。<br> A buggy iterator may yield less than the lower bound or more than the upper bound of elements. <br>buggy 迭代器的结果可能小于元素的下限，也可能大于元素的上限。<br>
    ///
    /// `size_hint()` is primarily intended to be used for optimizations such as reserving space for the elements of the iterator, but must not be trusted to e.g., omit bounds checks in unsafe code. <br>`size_hint()` 主要用于优化，例如为迭代器的元素保留空间，但不能被信任，例如省略不安全代码中的边界检查。<br>
    /// An incorrect implementation of `size_hint()` should not lead to memory safety violations. <br>`size_hint()` 的不正确实现不应导致违反内存安全性。<br>
    ///
    /// That said, the implementation should provide a correct estimation, because otherwise it would be a violation of the trait's protocol. <br>也就是说，该实现应提供正确的估计，因为否则将违反 trait 的协议。<br>
    ///
    /// The default implementation returns <code>(0, [None])</code> which is correct for any iterator. <br>默认实现返回 <code>(0, [None])</code> 这对于任何迭代器都是正确的。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// A more complex example: <br>一个更复杂的示例：<br>
    ///
    /// ```
    /// // The even numbers in the range of zero to nine. <br>介于 0 到 9 之间的偶数。<br>
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // We might iterate from zero to ten times. <br>我们可以从零迭代到十次。<br>
    /// // Knowing that it's five exactly wouldn't be possible without executing filter(). <br>不执行 filter() 就不可能知道它是 5。<br>
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Let's add five more numbers with chain() <br>让我们用 chain() 再添加五个数字<br>
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // now both bounds are increased by five <br>现在两个界限都增加了五个<br>
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Returning `None` for an upper bound: <br>返回 `None` 作为上限：<br>
    ///
    /// ```
    /// // an infinite iterator has no upper bound and the maximum possible lower bound <br>无限迭代器没有上限，最大可能下限<br>
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consumes the iterator, counting the number of iterations and returning it. <br>消耗迭代器，计算迭代次数并返回它。<br>
    ///
    /// This method will call [`next`] repeatedly until [`None`] is encountered, returning the number of times it saw [`Some`]. <br>此方法将反复调用 [`next`]，直到遇到 [`None`]，并返回它看到 [`Some`] 的次数。<br>
    /// Note that [`next`] has to be called at least once even if the iterator does not have any elements. <br>请注意，即使迭代器没有任何元素，也必须至少调用一次 [`next`]。<br>
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overflow Behavior <br>溢出行为<br>
    ///
    /// The method does no guarding against overflows, so counting elements of an iterator with more than [`usize::MAX`] elements either produces the wrong result or panics. <br>该方法无法防止溢出，因此对具有超过 [`usize::MAX`] 个元素的迭代器的元素进行计数会产生错误的结果或 panics。<br>
    ///
    /// If debug assertions are enabled, a panic is guaranteed. <br>如果启用了调试断言，则将保证 panic。<br>
    ///
    /// # Panics
    ///
    /// This function might panic if the iterator has more than [`usize::MAX`] elements. <br>如果迭代器具有多个 [`usize::MAX`] 元素，则此函数可能为 panic。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consumes the iterator, returning the last element. <br>消耗迭代器，返回最后一个元素。<br>
    ///
    /// This method will evaluate the iterator until it returns [`None`]. <br>此方法将评估迭代器，直到返回 [`None`]。<br>
    /// While doing so, it keeps track of the current element. <br>这样做时，它会跟踪当前元素。<br>
    /// After [`None`] is returned, `last()` will then return the last element it saw. <br>返回 [`None`] 之后，`last()` 将返回它看到的最后一个元素。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Advances the iterator by `n` elements. <br>通过 `n` 元素使迭代器前进。<br>
    ///
    /// This method will eagerly skip `n` elements by calling [`next`] up to `n` times until [`None`] is encountered. <br>该方法将通过最多 `n` 次调用 [`next`] 来急切地跳过 `n` 元素，直到遇到 [`None`]。<br>
    ///
    /// `advance_by(n)` will return [`Ok(())`][Ok] if the iterator successfully advances by `n` elements, or [`Err(k)`][Err] if [`None`] is encountered, where `k` is the number of elements the iterator is advanced by before running out of elements (i.e. <br>如果迭代器成功推进 `n` 个元素，则 `advance_by(n)` 将返回 [`Ok(())`][Ok]，如果遇到 [`None`]，则返回 [`Err(k)`][Err]，其中 `k` 是迭代器在用完元素之前推进的元素数 (即<br>
    /// the length of the iterator). <br>迭代器的长度)。<br>
    /// Note that `k` is always less than `n`. <br>请注意，`k` 始终小于 `n`。<br>
    ///
    /// Calling `advance_by(0)` can do meaningful work, for example [`Flatten`] can advance its outer iterator until it finds an inner iterator that is not empty, which then often allows it to return a more accurate `size_hint()` than in its initial state. <br>调用 `advance_by(0)` 可以做有意义的工作，例如 [`Flatten`] 可以推进它的外部迭代器，直到它找到一个不为空的内部迭代器，然后通常允许它返回一个比初始状态更准确的 `size_hint()`。<br>
    ///
    ///
    /// [`Flatten`]: crate::iter::Flatten
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // only `&4` was skipped <br>仅跳过 `&4`<br>
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Returns the `n`th element of the iterator. <br>返回迭代器的第 n 个元素。<br>
    ///
    /// Like most indexing operations, the count starts from zero, so `nth(0)` returns the first value, `nth(1)` the second, and so on. <br>像大多数索引操作一样，计数从零开始，因此 `nth(0)` 返回第一个值，`nth(1)` 返回第二个值，依此类推。<br>
    ///
    /// Note that all preceding elements, as well as the returned element, will be consumed from the iterator. <br>请注意，所有先前的元素以及返回的元素都将从迭代器中消耗。<br>
    /// That means that the preceding elements will be discarded, and also that calling `nth(0)` multiple times on the same iterator will return different elements. <br>这意味着前面的元素将被丢弃，并且在同一迭代器上多次调用 `nth(0)` 将返回不同的元素。<br>
    ///
    ///
    /// `nth()` will return [`None`] if `n` is greater than or equal to the length of the iterator. <br>如果 `n` 大于或等于迭代器的长度，则 `nth()` 将返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Calling `nth()` multiple times doesn't rewind the iterator: <br>多次调用 `nth()` 不会回退迭代器：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Returning `None` if there are less than `n + 1` elements: <br>如果少于 `n + 1` 个元素，则返回 `None`：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Creates an iterator starting at the same point, but stepping by the given amount at each iteration. <br>创建一个从同一点开始的迭代器，但在每次迭代时以给定的数量逐步执行。<br>
    ///
    /// Note 1: The first element of the iterator will always be returned, regardless of the step given. <br>Note 1: 无论给出的步骤如何，总是会返回迭代器的第一个元素。<br>
    ///
    /// Note 2: The time at which ignored elements are pulled is not fixed. <br>Note 2: 被忽略的元素被拉出的时间不是固定的。<br>
    /// `StepBy` behaves like the sequence `self.next()`, `self.nth(step-1)`, `self.nth(step-1)`, …, but is also free to behave like the sequence `advance_n_and_return_first(&mut self, step)`, `advance_n_and_return_first(&mut self, step)`, … Which way is used may change for some iterators for performance reasons. <br>`StepBy` 的行为类似于序列 `self.next()`, `self.nth(step-1)`, `self.nth(step-1)`,…，但也可以自由地表现成序列 `advance_n_and_return_first(&mut self, step)`, `advance_n_and_return_first(&mut self, step)`,…出于性能原因，对于某些迭代器，使用哪种方式可能会发生变化。<br>
    ///
    /// The second way will advance the iterator earlier and may consume more items. <br>第二种方法将使迭代器更早地进行，并可能消耗更多的项。<br>
    ///
    /// `advance_n_and_return_first` is the equivalent of: <br>`advance_n_and_return_first` 相当于：<br>
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, n: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if n > 1 {
    ///         iter.nth(n - 2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// The method will panic if the given step is `0`. <br>如果给定步骤为 `0`，则该方法将为 panic。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Takes two iterators and creates a new iterator over both in sequence. <br>接受两个迭代器，并依次在两个迭代器上创建一个新的迭代器。<br>
    ///
    /// `chain()` will return a new iterator which will first iterate over values from the first iterator and then over values from the second iterator. <br>`chain()` 将返回一个新的迭代器，它首先迭代第一个迭代器的值，然后迭代第二个迭代器的值。<br>
    ///
    /// In other words, it links two iterators together, in a chain. <br>换句话说，它将两个迭代器链接在一起。<br> 🔗
    ///
    /// [`once`] is commonly used to adapt a single value into a chain of other kinds of iteration. <br>[`once`] 通常用于将单个值调整为其他类型的迭代链。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Since the argument to `chain()` uses [`IntoIterator`], we can pass anything that can be converted into an [`Iterator`], not just an [`Iterator`] itself. <br>由于 `chain()` 的参数使用 [`IntoIterator`]，因此我们可以传递可以转换为 [`Iterator`] 的所有内容，而不仅仅是 [`Iterator`] 本身。<br>
    /// For example, slices (`&[T]`) implement [`IntoIterator`], and so can be passed to `chain()` directly: <br>例如，切片 (`&[T]`) 实现 [`IntoIterator`]，因此可以直接传递给 `chain()`：<br>
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// If you work with Windows API, you may wish to convert [`OsStr`] to `Vec<u16>`: <br>如果使用 Windows API，则可能希望将 [`OsStr`] 转换为 `Vec<u16>`：<br>
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' two iterators into a single iterator of pairs. <br>将两个迭代器压缩为成对的单个迭代器。<br>
    ///
    /// `zip()` returns a new iterator that will iterate over two other iterators, returning a tuple where the first element comes from the first iterator, and the second element comes from the second iterator. <br>`zip()` 返回一个新的迭代器，它将迭代其他两个迭代器，返回一个元组，其中第一个元素来自第一个迭代器，第二个元素来自第二个迭代器。<br>
    ///
    /// In other words, it zips two iterators together, into a single one. <br>换句话说，它将两个迭代器压缩在一起，形成一个单一的迭代器。<br>
    ///
    /// If either iterator returns [`None`], [`next`] from the zipped iterator will return [`None`]. <br>如果任一迭代器返回 [`None`]，则 zipped 迭代器中的 [`next`] 将返回 [`None`]。<br>
    /// If the zipped iterator has no more elements to return then each further attempt to advance it will first try to advance the first iterator at most one time and if it still yielded an item try to advance the second iterator at most one time. <br>如果 zipped 迭代器没有更多的元素要返回，那么每次进一步尝试推进它时，将首先尝试最多推进第一个迭代器一次，如果它仍然生成一个项，则尝试最多推进第二个迭代器一次。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Since the argument to `zip()` uses [`IntoIterator`], we can pass anything that can be converted into an [`Iterator`], not just an [`Iterator`] itself. <br>由于 `zip()` 的参数使用 [`IntoIterator`]，因此我们可以传递可以转换为 [`Iterator`] 的所有内容，而不仅仅是 [`Iterator`] 本身。<br>
    /// For example, slices (`&[T]`) implement [`IntoIterator`], and so can be passed to `zip()` directly: <br>例如，切片 (`&[T]`) 实现 [`IntoIterator`]，因此可以直接传递给 `zip()`：<br>
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` is often used to zip an infinite iterator to a finite one. <br>`zip()` 通常用于将无限迭代器压缩为有限迭代器。<br>
    /// This works because the finite iterator will eventually return [`None`], ending the zipper. <br>这是可行的，因为有限迭代器最终将返回 [`None`]，从而结束拉链。<br> Zipping with `(0..)` can look a lot like [`enumerate`]: <br>使用 `(0..)` 压缩看起来很像 [`enumerate`]：<br>
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// If both iterators have roughly equivalent syntax, it may be more readable to use [`zip`]: <br>如果两个迭代器的语法大致相同，则使用 [`zip`] 可能更具可读性：<br>
    ///
    /// ```
    /// use std::iter::zip;
    ///
    /// let a = [1, 2, 3];
    /// let b = [2, 3, 4];
    ///
    /// let mut zipped = zip(
    ///     a.into_iter().map(|x| x * 2).skip(1),
    ///     b.into_iter().map(|x| x * 2).skip(1),
    /// );
    ///
    /// assert_eq!(zipped.next(), Some((4, 6)));
    /// assert_eq!(zipped.next(), Some((6, 8)));
    /// assert_eq!(zipped.next(), None);
    /// ```
    ///
    /// compared to: <br>相比之下：<br>
    ///
    /// ```
    /// # let a = [1, 2, 3];
    /// # let b = [2, 3, 4];
    /// #
    /// let mut zipped = a
    ///     .into_iter()
    ///     .map(|x| x * 2)
    ///     .skip(1)
    ///     .zip(b.into_iter().map(|x| x * 2).skip(1));
    /// #
    /// # assert_eq!(zipped.next(), Some((4, 6)));
    /// # assert_eq!(zipped.next(), Some((6, 8)));
    /// # assert_eq!(zipped.next(), None);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    /// [`zip`]: crate::iter::zip
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Creates a new iterator which places a copy of `separator` between adjacent items of the original iterator. <br>创建一个新的迭代器，该迭代器将 `separator` 的副本放置在原始迭代器的相邻项之间。<br>
    ///
    /// In case `separator` does not implement [`Clone`] or needs to be computed every time, use [`intersperse_with`]. <br>如果 `separator` 未实现 [`Clone`] 或每次都需要计算，请使用 [`intersperse_with`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // The first element from `a`. <br>`a` 中的第一个元素。<br>
    /// assert_eq!(a.next(), Some(&100)); // The separator. <br>分隔符。<br>
    /// assert_eq!(a.next(), Some(&1));   // The next element from `a`. <br>`a` 中的下一个元素。<br>
    /// assert_eq!(a.next(), Some(&100)); // The separator. <br>分隔符。<br>
    /// assert_eq!(a.next(), Some(&2));   // The last element from `a`. <br>`a` 中的最后一个元素。<br>
    /// assert_eq!(a.next(), None);       // The iterator is finished. <br>迭代器完成。<br>
    /// ```
    ///
    /// `intersperse` can be very useful to join an iterator's items using a common element: <br>`intersperse` 对于使用公共元素连接迭代器的项非常有用：<br>
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Creates a new iterator which places an item generated by `separator` between adjacent items of the original iterator. <br>创建一个新的迭代器，该迭代器将 `separator` 生成的项放在原始迭代器的相邻项之间。<br>
    ///
    /// The closure will be called exactly once each time an item is placed between two adjacent items from the underlying iterator; <br>每次将一个项放置在底层迭代器的两个相邻项之间时，闭包将被精确地调用一次；<br>
    /// specifically, the closure is not called if the underlying iterator yields less than two items and after the last item is yielded. <br>具体来说，如果底层迭代器的产量少于两个项目，并且在产生最后一个项目之后，则不调用闭包。<br>
    ///
    ///
    /// If the iterator's item implements [`Clone`], it may be easier to use [`intersperse`]. <br>如果迭代器的项实现 [`Clone`]，则使用 [`intersperse`] 可能会更容易。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = [NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // The first element from `v`. <br>`v` 中的第一个元素。<br>
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator. <br>分隔符。<br>
    /// assert_eq!(it.next(), Some(NotClone(1)));  // The next element from `v`. <br>`v` 中的下一个元素。<br>
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator. <br>分隔符。<br>
    /// assert_eq!(it.next(), Some(NotClone(2)));  // The last element from from `v`. <br>来自 `v` 的最后一个元素。<br>
    /// assert_eq!(it.next(), None);               // The iterator is finished. <br>迭代器完成。<br>
    /// ```
    ///
    /// `intersperse_with` can be used in situations where the separator needs to be computed: <br>`intersperse_with` 可用于需要计算分隔符的情况：<br>
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // The closure mutably borrows its context to generate an item. <br>闭包可变地借用其上下文以生成项。<br>
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Takes a closure and creates an iterator which calls that closure on each element. <br>获取一个闭包并创建一个迭代器，该迭代器在每个元素上调用该闭包。<br>
    ///
    /// `map()` transforms one iterator into another, by means of its argument: <br>`map()` 通过其参数将一个迭代器转换为另一个迭代器：<br>
    /// something that implements [`FnMut`]. <br>实现 [`FnMut`] 的东西。<br> It produces a new iterator which calls this closure on each element of the original iterator. <br>它产生一个新的迭代器，在原始迭代器的每个元素上调用此闭包。<br>
    ///
    /// If you are good at thinking in types, you can think of `map()` like this: <br>如果您善于思考类型，则可以这样考虑 `map()`：<br>
    /// If you have an iterator that gives you elements of some type `A`, and you want an iterator of some other type `B`, you can use `map()`, passing a closure that takes an `A` and returns a `B`. <br>如果您有一个迭代器为您提供某种类型的 `A` 元素，并且您想要某种其他类型的 `B` 的迭代器，则可以使用 `map()`，传递一个需要 `A` 并返回 `B` 的闭包。<br>
    ///
    ///
    /// `map()` is conceptually similar to a [`for`] loop. <br>`map()` 在概念上类似于 [`for`] 循环。<br> However, as `map()` is lazy, it is best used when you're already working with other iterators. <br>但是，由于 `map()` 是惰性的，因此当您已经在使用其他迭代器时，最好使用 `map()`。<br>
    /// If you're doing some sort of looping for a side effect, it's considered more idiomatic to use [`for`] than `map()`. <br>如果您要进行某种循环的副作用，则认为使用 [`for`] 比使用 `map()` 更惯用。<br>
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// If you're doing some sort of side effect, prefer [`for`] to `map()`: <br>如果您正在做某种副作用，请首选 [`for`] 而不是 `map()`：<br>
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // don't do this: <br>不要这样做：<br>
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // it won't even execute, as it is lazy. <br>它甚至不会执行，因为它很懒。<br> Rust will warn you about this. <br>Rust 会就此警告您。<br>
    ///
    /// // Instead, use for: <br>而是用于：<br>
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Calls a closure on each element of an iterator. <br>在迭代器的每个元素上调用一个闭包。<br>
    ///
    /// This is equivalent to using a [`for`] loop on the iterator, although `break` and `continue` are not possible from a closure. <br>这等效于在迭代器上使用 [`for`] 循环，尽管不能从封闭包中获得 `break` 和 `continue`。<br>
    /// It's generally more idiomatic to use a `for` loop, but `for_each` may be more legible when processing items at the end of longer iterator chains. <br>通常，使用 `for` 循环更为习惯，但是在较长的迭代器链的末尾处理 Item 时，`for_each` 可能更容易理解。<br>
    ///
    /// In some cases `for_each` may also be faster than a loop, because it will use internal iteration on adapters like `Chain`. <br>在某些情况下，`for_each` 也可能比循环更快，因为它将在 `Chain` 等适配器上使用内部迭代。<br>
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// For such a small example, a `for` loop may be cleaner, but `for_each` might be preferable to keep a functional style with longer iterators: <br>对于这么小的示例，`for` 循环可能更干净，但是 `for_each` 可能更适合于保留具有较长迭代器的功能样式：<br>
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Creates an iterator which uses a closure to determine if an element should be yielded. <br>创建一个迭代器，该迭代器使用闭包确定是否应产生元素。<br>
    ///
    /// Given an element the closure must return `true` or `false`. <br>给定一个元素，闭包必须返回 `true` 或 `false`。<br> The returned iterator will yield only the elements for which the closure returns true. <br>返回的迭代器将仅生成闭包为其返回 true 的元素。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Because the closure passed to `filter()` takes a reference, and many iterators iterate over references, this leads to a possibly confusing situation, where the type of the closure is a double reference: <br>因为传递给 `filter()` 的闭包需要用一个引用，并且许多迭代器迭代引用，所以这可能导致混乱的情况，其中闭包的类型是双引用：<br>
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // need two *s! <br>需要两个 *s!<br>
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// It's common to instead use destructuring on the argument to strip away one: <br>通常在参数上使用解构来去掉一个：<br>
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // both & and * <br>& 和 *<br>
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// or both: <br>或两个：<br>
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // two &s <br>两个 &s<br>
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// of these layers. <br>这些层。<br>
    ///
    /// Note that `iter.filter(f).next()` is equivalent to `iter.find(f)`. <br>请注意，`iter.filter(f).next()` 等效于 `iter.find(f)`。<br>
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Creates an iterator that both filters and maps. <br>创建一个同时过滤和映射的迭代器。<br>
    ///
    /// The returned iterator yields only the `value`s for which the supplied closure returns `Some(value)`. <br>返回的迭代器只产生 `value`，而提供的闭包会返回 `Some(value)`。<br>
    ///
    /// `filter_map` can be used to make chains of [`filter`] and [`map`] more concise. <br>`filter_map` 可用于使 [`filter`] 和 [`map`] 的链更简洁。<br>
    /// The example below shows how a `map().filter().map()` can be shortened to a single call to `filter_map`. <br>下面的示例显示了如何将 `map().filter().map()` 缩短为 `filter_map` 的单个调用。<br>
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Here's the same example, but with [`filter`] and [`map`]: <br>这是相同的示例，但使用 [`filter`] 和 [`map`]：<br>
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Creates an iterator which gives the current iteration count as well as the next value. <br>创建一个迭代器，该迭代器给出当前迭代次数以及下一个值。<br>
    ///
    /// The iterator returned yields pairs `(i, val)`, where `i` is the current index of iteration and `val` is the value returned by the iterator. <br>返回的迭代器产生对 `(i, val)`，其中 `i` 是当前迭代索引，`val` 是迭代器返回的值。<br>
    ///
    ///
    /// `enumerate()` keeps its count as a [`usize`]. <br>`enumerate()` 保持其计数为 [`usize`]。<br>
    /// If you want to count by a different sized integer, the [`zip`] function provides similar functionality. <br>如果要使用其他大小的整数进行计数，则 [`zip`] 函数提供了类似的功能。<br>
    ///
    /// # Overflow Behavior <br>溢出行为<br>
    ///
    /// The method does no guarding against overflows, so enumerating more than [`usize::MAX`] elements either produces the wrong result or panics. <br>该方法无法防止溢出，因此枚举多个 [`usize::MAX`] 元素会产生错误的结果或 panics。<br>
    /// If debug assertions are enabled, a panic is guaranteed. <br>如果启用了调试断言，则将保证 panic。<br>
    ///
    /// # Panics
    ///
    /// The returned iterator might panic if the to-be-returned index would overflow a [`usize`]. <br>如果要返回的索引将溢出 [`usize`]，则返回的迭代器可能为 panic。<br>
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Creates an iterator which can use the [`peek`] and [`peek_mut`] methods to look at the next element of the iterator without consuming it. <br>创建一个迭代器，它可以使用 [`peek`] 和 [`peek_mut`] 方法查看迭代器的下一个元素而不消耗它。<br> See their documentation for more information. <br>有关更多信息，请参见他们的文档。<br>
    ///
    /// Note that the underlying iterator is still advanced when [`peek`] or [`peek_mut`] are called for the first time: In order to retrieve the next element, [`next`] is called on the underlying iterator, hence any side effects (i.e. <br>注意，第一次调用 [`peek`] 或 [`peek_mut`] 时，底层迭代器仍然在前进：为了检索下一个元素，在底层迭代器上调用 [`next`]，因此会产生任何副作用 (即<br>
    /// anything other than fetching the next value) of the [`next`] method will occur. <br>除了获取 [`next`] 方法的下一个值之外，其他所有操作都将发生。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lets us see into the future <br>peek() 让我们能看到未来<br>
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // we can peek() multiple times, the iterator won't advance <br>我们可以多次 peek()，迭代器不会前进<br>
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // after the iterator is finished, so is peek() <br>迭代器完成后，peek() 也是如此<br>
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Using [`peek_mut`] to mutate the next item without advancing the iterator: <br>使用 [`peek_mut`] 在不推进迭代器的情况下改变下一个项：<br>
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // `peek_mut()` lets us see into the future <br>`peek_mut()` 让我们看到了 future<br>
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// if let Some(mut p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     // put a value into the iterator <br>将一个值放入迭代器<br>
    ///     *p = &1000;
    /// }
    ///
    /// // The value reappears as the iterator continues <br>随着迭代器的继续，该值重新出现<br>
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&1000, &3]);
    /// ```
    /// [`peek`]: Peekable::peek
    /// [`peek_mut`]: Peekable::peek_mut
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Creates an iterator that [`skip`]s elements based on a predicate. <br>创建一个迭代器，该迭代器基于谓词 [`skip`] 元素。<br>
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` takes a closure as an argument. <br>`skip_while()` 将闭包作为参数。<br> It will call this closure on each element of the iterator, and ignore elements until it returns `false`. <br>它将在迭代器的每个元素上调用此闭包，并忽略元素，直到返回 `false`。<br>
    ///
    /// After `false` is returned, `skip_while()`'s job is over, and the rest of the elements are yielded. <br>返回 `false` 后，`skip_while () ` 的工作结束，并产生元素的剩余部分。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Because the closure passed to `skip_while()` takes a reference, and many iterators iterate over references, this leads to a possibly confusing situation, where the type of the closure argument is a double reference: <br>因为传递给 `skip_while()` 的闭包需要一个引用，并且许多迭代器都在引用上进行迭代，所以这会导致一种可能令人困惑的情况，其中闭包参数的类型是双引用：<br>
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // need two *s! <br>需要两个 *s!<br>
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping after an initial `false`: <br>在初始 `false` 之后停止：<br>
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // while this would have been false, since we already got a false, skip_while() isn't used any more <br>虽然这本来是错误的，但是由于我们已经得到了错误，所以不再使用 skip_while()<br>
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[doc(alias = "drop_while")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Creates an iterator that yields elements based on a predicate. <br>创建一个迭代器，该迭代器根据谓词产生元素。<br>
    ///
    /// `take_while()` takes a closure as an argument. <br>`take_while()` 将闭包作为参数。<br> It will call this closure on each element of the iterator, and yield elements while it returns `true`. <br>它将在迭代器的每个元素上调用此闭包，并在返回 `true` 时产生 yield 元素。<br>
    ///
    /// After `false` is returned, `take_while()`'s job is over, and the rest of the elements are ignored. <br>返回 `false` 后，`take_while () ` 的工作结束，并且元素的剩余部分被忽略。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Because the closure passed to `take_while()` takes a reference, and many iterators iterate over references, this leads to a possibly confusing situation, where the type of the closure is a double reference: <br>因为传递给 `take_while()` 的闭包需要用一个引用，并且许多迭代器迭代引用，所以这可能导致混乱的情况，其中闭包的类型是双引用：<br>
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // need two *s! <br>需要两个 *s!<br>
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping after an initial `false`: <br>在初始 `false` 之后停止：<br>
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // We have more elements that are less than zero, but since we already got a false, take_while() isn't used any more <br>我们有更多小于零的元素，但是由于我们已经得到了错误，因此不再使用 take_while()<br>
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Because `take_while()` needs to look at the value in order to see if it should be included or not, consuming iterators will see that it is removed: <br>因为 `take_while()` 需要查看该值以查看是否应包含它，所以使用迭代器的人将看到它已被删除：<br>
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `3` is no longer there, because it was consumed in order to see if the iteration should stop, but wasn't placed back into the iterator. <br>`3` 不再存在，因为它已被消耗以查看迭代是否应该停止，但并未放回到迭代器中。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Creates an iterator that both yields elements based on a predicate and maps. <br>创建一个迭代器，该迭代器均基于谓词和映射生成元素。<br>
    ///
    /// `map_while()` takes a closure as an argument. <br>`map_while()` 将闭包作为参数。<br>
    /// It will call this closure on each element of the iterator, and yield elements while it returns [`Some(_)`][`Some`]. <br>它将在迭代器的每个元素上调用此闭包，并在返回 [`Some(_)`][`Some`] 时产生元素。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Here's the same example, but with [`take_while`] and [`map`]: <br>这是相同的示例，但使用 [`take_while`] 和 [`map`]：<br>
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping after an initial [`None`]: <br>在初始 [`None`] 之后停止：<br>
    ///
    /// ```
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // We have more elements which could fit in u32 (4, 5), but `map_while` returned `None` for `-3` (as the `predicate` returned `None`) and `collect` stops at the first `None` encountered. <br>我们还有更多可能适合 u32 (4，5) 的元素，但是 `map_while` 为 `-3` 返回了 `None` (因为 `predicate` 返回了 `None`)，而 `collect` 在遇到的第一个 `None` 处停止。<br>
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Because `map_while()` needs to look at the value in order to see if it should be included or not, consuming iterators will see that it is removed: <br>因为 `map_while()` 需要查看该值以查看是否应包含它，所以使用迭代器的人将看到它已被删除：<br>
    ///
    ///
    /// ```
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `-3` is no longer there, because it was consumed in order to see if the iteration should stop, but wasn't placed back into the iterator. <br>`-3` 不再存在，因为它已被消耗以查看迭代是否应该停止，但并未放回到迭代器中。<br>
    ///
    /// Note that unlike [`take_while`] this iterator is **not** fused. <br>请注意，与 [`take_while`] 不同，此迭代器是不融合的。<br>
    /// It is also not specified what this iterator returns after the first [`None`] is returned. <br>还没有指定返回第一个 [`None`] 之后此迭代器返回的内容。<br>
    /// If you need fused iterator, use [`fuse`]. <br>如果需要融合迭代器，请使用 [`fuse`]。<br>
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_map_while", since = "1.57.0")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Creates an iterator that skips the first `n` elements. <br>创建一个跳过前 `n` 个元素的迭代器。<br>
    ///
    /// `skip(n)` skips elements until `n` elements are skipped or the end of the iterator is reached (whichever happens first). <br>`skip(n)` 跳过元素，直到跳过 `n` 元素或到达迭代器的末尾 (以先发生者为准)。<br> After that, all the remaining elements are yielded. <br>之后，产生所有剩余的元素。<br>
    ///
    /// In particular, if the original iterator is too short, then the returned iterator is empty. <br>特别是，如果原始迭代器太短，则返回的迭代器为空。<br>
    ///
    /// Rather than overriding this method directly, instead override the `nth` method. <br>而不是直接覆盖此方法，而是覆盖 `nth` 方法。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Creates an iterator that yields the first `n` elements, or fewer if the underlying iterator ends sooner. <br>创建一个迭代器，它产生第一个 `n` 元素，如果底层迭代器提前结束，则产生更少的元素。<br>
    ///
    /// `take(n)` yields elements until `n` elements are yielded or the end of the iterator is reached (whichever happens first). <br>`take(n)` 产生元素，直到产生 `n` 元素或到达迭代器的末尾 (以先发生者为准)。<br>
    /// The returned iterator is a prefix of length `n` if the original iterator contains at least `n` elements, otherwise it contains all of the (fewer than `n`) elements of the original iterator. <br>如果原始迭代器包含至少 `n` 个元素，则返回的迭代器是一个长度为 `n` 的前缀，否则它包含原始迭代器的所有 (少于 `n`) 个元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` is often used with an infinite iterator, to make it finite: <br>`take()` 通常与无限迭代器一起使用，以使其成为有限的：<br>
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// If less than `n` elements are available, `take` will limit itself to the size of the underlying iterator: <br>如果少于 `n` 个元素可用，`take` 会将自身限制为底层迭代器的大小：<br>
    ///
    /// ```
    /// let v = [1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator adapter similar to [`fold`] that holds internal state and produces a new iterator. <br>一个类似于 [`fold`] 的迭代器适配器，它保存内部状态并生成一个新的迭代器。<br>
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` takes two arguments: an initial value which seeds the internal state, and a closure with two arguments, the first being a mutable reference to the internal state and the second an iterator element. <br>`scan()` 有两个参数，一个初始值作为内部状态的种子，一个闭包有两个参数，第一个是：循环引用到内部状态，第二个是迭代器元素。<br>
    ///
    /// The closure can assign to the internal state to share state between iterations. <br>闭包可以分配给内部状态，以在迭代之间共享状态。<br>
    ///
    /// On iteration, the closure will be applied to each element of the iterator and the return value from the closure, an [`Option`], is yielded by the iterator. <br>迭代时，闭包将应用于迭代器的每个元素，并且闭包的返回值 [`Option`] 由迭代器产生。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // each iteration, we'll multiply the state by the element <br>每次迭代，我们将状态乘以元素<br>
    ///     *state = *state * x;
    ///
    ///     // then, we'll yield the negation of the state <br>然后，我们将得出国家的否定<br>
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Creates an iterator that works like map, but flattens nested structure. <br>创建一个迭代器，其工作方式类似于 map，但它会将嵌套的结构展平。<br>
    ///
    /// The [`map`] adapter is very useful, but only when the closure argument produces values. <br>[`map`] 适配器非常有用，但仅当闭包参数产生值时才使用。<br>
    /// If it produces an iterator instead, there's an extra layer of indirection. <br>如果它产生一个迭代器，则存在一个额外的间接层。<br>
    /// `flat_map()` will remove this extra layer on its own. <br>`flat_map()` 将自行删除这个额外的层。<br>
    ///
    /// You can think of `flat_map(f)` as the semantic equivalent of [`map`]ping, and then [`flatten`]ing as in `map(f).flatten()`. <br>您可以把 `flat_map(f)` 视为 [`map`] 的语义等价物，然后把 [`flatten`] 看作是 `map(f).flatten()`。<br>
    ///
    /// Another way of thinking about `flat_map()`: [`map`]'s closure returns one item for each element, and `flat_map()`'s closure returns an iterator for each element. <br>关于 `flat_map()` 的另一种方式: [`map`] 的闭包为每个元素返回一个项，而 `flat_map () ` 的闭包为每个元素返回一个迭代器。<br>
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returns an iterator <br>chars() 返回一个迭代器<br>
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Creates an iterator that flattens nested structure. <br>创建一个可简化嵌套结构体的迭代器。<br>
    ///
    /// This is useful when you have an iterator of iterators or an iterator of things that can be turned into iterators and you want to remove one level of indirection. <br>当您具有迭代器的迭代器或可以转换为迭代器的事物的迭代器并且要删除一个间接级别时，此功能很有用。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapping and then flattening: <br>映射然后展平：<br>
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returns an iterator <br>chars() 返回一个迭代器<br>
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// You can also rewrite this in terms of [`flat_map()`], which is preferable in this case since it conveys intent more clearly: <br>您也可以用 [`flat_map()`] 来重写它，在这种情况下最好使用 [`flat_map()`]，因为它可以更清楚地传达意图：<br>
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returns an iterator <br>chars() 返回一个迭代器<br>
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening only removes one level of nesting at a time: <br>展平一次只能删除一层嵌套：<br>
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Here we see that `flatten()` does not perform a "deep" flatten. <br>在这里，我们看到 `flatten()` 不执行深度展平。<br>
    /// Instead, only one level of nesting is removed. <br>相反，仅删除了一层嵌套。<br> That is, if you `flatten()` a three-dimensional array, the result will be two-dimensional and not one-dimensional. <br>也就是说，如果您用 `flatten()` 三维数组，则结果将是二维而不是一维的。<br>
    /// To get a one-dimensional structure, you have to `flatten()` again. <br>要获得一维结构体，您必须再次 `flatten()`。<br>
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Creates an iterator which ends after the first [`None`]. <br>创建一个迭代器，该迭代器在第一个 [`None`] 之后结束。<br>
    ///
    /// After an iterator returns [`None`], future calls may or may not yield [`Some(T)`] again. <br>迭代器返回 [`None`] 之后，future 调用可能会或可能不会再次产生 [`Some(T)`]。<br>
    /// `fuse()` adapts an iterator, ensuring that after a [`None`] is given, it will always return [`None`] forever. <br>`fuse()` 适配了一个迭代器，确保在给定 [`None`] 之后，它将永远返回 [`None`]。<br>
    ///
    ///
    /// Note that the [`Fuse`] wrapper is a no-op on iterators that implement the [`FusedIterator`] trait. <br>请注意，[`Fuse`] 包装器对实现 [`FusedIterator`] trait 的迭代器是无操作的。<br>
    /// `fuse()` may therefore behave incorrectly if the [`FusedIterator`] trait is improperly implemented. <br>因此，如果 [`FusedIterator`] trait 实现不当，`fuse()` 可能会出现错误行为。<br>
    ///
    /// [`Some(T)`]: Some
    /// [`FusedIterator`]: crate::iter::FusedIterator
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // an iterator which alternates between Some and None <br>一个在 Some 和 None 之间交替的迭代器<br>
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // if it's even, Some(i32), else None <br>如果是偶数，则为 Some(i32)，否则为 None<br>
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // we can see our iterator going back and forth <br>我们可以看到我们的迭代器来回走动<br>
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // however, once we fuse it... <br>但是，一旦我们融合了...<br>
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // it will always return `None` after the first time. <br>第一次之后它将始终返回 `None`。<br>
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Does something with each element of an iterator, passing the value on. <br>对迭代器的每个元素执行某些操作，将值传递给它。<br>
    ///
    /// When using iterators, you'll often chain several of them together. <br>使用迭代器时，通常会将其中的几个链接在一起。<br>
    /// While working on such code, you might want to check out what's happening at various parts in the pipeline. <br>在处理此类代码时，您可能想要切换到管道中各个部分的情况。<br> To do that, insert a call to `inspect()`. <br>为此，将一个调用插入 `inspect()`。<br>
    ///
    /// It's more common for `inspect()` to be used as a debugging tool than to exist in your final code, but applications may find it useful in certain situations when errors need to be logged before being discarded. <br>`inspect()` 用作调试工具要比最终代码中存在的更为普遍，但是在某些情况下，如果需要先记录错误然后丢弃，应用程序可能会发现它很有用。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // this iterator sequence is complex. <br>该迭代器序列很复杂。<br>
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // let's add some inspect() calls to investigate what's happening <br>让我们添加一些 inspect() 调用以调查正在发生的事情<br>
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// This will print: <br>这将打印：<br>
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logging errors before discarding them: <br>在丢弃错误之前记录错误：<br>
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// This will print: <br>这将打印：<br>
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Borrows an iterator, rather than consuming it. <br>借用一个迭代器，而不是使用它。<br>
    ///
    /// This is useful to allow applying iterator adapters while still retaining ownership of the original iterator. <br>这对于允许应用迭代器适配器同时仍保留原始迭代器的所有权很有用。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let mut words = ["hello", "world", "of", "Rust"].into_iter();
    ///
    /// // Take the first two words. <br>以前两个单词为例。<br>
    /// let hello_world: Vec<_> = words.by_ref().take(2).collect();
    /// assert_eq!(hello_world, vec!["hello", "world"]);
    ///
    /// // Collect the rest of the words. <br>收集剩下的单词。<br>
    /// // We can only do this because we used `by_ref` earlier. <br>我们只能这样做，因为我们之前使用了 `by_ref`。<br>
    /// let of_rust: Vec<_> = words.collect();
    /// assert_eq!(of_rust, vec!["of", "Rust"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforms an iterator into a collection. <br>将迭代器转换为集合。<br>
    ///
    /// `collect()` can take anything iterable, and turn it into a relevant collection. <br>`collect()` 可以将任何可迭代的东西变成一个相关的集合。<br>
    /// This is one of the more powerful methods in the standard library, used in a variety of contexts. <br>这是在各种上下文中使用的标准库中功能更强大的方法之一。<br>
    ///
    /// The most basic pattern in which `collect()` is used is to turn one collection into another. <br>使用 `collect()` 的最基本模式是将一个集合转换为另一个集合。<br>
    /// You take a collection, call [`iter`] on it, do a bunch of transformations, and then `collect()` at the end. <br>您进行了一个收集，在其上调用 [`iter`]，进行了一堆转换，最后添加 `collect()`。<br>
    ///
    /// `collect()` can also create instances of types that are not typical collections. <br>`collect()` 还可以创建非典型集合类型的实例。<br>
    /// For example, a [`String`] can be built from [`char`]s, and an iterator of [`Result<T, E>`][`Result`] items can be collected into `Result<Collection<T>, E>`. <br>例如，可以从 [`char`] 构建一个 [`String`]，并且可以将 [`Result<T, E>`][`Result`] 项的迭代器收集到 `Result<Collection<T>, E>` 中。<br>
    ///
    /// See the examples below for more. <br>有关更多信息，请参见下面的示例。<br>
    ///
    /// Because `collect()` is so general, it can cause problems with type inference. <br>由于 `collect()` 非常通用，因此可能导致类型推断问题。<br>
    /// As such, `collect()` is one of the few times you'll see the syntax affectionately known as the 'turbofish': `::<>`. <br>因此，`collect()` 是少数几次您会看到被亲切地称为 'turbofish': `::<>` 的语法之一。<br>
    /// This helps the inference algorithm understand specifically which collection you're trying to collect into. <br>这有助于推理算法特别了解您要收集到的集合。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Note that we needed the `: Vec<i32>` on the left-hand side. <br>请注意，我们需要在左侧使用 `: Vec<i32>`。<br> This is because we could collect into, for example, a [`VecDeque<T>`] instead: <br>这是因为我们可以代替收集到例如 [`VecDeque<T>`] 中：<br>
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Using the 'turbofish' instead of annotating `doubled`: <br>使用 'turbofish' 而不是注解 `doubled`：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Because `collect()` only cares about what you're collecting into, you can still use a partial type hint, `_`, with the turbofish: <br>因为 `collect()` 只关心您要收集的内容，所以您仍然可以将局部类型提示 `_` 与 turbfish 一起使用：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Using `collect()` to make a [`String`]: <br>使用 `collect()` 生成 [`String`]：<br>
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// If you have a list of [`Result<T, E>`][`Result`]s, you can use `collect()` to see if any of them failed: <br>如果您有 [`Result<T, E>`][`Result`]，您可以使用 `collect()` 来查看它们是否失败：<br>
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gives us the first error <br>给我们第一个错误<br>
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gives us the list of answers <br>给我们答案列表<br>
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Fallibly transforms an iterator into a collection, short circuiting if a failure is encountered. <br>错误地将迭代器转换为集合，如果遇到失败就短路。<br>
    ///
    /// `try_collect()` is a variation of [`collect()`][`collect`] that allows fallible conversions during collection. <br>`try_collect()` 是 [`collect()`][`collect`] 的变体，它允许在收集期间进行可能出错的转换。<br>
    /// Its main use case is simplifying conversions from iterators yielding [`Option<T>`][`Option`] into `Option<Collection<T>>`, or similarly for other [`Try`] types (e.g. <br>它的主要用例是简化从产生 [`Option<T>`][`Option`] 到 `Option<Collection<T>>` 的迭代器的转换，或者类似地用于其他 [`Try`] 类型 (例如<br>
    /// [`Result`]).
    ///
    /// Importantly, `try_collect()` doesn't require that the outer [`Try`] type also implements [`FromIterator`]; <br>重要的是，`try_collect()` 不需要外部 [`Try`] 类型也实现 [`FromIterator`];<br>
    /// only the inner type produced on `Try::Output` must implement it. <br>只有在 `Try::Output` 上产生的内部类型必须实现它。<br>
    /// Concretely, this means that collecting into `ControlFlow<_, Vec<i32>>` is valid because `Vec<i32>` implements [`FromIterator`], even though [`ControlFlow`] doesn't. <br>具体来说，这意味着收集到 `ControlFlow<_, Vec<i32>>` 是有效的，因为 `Vec<i32>` 实现了 [`FromIterator`]，即使 [`ControlFlow`] 没有实现。<br>
    ///
    /// Also, if a failure is encountered during `try_collect()`, the iterator is still valid and may continue to be used, in which case it will continue iterating starting after the element that triggered the failure. <br>另外，如果在 `try_collect()` 期间遇到失败，迭代器仍然有效，可以继续使用，在这种情况下，它将在触发失败的元素之后继续迭代。<br>
    /// See the last example below for an example of how this works. <br>有关其工作原理的示例，请参见下面的最后一个示例。<br>
    ///
    /// # Examples
    /// Successfully collecting an iterator of `Option<i32>` into `Option<Vec<i32>>`: <br>成功将 `Option<i32>` 的一个迭代器收集到 `Option<Vec<i32>>` 中:<br>
    ///
    /// ```
    /// #![feature(iterator_try_collect)]
    ///
    /// let u = vec![Some(1), Some(2), Some(3)];
    /// let v = u.into_iter().try_collect::<Vec<i32>>();
    /// assert_eq!(v, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Failing to collect in the same way: <br>未能以同样的方式收集:<br>
    ///
    /// ```
    /// #![feature(iterator_try_collect)]
    ///
    /// let u = vec![Some(1), Some(2), None, Some(3)];
    /// let v = u.into_iter().try_collect::<Vec<i32>>();
    /// assert_eq!(v, None);
    /// ```
    ///
    /// A similar example, but with `Result`: <br>一个类似的例子，但使用了 `Result`:<br>
    ///
    /// ```
    /// #![feature(iterator_try_collect)]
    ///
    /// let u: Vec<Result<i32, ()>> = vec![Ok(1), Ok(2), Ok(3)];
    /// let v = u.into_iter().try_collect::<Vec<i32>>();
    /// assert_eq!(v, Ok(vec![1, 2, 3]));
    ///
    /// let u = vec![Ok(1), Ok(2), Err(()), Ok(3)];
    /// let v = u.into_iter().try_collect::<Vec<i32>>();
    /// assert_eq!(v, Err(()));
    /// ```
    ///
    /// Finally, even [`ControlFlow`] works, despite the fact that it doesn't implement [`FromIterator`]. <br>最后，即使 [`ControlFlow`] 也可以工作，尽管它没有实现 [`FromIterator`]。<br> Note also that the iterator can continue to be used, even if a failure is encountered: <br>另请注意，即使遇到失败，迭代器也可以继续使用:<br>
    ///
    /// ```
    /// #![feature(iterator_try_collect)]
    ///
    /// use core::ops::ControlFlow::{Break, Continue};
    ///
    /// let u = [Continue(1), Continue(2), Break(3), Continue(4), Continue(5)];
    /// let mut it = u.into_iter();
    ///
    /// let v = it.try_collect::<Vec<_>>();
    /// assert_eq!(v, Break(3));
    ///
    /// let v = it.try_collect::<Vec<_>>();
    /// assert_eq!(v, Continue(vec![4, 5]));
    /// ```
    ///
    /// [`collect`]: Iterator::collect
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iterator_try_collect", issue = "94047")]
    fn try_collect<B>(&mut self) -> ChangeOutputType<Self::Item, B>
    where
        Self: Sized,
        <Self as Iterator>::Item: Try,
        <<Self as Iterator>::Item as Try>::Residual: Residual<B>,
        B: FromIterator<<Self::Item as Try>::Output>,
    {
        try_process(self, |i| i.collect())
    }

    /// Consumes an iterator, creating two collections from it. <br>消耗一个迭代器，从中创建两个集合。<br>
    ///
    /// The predicate passed to `partition()` can return `true`, or `false`. <br>传递给 `partition()` 的谓词可以返回 `true` 或 `false`。<br>
    /// `partition()` returns a pair, all of the elements for which it returned `true`, and all of the elements for which it returned `false`. <br>`partition()` 返回一对，它返回 `true` 的所有元素，以及它返回 `false` 的所有元素。<br>
    ///
    ///
    /// See also [`is_partitioned()`] and [`partition_in_place()`]. <br>另请参见 [`is_partitioned()`] 和 [`partition_in_place()`]。<br>
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders the elements of this iterator *in-place* according to the given predicate, such that all those that return `true` precede all those that return `false`. <br>根据给定的谓词，对迭代器的元素进行就地重新排序，以使所有返回 `true` 的元素都在所有返回 `false` 的元素之前。<br>
    /// Returns the number of `true` elements found. <br>返回找到的 `true` 元素的数量。<br>
    ///
    /// The relative order of partitioned items is not maintained. <br>未维护分区项的相对顺序。<br>
    ///
    /// # Current implementation <br>当前实现<br>
    ///
    /// Current algorithms tries finding the first element for which the predicate evaluates to false, and the last element for which it evaluates to true and repeatedly swaps them. <br>当前的算法尝试找到谓词评估为 false 的第一个元素，以及它评估为 true 的最后一个元素，并反复交换它们。<br>
    ///
    ///
    /// Time complexity: *O*(*n*) <br>时间复杂度: *O*(*n*)<br>
    ///
    /// See also [`is_partitioned()`] and [`partition()`]. <br>另请参见 [`is_partitioned()`] 和 [`partition()`]。<br>
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition in-place between evens and odds <br>在偶数和赔率之间进行适当的分区<br>
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    ///
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: should we worry about the count overflowing? <br>我们应该担心计数溢出吗？<br> The only way to have more than `usize::MAX` mutable references is with ZSTs, which aren't useful to partition... <br>拥有超过 `usize::MAX` 可变引用的唯一方法是使用 ZST，这对于分区没有用...<br>
        //

        // These closure "factory" functions exist to avoid genericity in `Self`. <br>这些闭包工厂函数的存在是为了避免 `Self` 中的泛型。<br>

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Repeatedly find the first `false` and swap it with the last `true`. <br>重复查找第一个 `false` 并将其与最后一个 `true` 交换。<br>
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Checks if the elements of this iterator are partitioned according to the given predicate, such that all those that return `true` precede all those that return `false`. <br>检查此迭代器的元素是否根据给定的谓词进行了分区，以便所有返回 `true` 的元素都在所有返回 `false` 的元素之前。<br>
    ///
    ///
    /// See also [`partition()`] and [`partition_in_place()`]. <br>另请参见 [`partition()`] 和 [`partition_in_place()`]。<br>
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Either all items test `true`, or the first clause stops at `false` and we check that there are no more `true` items after that. <br>所有项测试 `true`，或者第一个子句在 `false` 处停止，然后我们检查之后没有更多的 `true` 项。<br>
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator method that applies a function as long as it returns successfully, producing a single, final value. <br>一个迭代器方法，它只要成功返回就应用函数，并产生单个最终值。<br>
    ///
    /// `try_fold()` takes two arguments: an initial value, and a closure with two arguments: an 'accumulator', and an element. <br>`try_fold()` 有两个参数：一个初始值，一个闭包，有两个参数：一个 'accumulator' 和一个元素。<br>
    /// The closure either returns successfully, with the value that the accumulator should have for the next iteration, or it returns failure, with an error value that is propagated back to the caller immediately (short-circuiting). <br>闭包要么成功返回并返回累加器在下一次迭代中应具有的值，要么返回失败，返回错误值并立即将错误值传播回调用者 (short-circuiting)。<br>
    ///
    ///
    /// The initial value is the value the accumulator will have on the first call. <br>初始值是累加器在第一次调用时将具有的值。<br> If applying the closure succeeded against every element of the iterator, `try_fold()` returns the final accumulator as success. <br>如果对迭代器的每个元素成功应用闭包，`try_fold()` 将返回最终的累加器作为成功。<br>
    ///
    /// Folding is useful whenever you have a collection of something, and want to produce a single value from it. <br>当您拥有某个集合，并且希望从中产生单个值时，`fold` 非常有用。<br>
    ///
    /// # Note to Implementors <br>实现者注意<br>
    ///
    /// Several of the other (forward) methods have default implementations in terms of this one, so try to implement this explicitly if it can do something better than the default `for` loop implementation. <br>就此而言，其他几种 (forward) 方法都具有默认实现，因此，如果它可以做得比默认 `for` 循环实现更好，请尝试显式实现此方法。<br>
    ///
    /// In particular, try to have this call `try_fold()` on the internal parts from which this iterator is composed. <br>特别是，请尝试将此 `try_fold()` 放在组成此迭代器的内部部件上。<br>
    /// If multiple calls are needed, the `?` operator may be convenient for chaining the accumulator value along, but beware any invariants that need to be upheld before those early returns. <br>如果需要多次调用，则 `?` 运算符可能会很方便地将累加器值链接在一起，但是要提防在这些早期返回之前需要保留的所有不变量。<br>
    /// This is a `&mut self` method, so iteration needs to be resumable after hitting an error here. <br>这是一种 `&mut self` 方法，因此在此处遇到错误后需要重新开始迭代。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // the checked sum of all of the elements of the array <br>数组所有元素的校验和<br>
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // This sum overflows when adding the 100 element <br>加 100 元素时，此总和溢出<br>
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Because it short-circuited, the remaining elements are still available through the iterator. <br>由于发生短路，因此其余元素仍可通过迭代器使用。<br>
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    /// While you cannot `break` from a closure, the [`ControlFlow`] type allows a similar idea: <br>虽然您不能从 闭包 `break`，[`ControlFlow`] 类型允许类似的想法：<br>
    ///
    /// ```
    /// use std::ops::ControlFlow;
    ///
    /// let triangular = (1..30).try_fold(0_i8, |prev, x| {
    ///     if let Some(next) = prev.checked_add(x) {
    ///         ControlFlow::Continue(next)
    ///     } else {
    ///         ControlFlow::Break(prev)
    ///     }
    /// });
    /// assert_eq!(triangular, ControlFlow::Break(120));
    ///
    /// let triangular = (1..30).try_fold(0_u64, |prev, x| {
    ///     if let Some(next) = prev.checked_add(x) {
    ///         ControlFlow::Continue(next)
    ///     } else {
    ///         ControlFlow::Break(prev)
    ///     }
    /// });
    /// assert_eq!(triangular, ControlFlow::Continue(435));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Output = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator method that applies a fallible function to each item in the iterator, stopping at the first error and returning that error. <br>一个迭代器方法，该方法将一个容易犯错的函数应用于迭代器中的每个项，在第一个错误处停止并返回该错误。<br>
    ///
    ///
    /// This can also be thought of as the fallible form of [`for_each()`] or as the stateless version of [`try_fold()`]. <br>也可以将其视为 [`for_each()`] 的错误形式或 [`try_fold()`] 的无状态版本。<br>
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // It short-circuited, so the remaining items are still in the iterator: <br>它短路，因此其余项仍在迭代器中：<br>
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    /// The [`ControlFlow`] type can be used with this method for the situations in which you'd use `break` and `continue` in a normal loop: <br>[`ControlFlow`] 类型可以与此方法一起用于在正常循环中使用 `break` 和 `continue` 的情况：<br>
    ///
    /// ```
    /// use std::ops::ControlFlow;
    ///
    /// let r = (2..100).try_for_each(|x| {
    ///     if 323 % x == 0 {
    ///         return ControlFlow::Break(x)
    ///     }
    ///
    ///     ControlFlow::Continue(())
    /// });
    /// assert_eq!(r, ControlFlow::Break(17));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Output = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Folds every element into an accumulator by applying an operation, returning the final result. <br>通过应用操作将每个元素 `fold` 到一个累加器中，返回最终结果。<br>
    ///
    /// `fold()` takes two arguments: an initial value, and a closure with two arguments: an 'accumulator', and an element. <br>`fold()` 有两个参数：一个初始值，一个闭包，有两个参数：一个 'accumulator' 和一个元素。<br>
    /// The closure returns the value that the accumulator should have for the next iteration. <br>闭包返回累加器在下一次迭代中应具有的值。<br>
    ///
    /// The initial value is the value the accumulator will have on the first call. <br>初始值是累加器在第一次调用时将具有的值。<br>
    ///
    /// After applying this closure to every element of the iterator, `fold()` returns the accumulator. <br>在将此闭包应用于迭代器的每个元素之后，`fold()` 返回累加器。<br>
    ///
    /// This operation is sometimes called 'reduce' or 'inject'. <br>该操作有时称为 'reduce' 或 'inject'。<br>
    ///
    /// Folding is useful whenever you have a collection of something, and want to produce a single value from it. <br>当您拥有某个集合，并且希望从中产生单个值时，`fold` 非常有用。<br>
    ///
    /// Note: `fold()`, and similar methods that traverse the entire iterator, might not terminate for infinite iterators, even on traits for which a result is determinable in finite time. <br>`fold()` 和遍历整个迭代器的类似方法可能不会因无限迭代器而终止，即使在 traits 上，其结果在有限时间内是可确定的。<br>
    ///
    /// Note: [`reduce()`] can be used to use the first element as the initial value, if the accumulator type and item type is the same. <br>如果累加器类型和项类型相同，则可以使用 [`reduce()`] 将第一个元素用作初始值。<br>
    ///
    /// Note: `fold()` combines elements in a *left-associative* fashion. <br>`fold()` 以*左关联*方式组合元素。<br>
    /// For associative operators like `+`, the order the elements are combined in is not important, but for non-associative operators like `-` the order will affect the final result. <br>对于像 `+` 这样的关联性，元素组合的顺序并不重要，但对于像 `-` 这样的非关联性，顺序会影响最终结果。<br>
    /// For a *right-associative* version of `fold()`, see [`DoubleEndedIterator::rfold()`]. <br>对于 `fold()` 的*右关联*版本，请参见 [`DoubleEndedIterator::rfold()`]。<br>
    ///
    /// # Note to Implementors <br>实现者注意<br>
    ///
    /// Several of the other (forward) methods have default implementations in terms of this one, so try to implement this explicitly if it can do something better than the default `for` loop implementation. <br>就此而言，其他几种 (forward) 方法都具有默认实现，因此，如果它可以做得比默认 `for` 循环实现更好，请尝试显式实现此方法。<br>
    ///
    ///
    /// In particular, try to have this call `fold()` on the internal parts from which this iterator is composed. <br>特别是，请尝试将此 `fold()` 放在组成此迭代器的内部部件上。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // the sum of all of the elements of the array <br>数组所有元素的总和<br>
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Let's walk through each step of the iteration here: <br>让我们在这里遍历迭代的每个步骤：<br>
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// And so, our final result, `6`. <br>所以，我们的最终结果，`6`。<br>
    ///
    /// This example demonstrates the left-associative nature of `fold()`: <br>这个例子演示了 `fold()` 的左关联特性：<br>
    /// it builds a string, starting with an initial value and continuing with each element from the front until the back: <br>它构建一个字符串，从一个初始值开始，从前面到后面的每个元素继续：<br>
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().fold(zero, |acc, &x| {
    ///     format!("({} + {})", acc, x)
    /// });
    ///
    /// assert_eq!(result, "(((((0 + 1) + 2) + 3) + 4) + 5)");
    /// ```
    /// It's common for people who haven't used iterators a lot to use a `for` loop with a list of things to build up a result. <br>对于那些不经常使用迭代器的人，通常会使用 `for` 循环并附带一系列要建立结果的列表。<br> Those can be turned into `fold()`s: <br>那些可以变成 `fold () `s：<br>
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for loop: <br>for 循环：<br>
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // they're the same <br>他们是一样的<br>
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "inject", alias = "foldl")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduces the elements to a single one, by repeatedly applying a reducing operation. <br>通过重复应用缩减操作，将元素缩减为一个。<br>
    ///
    /// If the iterator is empty, returns [`None`]; <br>如果迭代器为空，则返回 [`None`]; 否则，返回 [`None`]。<br> otherwise, returns the result of the reduction. <br>否则，返回减少的结果。<br>
    ///
    /// The reducing function is a closure with two arguments: an 'accumulator', and an element. <br>Reduce 函数是一个闭包，有两个参数：一个 'accumulator' 和一个元素。<br>
    /// For iterators with at least one element, this is the same as [`fold()`] with the first element of the iterator as the initial accumulator value, folding every subsequent element into it. <br>对于具有至少一个元素的迭代器，这与 [`fold()`] 相同，将迭代器的第一个元素作为初始累加器值，将每个后续元素 fold 到其中。<br>
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Find the maximum value: <br>找出最大值：<br>
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|accum, item| {
    ///         if accum >= item { accum } else { item }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Reduces the elements to a single one by repeatedly applying a reducing operation. <br>通过重复应用 Reduce 操作，将元素归约为单个元素。<br>
    /// If the closure returns a failure, the failure is propagated back to the caller immediately. <br>如果闭包返回失败，则失败会立即传播给调用者。<br>
    ///
    /// The return type of this method depends on the return type of the closure. <br>此方法的返回类型取决于闭包的返回类型。<br>
    /// If the closure returns `Result<Self::Item, E>`, then this function will return `Result<Option<Self::Item>, E>`. <br>如果闭包返回 `Result<Self::Item, E>`，那么这个函数将返回 `Result<Option<Self::Item>, E>`。<br>
    /// If the closure returns `Option<Self::Item>`, then this function will return `Option<Option<Self::Item>>`. <br>如果闭包返回 `Option<Self::Item>`，那么这个函数将返回 `Option<Option<Self::Item>>`。<br>
    ///
    /// When called on an empty iterator, this function will return either `Some(None)` or `Ok(None)` depending on the type of the provided closure. <br>当调用一个空的迭代器时，这个函数将返回 `Some(None)` 或 `Ok(None)` 取决于提供的闭包的类型。<br>
    ///
    /// For iterators with at least one element, this is essentially the same as calling [`try_fold()`] with the first element of the iterator as the initial accumulator value. <br>对于至少有一个元素的迭代器，这本质上与使用迭代器的第一个元素作为初始累加器值调用 [`try_fold()`] 相同。<br>
    ///
    ///
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// Safely calculate the sum of a series of numbers: <br>安全地计算一系列数字的总和：<br>
    ///
    /// ```
    /// #![feature(iterator_try_reduce)]
    ///
    /// let numbers: Vec<usize> = vec![10, 20, 5, 23, 0];
    /// let sum = numbers.into_iter().try_reduce(|x, y| x.checked_add(y));
    /// assert_eq!(sum, Some(Some(58)));
    /// ```
    ///
    /// Determine when a reduction short circuited: <br>确定什么时候 reduction 短路：<br>
    ///
    /// ```
    /// #![feature(iterator_try_reduce)]
    ///
    /// let numbers = vec![1, 2, 3, usize::MAX, 4, 5];
    /// let sum = numbers.into_iter().try_reduce(|x, y| x.checked_add(y));
    /// assert_eq!(sum, None);
    /// ```
    ///
    /// Determine when a reduction was not performed because there are no elements: <br>确定在什么情况下没有 reduction，因为没有元素：<br>
    ///
    /// ```
    /// #![feature(iterator_try_reduce)]
    ///
    /// let numbers: Vec<usize> = Vec::new();
    /// let sum = numbers.into_iter().try_reduce(|x, y| x.checked_add(y));
    /// assert_eq!(sum, Some(None));
    /// ```
    ///
    /// Use a [`Result`] instead of an [`Option`]: <br>使用 [`Result`] 而不是 [`Option`]：<br>
    ///
    /// ```
    /// #![feature(iterator_try_reduce)]
    ///
    /// let numbers = vec!["1", "2", "3", "4", "5"];
    /// let max: Result<Option<_>, <usize as std::str::FromStr>::Err> =
    ///     numbers.into_iter().try_reduce(|x, y| {
    ///         if x.parse::<usize>()? > y.parse::<usize>()? { Ok(x) } else { Ok(y) }
    ///     });
    /// assert_eq!(max, Ok(Some("5")));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iterator_try_reduce", reason = "new API", issue = "87053")]
    fn try_reduce<F, R>(&mut self, f: F) -> ChangeOutputType<R, Option<R::Output>>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> R,
        R: Try<Output = Self::Item>,
        R::Residual: Residual<Option<Self::Item>>,
    {
        let first = match self.next() {
            Some(i) => i,
            None => return Try::from_output(None),
        };

        match self.try_fold(first, f).branch() {
            ControlFlow::Break(r) => FromResidual::from_residual(r),
            ControlFlow::Continue(i) => Try::from_output(Some(i)),
        }
    }

    /// Tests if every element of the iterator matches a predicate. <br>测试迭代器的每个元素是否与谓词匹配。<br>
    ///
    /// `all()` takes a closure that returns `true` or `false`. <br>`all()` 接受一个返回 `true` 或 `false` 的闭包。<br> It applies this closure to each element of the iterator, and if they all return `true`, then so does `all()`. <br>它将这个闭包应用于迭代器的每个元素，如果它们都返回 `true`，那么 `all()` 也返回。<br>
    /// If any of them return `false`, it returns `false`. <br>如果它们中的任何一个返回 `false`，则返回 `false`。<br>
    ///
    /// `all()` is short-circuiting; <br>`all()` 是短路的；<br> in other words, it will stop processing as soon as it finds a `false`, given that no matter what else happens, the result will also be `false`. <br>换句话说，它一旦找到 `false` 就会停止处理，因为无论发生什么，结果也将是 `false`。<br>
    ///
    ///
    /// An empty iterator returns `true`. <br>空的迭代器将返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stopping at the first `false`: <br>在第一个 `false` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tests if any element of the iterator matches a predicate. <br>测试迭代器的任何元素是否与谓词匹配。<br>
    ///
    /// `any()` takes a closure that returns `true` or `false`. <br>`any()` 接受一个返回 `true` 或 `false` 的闭包。<br> It applies this closure to each element of the iterator, and if any of them return `true`, then so does `any()`. <br>它将这个闭包应用于迭代器的每个元素，如果它们中的任何一个返回 `true`，那么 `any()` 也是如此。<br>
    /// If they all return `false`, it returns `false`. <br>如果它们都返回 `false`，则返回 `false`。<br>
    ///
    /// `any()` is short-circuiting; <br>`any()` 是短路的；<br> in other words, it will stop processing as soon as it finds a `true`, given that no matter what else happens, the result will also be `true`. <br>换句话说，它一旦找到 `true` 就会停止处理，因为无论发生什么，结果也将是 `true`。<br>
    ///
    ///
    /// An empty iterator returns `false`. <br>空的迭代器将返回 `false`。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stopping at the first `true`: <br>在第一个 `true` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Searches for an element of an iterator that satisfies a predicate. <br>搜索满足谓词的迭代器的元素。<br>
    ///
    /// `find()` takes a closure that returns `true` or `false`. <br>`find()` 接受一个返回 `true` 或 `false` 的闭包。<br>
    /// It applies this closure to each element of the iterator, and if any of them return `true`, then `find()` returns [`Some(element)`]. <br>它将这个闭包应用于迭代器的每个元素，如果其中任何一个返回 `true`，则 `find()` 返回 [`Some(element)`]。<br>
    /// If they all return `false`, it returns [`None`]. <br>如果它们都返回 `false`，则返回 [`None`]。<br>
    ///
    /// `find()` is short-circuiting; <br>`find()` 是短路的；<br> in other words, it will stop processing as soon as the closure returns `true`. <br>换句话说，一旦闭包返回 `true`，它将立即停止处理。<br>
    ///
    /// Because `find()` takes a reference, and many iterators iterate over references, this leads to a possibly confusing situation where the argument is a double reference. <br>由于 `find()` 接受 quot，并且许多迭代器迭代 quot，因此导致参数为双 quot 的情况可能令人困惑。<br>
    ///
    /// You can see this effect in the examples below, with `&&x`. <br>在 `&&x` 的以下示例中，您可以看到这种效果。<br>
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopping at the first `true`: <br>在第一个 `true` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Note that `iter.find(f)` is equivalent to `iter.filter(f).next()`. <br>请注意，`iter.find(f)` 等效于 `iter.filter(f).next()`。<br>
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Applies function to the elements of iterator and returns the first non-none result. <br>将函数应用于迭代器的元素，并返回第一个非 None 的结果。<br>
    ///
    ///
    /// `iter.find_map(f)` is equivalent to `iter.filter_map(f).next()`. <br>`iter.find_map(f)` 相当于 `iter.filter_map(f).next()`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Applies function to the elements of iterator and returns the first true result or the first error. <br>将函数应用于迭代器的元素，并返回第一个为 true 的结果或第一个错误。<br>
    ///
    /// The return type of this method depends on the return type of the closure. <br>此方法的返回类型取决于闭包的返回类型。<br>
    /// If you return `Result<bool, E>` from the closure, you'll get a `Result<Option<Self::Item>; <br>如果您从闭包中返回 `Result<bool, E>`，您会得到一个 `Result <Option<Self::Item>；<br> E>`.
    /// If you return `Option<bool>` from the closure, you'll get an `Option<Option<Self::Item>>`. <br>如果您从闭包中返回 `Option<bool>`，您会得到一个 `Option<Option<Self::Item>>`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    ///
    /// This also supports other types which implement `Try`, not just `Result`. <br>这也支持实现 `Try` 的其他类型，而不仅仅是 `Result`。<br>
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// use std::num::NonZeroU32;
    /// let a = [3, 5, 7, 4, 9, 0, 11];
    /// let result = a.iter().try_find(|&&x| NonZeroU32::new(x).map(|y| y.is_power_of_two()));
    /// assert_eq!(result, Some(Some(&4)));
    /// let result = a.iter().take(3).try_find(|&&x| NonZeroU32::new(x).map(|y| y.is_power_of_two()));
    /// assert_eq!(result, Some(None));
    /// let result = a.iter().rev().try_find(|&&x| NonZeroU32::new(x).map(|y| y.is_power_of_two()));
    /// assert_eq!(result, None);
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> ChangeOutputType<R, Option<Self::Item>>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Output = bool>,
        R::Residual: Residual<Option<Self::Item>>,
    {
        #[inline]
        fn check<I, V, R>(
            mut f: impl FnMut(&I) -> V,
        ) -> impl FnMut((), I) -> ControlFlow<R::TryType>
        where
            V: Try<Output = bool, Residual = R>,
            R: Residual<Option<I>>,
        {
            move |(), x| match f(&x).branch() {
                ControlFlow::Continue(false) => ControlFlow::CONTINUE,
                ControlFlow::Continue(true) => ControlFlow::Break(Try::from_output(Some(x))),
                ControlFlow::Break(r) => ControlFlow::Break(FromResidual::from_residual(r)),
            }
        }

        match self.try_fold((), check(f)) {
            ControlFlow::Break(x) => x,
            ControlFlow::Continue(()) => Try::from_output(None),
        }
    }

    /// Searches for an element in an iterator, returning its index. <br>在迭代器中搜索元素，并返回其索引。<br>
    ///
    /// `position()` takes a closure that returns `true` or `false`. <br>`position()` 接受一个返回 `true` 或 `false` 的闭包。<br>
    /// It applies this closure to each element of the iterator, and if one of them returns `true`, then `position()` returns [`Some(index)`]. <br>它将这个闭包应用于迭代器的每个元素，如果其中一个返回 `true`，则 `position()` 返回 [`Some(index)`]。<br>
    /// If all of them return `false`, it returns [`None`]. <br>如果它们全部返回 `false`，则返回 [`None`]。<br>
    ///
    /// `position()` is short-circuiting; <br>`position()` 是短路的；<br> in other words, it will stop processing as soon as it finds a `true`. <br>换句话说，它会在找到 `true` 后立即停止处理。<br>
    ///
    /// # Overflow Behavior <br>溢出行为<br>
    ///
    /// The method does no guarding against overflows, so if there are more than [`usize::MAX`] non-matching elements, it either produces the wrong result or panics. <br>该方法无法防止溢出，因此，如果存在多个不匹配的 [`usize::MAX`] 元素，则会产生错误的结果或 panics。<br>
    ///
    /// If debug assertions are enabled, a panic is guaranteed. <br>如果启用了调试断言，则将保证 panic。<br>
    ///
    /// # Panics
    ///
    /// This function might panic if the iterator has more than `usize::MAX` non-matching elements. <br>如果迭代器具有多个 `usize::MAX` 不匹配元素，则此函数可能为 panic。<br>
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stopping at the first `true`: <br>在第一个 `true` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // The returned index depends on iterator state <br>返回的索引取决于迭代器状态<br>
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Searches for an element in an iterator from the right, returning its index. <br>从右侧搜索迭代器中的元素，并返回其索引。<br>
    ///
    /// `rposition()` takes a closure that returns `true` or `false`. <br>`rposition()` 接受一个返回 `true` 或 `false` 的闭包。<br>
    /// It applies this closure to each element of the iterator, starting from the end, and if one of them returns `true`, then `rposition()` returns [`Some(index)`]. <br>将从结束开始将此闭包应用于迭代器的每个元素，如果其中一个返回 `true`，则 `rposition()` 返回 [`Some(index)`]。<br>
    ///
    /// If all of them return `false`, it returns [`None`]. <br>如果它们全部返回 `false`，则返回 [`None`]。<br>
    ///
    /// `rposition()` is short-circuiting; <br>`rposition()` 是短路的；<br> in other words, it will stop processing as soon as it finds a `true`. <br>换句话说，它会在找到 `true` 后立即停止处理。<br>
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stopping at the first `true`: <br>在第一个 `true` 处停止：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // we can still use `iter`, as there are more elements. <br>我们仍然可以使用 `iter`，因为还有更多元素。<br>
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // No need for an overflow check here, because `ExactSizeIterator` implies that the number of elements fits into a `usize`. <br>这里不需要进行溢出检查，因为 `ExactSizeIterator` 表示元素数量适合 `usize`。<br>
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Returns the maximum element of an iterator. <br>返回迭代器的最大元素。<br>
    ///
    /// If several elements are equally maximum, the last element is returned. <br>如果几个元素最大相等，则返回最后一个元素。<br> If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// Note that [`f32`]/[`f64`] doesn't implement [`Ord`] due to NaN being incomparable. <br>请注意，由于 NaN 不可比较，[`f32`]/[`f64`] 没有实现 [`Ord`]。<br>
    /// You can work around this by using [`Iterator::reduce`]: <br>您可以使用 [`Iterator::reduce`] 解决此问题：<br>
    ///
    /// ```
    /// assert_eq!(
    ///     [2.4, f32::NAN, 1.3]
    ///         .into_iter()
    ///         .reduce(f32::max)
    ///         .unwrap(),
    ///     2.4
    /// );
    /// ```
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Returns the minimum element of an iterator. <br>返回迭代器的最小元素。<br>
    ///
    /// If several elements are equally minimum, the first element is returned. <br>如果几个元素相等地最小，则返回第一个元素。<br>
    /// If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// Note that [`f32`]/[`f64`] doesn't implement [`Ord`] due to NaN being incomparable. <br>请注意，由于 NaN 不可比较，[`f32`]/[`f64`] 没有实现 [`Ord`]。<br> You can work around this by using [`Iterator::reduce`]: <br>您可以使用 [`Iterator::reduce`] 解决此问题：<br>
    ///
    /// ```
    /// assert_eq!(
    ///     [2.4, f32::NAN, 1.3]
    ///         .into_iter()
    ///         .reduce(f32::min)
    ///         .unwrap(),
    ///     1.3
    /// );
    /// ```
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returns the element that gives the maximum value from the specified function. <br>返回给出指定函数最大值的元素。<br>
    ///
    ///
    /// If several elements are equally maximum, the last element is returned. <br>如果几个元素最大相等，则返回最后一个元素。<br>
    /// If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Returns the element that gives the maximum value with respect to the specified comparison function. <br>返回给出相对于指定比较函数的最大值的元素。<br>
    ///
    ///
    /// If several elements are equally maximum, the last element is returned. <br>如果几个元素最大相等，则返回最后一个元素。<br>
    /// If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Returns the element that gives the minimum value from the specified function. <br>返回给出指定函数中最小值的元素。<br>
    ///
    ///
    /// If several elements are equally minimum, the first element is returned. <br>如果几个元素相等地最小，则返回第一个元素。<br>
    /// If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Returns the element that gives the minimum value with respect to the specified comparison function. <br>返回给出相对于指定比较函数的最小值的元素。<br>
    ///
    ///
    /// If several elements are equally minimum, the first element is returned. <br>如果几个元素相等地最小，则返回第一个元素。<br>
    /// If the iterator is empty, [`None`] is returned. <br>如果迭代器为空，则返回 [`None`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses an iterator's direction. <br>反转迭代器的方向。<br>
    ///
    /// Usually, iterators iterate from left to right. <br>通常，迭代器从左到右进行迭代。<br>
    /// After using `rev()`, an iterator will instead iterate from right to left. <br>使用 `rev()` 之后，迭代器将改为从右向左进行迭代。<br>
    ///
    /// This is only possible if the iterator has an end, so `rev()` only works on [`DoubleEndedIterator`]s. <br>仅在迭代器具有结束符的情况下才有可能，因此 `rev()` 仅适用于 [`DoubleEndedIterator`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converts an iterator of pairs into a pair of containers. <br>将成对的迭代器转换为一对容器。<br>
    ///
    /// `unzip()` consumes an entire iterator of pairs, producing two collections: one from the left elements of the pairs, and one from the right elements. <br>`unzip()` 消耗整个对的迭代器，产生两个集合：一个来自对的左侧元素，一个来自右侧元素。<br>
    ///
    ///
    /// This function is, in some sense, the opposite of [`zip`]. <br>从某种意义上说，该函数与 [`zip`] 相反。<br>
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [(1, 2), (3, 4), (5, 6)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3, 5]);
    /// assert_eq!(right, [2, 4, 6]);
    ///
    /// // you can also unzip multiple nested tuples at once <br>您还可以一次解压缩多个嵌套元组<br>
    /// let a = [(1, (2, 3)), (4, (5, 6))];
    ///
    /// let (x, (y, z)): (Vec<_>, (Vec<_>, Vec<_>)) = a.iter().cloned().unzip();
    /// assert_eq!(x, [1, 4]);
    /// assert_eq!(y, [2, 5]);
    /// assert_eq!(z, [3, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        let mut unzipped: (FromA, FromB) = Default::default();
        unzipped.extend(self);
        unzipped
    }

    /// Creates an iterator which copies all of its elements. <br>创建一个迭代器，该迭代器将复制其所有元素。<br>
    ///
    /// This is useful when you have an iterator over `&T`, but you need an iterator over `T`. <br>当在 `&T` 上具有迭代器，但在 `T` 上需要迭代器时，此功能很有用。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copied is the same as .map(|&x| x) <br>复制的与 .map(|&x| x) 相同<br>
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Creates an iterator which [`clone`]s all of its elements. <br>创建一个迭代器，该迭代器将克隆所有元素。<br>
    ///
    /// This is useful when you have an iterator over `&T`, but you need an iterator over `T`. <br>当在 `&T` 上具有迭代器，但在 `T` 上需要迭代器时，此功能很有用。<br>
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned is the same as .map(|&x| x), for integers <br>对于整数，cloneed 与 .map(|&x| x) 相同<br>
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repeats an iterator endlessly. <br>不断重复的迭代器。<br>
    ///
    /// Instead of stopping at [`None`], the iterator will instead start again, from the beginning. <br>迭代器不会在 [`None`] 处停止，而是会从头开始重新启动。<br> After iterating again, it will start at the beginning again. <br>再次迭代后，它将再次从头开始。<br> And again. <br>然后再次。<br>
    /// And again. <br>然后再次。<br>
    /// Forever.
    /// Note that in case the original iterator is empty, the resulting iterator will also be empty. <br>请注意，如果原始迭代器为空，则生成的迭代器也将为空。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sums the elements of an iterator. <br>对迭代器的元素求和。<br>
    ///
    /// Takes each element, adds them together, and returns the result. <br>获取每个元素，将它们添加在一起，然后返回结果。<br>
    ///
    /// An empty iterator returns the zero value of the type. <br>空的迭代器将返回该类型的零值。<br>
    ///
    /// # Panics
    ///
    /// When calling `sum()` and a primitive integer type is being returned, this method will panic if the computation overflows and debug assertions are enabled. <br>当调用 `sum()` 并返回原始整数类型时，如果计算溢出并且启用了调试断言，则此方法将为 panic。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates over the entire iterator, multiplying all the elements <br>遍历整个迭代器，将所有元素相乘<br>
    ///
    /// An empty iterator returns the one value of the type. <br>空的迭代器将返回该类型的一个值。<br>
    ///
    /// # Panics
    ///
    /// When calling `product()` and a primitive integer type is being returned, method will panic if the computation overflows and debug assertions are enabled. <br>当调用 `product()` 并返回原始整数类型时，如果计算溢出并且启用了调试断言，则方法将为 panic。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares the elements of this [`Iterator`] with those of another. <br>[字典顺序](Ord#lexicographical-comparison) 将这个 [`Iterator`] 的元素与另一个的元素进行比较。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares the elements of this [`Iterator`] with those of another with respect to the specified comparison function. <br>[字典顺序](Ord#lexicographical-comparison) 根据指定的比较函数将这个 [`Iterator`] 的元素与另一个 [`Iterator`] 的元素进行比较。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares the elements of this [`Iterator`] with those of another. <br>[字典顺序](Ord#lexicographical-comparison) 将这个 [`Iterator`] 的元素与另一个的元素进行比较。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares the elements of this [`Iterator`] with those of another with respect to the specified comparison function. <br>[字典顺序](Ord#lexicographical-comparison) 根据指定的比较函数将这个 [`Iterator`] 的元素与另一个 [`Iterator`] 的元素进行比较。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determines if the elements of this [`Iterator`] are equal to those of another. <br>确定此 [`Iterator`] 的元素是否与另一个元素相同。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determines if the elements of this [`Iterator`] are equal to those of another with respect to the specified equality function. <br>关于指定的相等函数，确定 [`Iterator`] 的元素是否与另一个元素相等。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determines if the elements of this [`Iterator`] are unequal to those of another. <br>确定此 [`Iterator`] 的元素是否与另一个元素不相等。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determines if the elements of this [`Iterator`] are [lexicographically](Ord#lexicographical-comparison) less than those of another. <br>确定此 [`Iterator`] 的元素是否比另一个元素少 [按字典顺序](Ord#lexicographical-comparison)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determines if the elements of this [`Iterator`] are [lexicographically](Ord#lexicographical-comparison) less or equal to those of another. <br>确定此 [`Iterator`] 的元素是否 [按字典顺序](Ord#lexicographical-comparison) 小于或等于另一个元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determines if the elements of this [`Iterator`] are [lexicographically](Ord#lexicographical-comparison) greater than those of another. <br>确定此 [`Iterator`] 的元素是否大于另一个元素的 [按字典顺序](Ord#lexicographical-comparison)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determines if the elements of this [`Iterator`] are [lexicographically](Ord#lexicographical-comparison) greater than or equal to those of another. <br>确定此 [`Iterator`] 的元素是否 [按字典顺序](Ord#lexicographical-comparison) 大于或等于另一个元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Checks if the elements of this iterator are sorted. <br>检查此迭代器的元素是否已排序。<br>
    ///
    /// That is, for each element `a` and its following element `b`, `a <= b` must hold. <br>也就是说，对于每个元素 `a` 及其后续元素 `b`，`a <= b` 必须成立。<br> If the iterator yields exactly zero or one element, `true` is returned. <br>如果迭代器的结果恰好为零或一个元素，则返回 `true`。<br>
    ///
    /// Note that if `Self::Item` is only `PartialOrd`, but not `Ord`, the above definition implies that this function returns `false` if any two consecutive items are not comparable. <br>请注意，如果 `Self::Item` 仅是 `PartialOrd`，而不是 `Ord`，则上述定义意味着，如果任何两个连续的项都不具有可比性，则此函数将返回 `false`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Checks if the elements of this iterator are sorted using the given comparator function. <br>检查此迭代器的元素是否使用给定的比较器函数进行排序。<br>
    ///
    /// Instead of using `PartialOrd::partial_cmp`, this function uses the given `compare` function to determine the ordering of two elements. <br>该函数使用给定的 `compare` 函数来确定两个元素的顺序，而不是使用 `PartialOrd::partial_cmp`。<br>
    /// Apart from that, it's equivalent to [`is_sorted`]; <br>除此之外，它等效于 [`is_sorted`]。<br> see its documentation for more information. <br>有关更多信息，请参见其文档。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Checks if the elements of this iterator are sorted using the given key extraction function. <br>检查此迭代器的元素是否使用给定的键提取函数进行排序。<br>
    ///
    /// Instead of comparing the iterator's elements directly, this function compares the keys of the elements, as determined by `f`. <br>该函数不直接比较迭代器的元素，而是比较元素的键 (由 `f` 确定)。<br>
    /// Apart from that, it's equivalent to [`is_sorted`]; <br>除此之外，它等效于 [`is_sorted`]。<br> see its documentation for more information. <br>有关更多信息，请参见其文档。<br>
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// See [TrustedRandomAccess][super::super::TrustedRandomAccess] <br>请参见 [TrustedRandomAccess][super::super::TrustedRandomAccess]<br>
    // The unusual name is to avoid name collisions in method resolution see #76479. <br>不寻常的名称是为了避免方法解析中的名称冲突，请参见 #76479。<br>
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccessNoCoerce,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}
