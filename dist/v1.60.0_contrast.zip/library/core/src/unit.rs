use crate::iter::FromIterator;

/// Collapses all unit items from an iterator into one. <br>将一个迭代器中的所有 unit 项折叠为一个。<br>
///
/// This is more useful when combined with higher-level abstractions, like collecting to a `Result<(), E>` where you only care about errors: <br>与更高级别的抽象结合使用时，此功能尤其有用，例如收集到仅关心错误的 `Result<(), E>` 上：<br>
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}
