use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// A memory allocator that can be registered as the standard library’s default through the `#[global_allocator]` attribute. <br>可以通过 `#[global_allocator]` 属性将其分配为标准库的默认内存分配器。<br>
///
/// Some of the methods require that a memory block be *currently allocated* via an allocator. <br>某些方法要求通过分配器 *currently* 分配存储块。<br> This means that: <br>这意味着：<br>
///
/// * the starting address for that memory block was previously returned by a previous call to an allocation method such as `alloc`, and <br>该存储块的起始地址先前是由先前的调用返回到诸如 `alloc` 的分配方法的，并且<br>
///
/// * the memory block has not been subsequently deallocated, where blocks are deallocated either by being passed to a deallocation method such as `dealloc` or by being passed to a reallocation method that returns a non-null pointer. <br>内存块尚未随后被释放，而是通过传递给诸如 `dealloc` 的释放方法或传递给返回非空指针的重新分配方法来对块进行释放。<br>
///
///
/// # Example
///
/// ```
/// use std::alloc::{GlobalAlloc, Layout};
/// use std::cell::UnsafeCell;
/// use std::ptr::null_mut;
/// use std::sync::atomic::{
///     AtomicUsize,
///     Ordering::{Acquire, SeqCst},
/// };
///
/// const ARENA_SIZE: usize = 128 * 1024;
/// const MAX_SUPPORTED_ALIGN: usize = 4096;
/// #[repr(C, align(4096))] // 4096 == MAX_SUPPORTED_ALIGN
/// struct SimpleAllocator {
///     arena: UnsafeCell<[u8; ARENA_SIZE]>,
///     remaining: AtomicUsize, // we allocate from the top, counting down <br>我们从顶部分配，倒计时<br>
/// }
///
/// #[global_allocator]
/// static ALLOCATOR: SimpleAllocator = SimpleAllocator {
///     arena: UnsafeCell::new([0x55; ARENA_SIZE]),
///     remaining: AtomicUsize::new(ARENA_SIZE),
/// };
///
/// unsafe impl Sync for SimpleAllocator {}
///
/// unsafe impl GlobalAlloc for SimpleAllocator {
///     unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
///         let size = layout.size();
///         let align = layout.align();
///
///         // `Layout` contract forbids making a `Layout` with align=0, or align not power of 2. <br>`Layout` 契约禁止使用 align=0 或 align 不是 2 的幂进行 `Layout`。<br>
///         // So we can safely use a mask to ensure alignment without worrying about UB. <br>所以我们可以放心地使用掩码来确保对齐，而不必担心 UB。<br>
///         let align_mask_to_round_down = !(align - 1);
///
///         if align > MAX_SUPPORTED_ALIGN {
///             return null_mut();
///         }
///
///         let mut allocated = 0;
///         if self
///             .remaining
///             .fetch_update(SeqCst, SeqCst, |mut remaining| {
///                 if size > remaining {
///                     return None;
///                 }
///                 remaining -= size;
///                 remaining &= align_mask_to_round_down;
///                 allocated = remaining;
///                 Some(remaining)
///             })
///             .is_err()
///         {
///             return null_mut();
///         };
///         (self.arena.get() as *mut u8).add(allocated)
///     }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// fn main() {
///     let _s = format!("allocating a string!");
///     let currently = ALLOCATOR.remaining.load(Acquire);
///     println!("allocated so far: {}", ARENA_SIZE - currently);
/// }
/// ```
///
/// # Safety
///
/// The `GlobalAlloc` trait is an `unsafe` trait for a number of reasons, and implementors must ensure that they adhere to these contracts: <br>由于多种原因，`GlobalAlloc` trait 是 `unsafe` trait，实现者必须确保遵守以下契约：<br>
///
/// * It's undefined behavior if global allocators unwind. <br>如果分配器解散，这是未定义的行为。<br> This restriction may be lifted in the future, but currently a panic from any of these functions may lead to memory unsafety. <br>可以在 future 中取消此限制，但是当前来自任何这些函数的 panic 都可能导致内存不安全。<br>
///
/// * `Layout` queries and calculations in general must be correct. <br>`Layout` 查询和计算一般情况下必须是正确的。<br> Callers of this trait are allowed to rely on the contracts defined on each method, and implementors must ensure such contracts remain true. <br>允许 trait 的调用者依赖于每种方法上定义的协定，实现者必须确保此类协定保持正确。<br>
///
/// * You must not rely on allocations actually happening, even if there are explicit heap allocations in the source. <br>您不能依赖实际发生的分配，即使源中有显式的堆分配。<br>
/// The optimizer may detect unused allocations that it can either eliminate entirely or move to the stack and thus never invoke the allocator. <br>优化器可能会检测到未使用的分配，该分配器可以将其完全消除或移到栈，因此从不调用分配器。<br>
/// The optimizer may further assume that allocation is infallible, so code that used to fail due to allocator failures may now suddenly work because the optimizer worked around the need for an allocation. <br>优化器可能进一步假设分配是无误的，因此由于分配器故障而导致分配器失败的代码现在可能突然起作用，因为优化器解决了分配需求。<br>
/// More concretely, the following code example is unsound, irrespective of whether your custom allocator allows counting how many allocations have happened. <br>更具体地说，无论您的自定义分配器是否允许计算发生了多少分配，下面的代码示例都是不正确的。<br>
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Note that the optimizations mentioned above are not the only optimization that can be applied. <br>请注意，上面提到的优化并不是唯一可以应用的优化。<br> You may generally not rely on heap allocations happening if they can be removed without changing program behavior. <br>如果可以在不更改程序行为的情况下将其删除，则通常可能不依赖于发生的堆分配。<br>
///   Whether allocations happen or not is not part of the program behavior, even if it could be detected via an allocator that tracks allocations by printing or otherwise having side effects. <br>分配的发生与否不是程序行为的一部分，即使可以通过分配器检测到分配，该分配器通过打印或其他方式跟踪分配也会产生副作用。<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Allocate memory as described by the given `layout`. <br>按照给定的 `layout` 分配内存。<br>
    ///
    /// Returns a pointer to newly-allocated memory, or null to indicate allocation failure. <br>返回指向新分配的内存的指针，或者返回 null 以指示分配失败。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe because undefined behavior can result if the caller does not ensure that `layout` has non-zero size. <br>该函数是不安全的，因为如果调用者不确保 `layout` 的大小为非零，则可能导致未定义的行为。<br>
    ///
    /// (Extension subtraits might provide more specific bounds on behavior, e.g., guarantee a sentinel address or a null pointer in response to a zero-size allocation request.) <br>(扩展子特性可能提供行为的更具体限制，例如，保证响应零大小分配请求的前哨地址或空指针。)<br>
    ///
    /// The allocated block of memory may or may not be initialized. <br>分配的内存块可能会初始化也可能不会初始化。<br>
    ///
    /// # Errors
    ///
    /// Returning a null pointer indicates that either memory is exhausted or `layout` does not meet this allocator's size or alignment constraints. <br>返回空指针表示内存已耗尽，或者 `layout` 不满足此分配器的大小或对齐约束。<br>
    ///
    /// Implementations are encouraged to return null on memory exhaustion rather than aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 null 而不是中止，但这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望因分配错误而终止计算的客户调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate the block of memory at the given `ptr` pointer with the given `layout`. <br>使用给定的 `layout` 在给定的 `ptr` 指针处释放内存块。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe because undefined behavior can result if the caller does not ensure all of the following: <br>该函数是不安全的，因为如果调用者不能确保满足以下所有条件，则可能导致未定义的行为：<br>
    ///
    ///
    /// * `ptr` must denote a block of memory currently allocated via this allocator, <br>`ptr` 必须表示当前通过此分配器分配的内存块，<br>
    ///
    /// * `layout` must be the same layout that was used to allocate that block of memory. <br>`layout` 必须与用于分配该内存块的布局相同。<br>
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behaves like `alloc`, but also ensures that the contents are set to zero before being returned. <br>行为类似于 `alloc`，但也确保在返回之前将内容设置为零。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe for the same reasons that `alloc` is. <br>出于与 `alloc` 相同的原因，此函数是不安全的。<br>
    /// However the allocated block of memory is guaranteed to be initialized. <br>但是，保证已分配的内存块将被初始化。<br>
    ///
    /// # Errors
    ///
    /// Returning a null pointer indicates that either memory is exhausted or `layout` does not meet allocator's size or alignment constraints, just as in `alloc`. <br>像 `alloc` 一样，返回空指针表示内存已耗尽或 `layout` 不满足分配器的大小或对齐约束。<br>
    ///
    /// Clients wishing to abort computation in response to an allocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望因分配错误而终止计算的客户调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: the safety contract for `alloc` must be upheld by the caller. <br>调用者必须遵守 `alloc` 的安全保证。<br>
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAFETY: as allocation succeeded, the region from `ptr` of size `size` is guaranteed to be valid for writes. <br>随着分配成功，从 `ptr` 开始的大小为 `size` 的区域将保证对写入有效。<br>
            //
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Shrink or grow a block of memory to the given `new_size`. <br>将内存块缩小或增加到给定的 `new_size`。<br>
    /// The block is described by the given `ptr` pointer and `layout`. <br>该块由给定的 `ptr` 指针和 `layout` 描述。<br>
    ///
    /// If this returns a non-null pointer, then ownership of the memory block referenced by `ptr` has been transferred to this allocator. <br>如果返回非空指针，则 `ptr` 引用的内存块的所有权已转移到此分配器。<br>
    /// The memory may or may not have been deallocated, and should be considered unusable (unless of course it was transferred back to the caller again via the return value of this method). <br>内存可能已释放，也可能尚未释放，应将其视为不可用的 (除非当然已通过此方法的返回值再次将其转移回调用者)。<br>
    /// The new memory block is allocated with `layout`, but with the `size` updated to `new_size`. <br>`layout` 分配了新的存储块，但 `size` 更新为 `new_size`。<br>
    /// This new layout should be used when deallocating the new memory block with `dealloc`. <br>当用 `dealloc` 释放新的内存块时，应该使用这种新的布局。<br>
    /// The range `0..min(layout.size(), new_size)` of the new memory block is guaranteed to have the same values as the original block. <br>确保新存储块的范围 `0..min(layout.size(), new_size)` 与原始存储块具有相同的值。<br>
    ///
    /// If this method returns null, then ownership of the memory block has not been transferred to this allocator, and the contents of the memory block are unaltered. <br>如果此方法返回 null，则该存储块的所有权尚未转移到此分配器，并且该存储块的内容不会更改。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe because undefined behavior can result if the caller does not ensure all of the following: <br>该函数是不安全的，因为如果调用者不能确保满足以下所有条件，则可能导致未定义的行为：<br>
    ///
    /// * `ptr` must be currently allocated via this allocator, <br>`ptr` 当前必须通过这个分配器分配，<br>
    ///
    /// * `layout` must be the same layout that was used to allocate that block of memory, <br>`layout` 必须与用于分配该内存块的布局相同，<br>
    ///
    /// * `new_size` must be greater than zero. <br>`new_size` 必须大于零。<br>
    ///
    /// * `new_size`, when rounded up to the nearest multiple of `layout.align()`, must not overflow (i.e., the rounded value must be less than `usize::MAX`). <br>`new_size` 在四舍五入到最接近的 `layout.align()` 倍数时，不得溢出 (即，四舍五入的值必须小于 `usize::MAX`)。<br>
    ///
    /// (Extension subtraits might provide more specific bounds on behavior, e.g., guarantee a sentinel address or a null pointer in response to a zero-size allocation request.) <br>(扩展子特性可能提供行为的更具体限制，例如，保证响应零大小分配请求的前哨地址或空指针。)<br>
    ///
    /// # Errors
    ///
    /// Returns null if the new layout does not meet the size and alignment constraints of the allocator, or if reallocation otherwise fails. <br>如果新布局不符合分配器的大小和对齐约束，或者重新分配失败，则返回 null。<br>
    ///
    /// Implementations are encouraged to return null on memory exhaustion rather than panicking or aborting, but this is not a strict requirement. <br>鼓励实现在内存耗尽时返回 null 而不是 panic 或中止，但是这不是严格的要求。<br>
    /// (Specifically: it is *legal* to implement this trait atop an underlying native allocation library that aborts on memory exhaustion.) <br>(具体来说：在一个底层的原生分配库上实现此 trait 是 *合法的*，该本地分配库在内存耗尽时中止。)<br>
    ///
    /// Clients wishing to abort computation in response to a reallocation error are encouraged to call the [`handle_alloc_error`] function, rather than directly invoking `panic!` or similar. <br>鼓励希望响应重新分配错误而终止计算的客户调用 [`handle_alloc_error`] 函数，而不是直接调用 `panic!` 或类似方法。<br>
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: the caller must ensure that the `new_size` does not overflow. <br>调用者必须确保 `new_size` 不会溢出。<br>
        // `layout.align()` comes from a `Layout` and is thus guaranteed to be valid. <br>`layout.align()` 来自 `Layout`，因此保证有效。<br>
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: the caller must ensure that `new_layout` is greater than zero. <br>调用者必须确保 `new_layout` 大于零。<br>
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: the previously allocated block cannot overlap the newly allocated block. <br>先前分配的块不能与新分配的块重叠。<br>
            // The safety contract for `dealloc` must be upheld by the caller. <br>调用者必须遵守 `dealloc` 的安全保证。<br>
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}
