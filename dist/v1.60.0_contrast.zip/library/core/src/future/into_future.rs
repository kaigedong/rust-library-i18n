use crate::future::Future;

/// Conversion into a `Future`. <br>转换为 `Future`。<br>
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// The output that the future will produce on completion. <br>future 完成时将产生的输出。<br>
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Which kind of future are we turning this into? <br>我们要把它变成哪种 future?<br>
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Creates a future from a value. <br>根据一个值创建一个 future。<br>
    #[unstable(feature = "into_future", issue = "67644")]
    #[lang = "into_future"]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}
