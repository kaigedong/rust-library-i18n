use crate::fmt;

/// A struct containing information about the location of a panic. <br>包含有关 panic 位置信息的结构体。<br>
///
/// This structure is created by [`PanicInfo::location()`]. <br>该结构体由 [`PanicInfo::location()`] 创建。<br>
///
/// [`PanicInfo::location()`]: crate::panic::PanicInfo::location
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Comparisons for equality and ordering are made in file, line, then column priority. <br>在文件，行和列优先级中进行相等性和顺序的比较。<br>
/// Files are compared as strings, not `Path`, which could be unexpected. <br>文件被比较为字符串，而不是 `Path`，这可能是意外的。<br>
/// See [`Location::file`]'s documentation for more discussion. <br>有关更多讨论，请参见 [`Location::file`] 的文档。<br>
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Returns the source location of the caller of this function. <br>返回此函数的调用者的源位置。<br>
    /// If that function's caller is annotated then its call location will be returned, and so on up the stack to the first call within a non-tracked function body. <br>如果该函数的调用者被注释，那么它的调用位置将被返回，以此类推，直到堆栈中第一个未被跟踪的函数体中的调用。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Returns the [`Location`] at which it is called. <br>返回调用它的 [`Location`]。<br>
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Returns a [`Location`] from within this function's definition. <br>从此函数的定义中返回 [`Location`]。<br>
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // running the same untracked function in a different location gives us the same result <br>在不同的位置运行相同的未跟踪函数会得到相同的结果<br>
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // running the tracked function in a different location produces a different value <br>在其他位置运行跟踪的函数会产生不同的值<br>
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[must_use]
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }

    /// Returns the name of the source file from which the panic originated. <br>返回 panic 源自的源文件的名称。<br>
    ///
    /// # `&str`, not `&Path` <br>`&str`，不是 `&Path`<br>
    ///
    /// The returned name refers to a source path on the compiling system, but it isn't valid to represent this directly as a `&Path`. <br>返回的名称指向编译系统上的源路径，但是将其直接表示为 `&Path` 是无效的。<br>
    /// The compiled code may run on a different system with a different `Path` implementation than the system providing the contents and this library does not currently have a different "host path" type. <br>与提供内容的系统相比，编译后的代码可以在具有不同 `Path` 实现的不同系统上运行，并且此库当前没有不同的 "host path" 类型。<br>
    ///
    /// The most surprising behavior occurs when "the same" file is reachable via multiple paths in the module system (usually using the `#[path = "..."]` attribute or similar), which can cause what appears to be identical code to return differing values from this function. <br>当通过模块系统中的多个路径可访问 "the same" 文件时 (通常使用 `#[path = "..."]` 属性或类似属性)，会发生最令人惊讶的行为，这可能导致看似相同的代码返回与此函数不同的值。<br>
    ///
    ///
    /// # Cross-compilation
    ///
    /// This value is not suitable for passing to `Path::new` or similar constructors when the host platform and target platform differ. <br>当主机平台和目标平台不同时，此值不适合传递给 `Path::new` 或类似的构造函数。<br>
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[must_use]
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Returns the line number from which the panic originated. <br>返回 panic 起源的行号。<br>
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[must_use]
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Returns the column from which the panic originated. <br>返回 panic 起源的列。<br>
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[must_use]
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[unstable(
    feature = "panic_internals",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]
impl<'a> Location<'a> {
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}
