//! Composable asynchronous iteration. <br>可组合的异步迭代。<br>
//!
//! If you've found yourself with an asynchronous collection of some kind, and needed to perform an operation on the elements of said collection, you'll quickly run into 'async iterators'. <br>如果您发现自己使用某种异步集合，并且需要对所述集合的元素执行操作，您将很快遇到异步迭代器。<br>
//! Async Iterators are heavily used in idiomatic asynchronous Rust code, so it's worth becoming familiar with them. <br>异步迭代器在惯用的异步 Rust 代码中大量使用，因此熟悉它们是值得的。<br>
//!
//! Before explaining more, let's talk about how this module is structured: <br>在解释更多内容之前，让我们讨论一下该模块的结构：<br>
//!
//! # Organization
//!
//! This module is largely organized by type: <br>该模块主要是按类型来组织的：<br>
//!
//! * [Traits] are the core portion: these traits define what kind of async iterators exist and what you can do with them. <br>[Traits] 是核心部分：这些 traits 定义了存在什么样的异步迭代器以及您可以用它们做什么。<br> The methods of these traits are worth putting some extra study time into. <br>这些 traits 的方法值得投入一些额外的学习时间。<br>
//! * Functions provide some helpful ways to create some basic async iterators. <br>函数提供了一些有用的方法来创建一些基本的异步迭代器。<br>
//! * Structs are often the return types of the various methods on this module's traits. <br>结构体通常是该模块的 traits 上各种方法的返回类型。<br> You'll usually want to look at the method that creates the `struct`, rather than the `struct` itself. <br>通常，您将需要查看创建 `struct` 的方法，而不是 `struct` 本身。<br>
//! For more detail about why, see '[Implementing Async Iterator](#implementing-async-iterator)'. <br>有关原因的更多详细信息，请参见 [实现异步迭代器](#implementing-async-iterator)。<br>
//!
//! [Traits]: #traits
//!
//! That's it! <br>就是这样！<br> Let's dig into async iterators. <br>让我们深入研究异步迭代器。<br>
//!
//! # Async Iterators <br>异步迭代器<br>
//!
//! The heart and soul of this module is the [`AsyncIterator`] trait. <br>这个模块的核心和灵魂是 [`AsyncIterator`] trait。<br> The core of [`AsyncIterator`] looks like this: <br>[`AsyncIterator`] 的核心是这样的:<br>
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait AsyncIterator {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Unlike `Iterator`, `AsyncIterator` makes a distinction between the [`poll_next`] method which is used when implementing an `AsyncIterator`, and a (to-be-implemented) `next` method which is used when consuming an async iterator. <br>与 `Iterator` 不同，`AsyncIterator` 区分了实现 `AsyncIterator` 时使用的 [`poll_next`] 方法和使用异步迭代器时使用的 (to-be-implemented) `next` 方法。<br>
//!
//! Consumers of `AsyncIterator` only need to consider `next`, which when called, returns a future which yields `Option<AsyncIterator::Item>`. <br>`AsyncIterator` 的消费者只需要考虑 `next`，它在调用时会返回一个 future，它产生 `Option<AsyncIterator::Item>`。<br>
//!
//! The future returned by `next` will yield `Some(Item)` as long as there are elements, and once they've all been exhausted, will yield `None` to indicate that iteration is finished. <br>只要有元素，`next` 返回的 future 就会产生 `Some(Item)`，一旦所有元素用完，就会产生 `None` 来指示迭代已完成。<br>
//! If we're waiting on something asynchronous to resolve, the future will wait until the async iterator is ready to yield again. <br>如果我们正在等待异步解决问题，future 将等待异步迭代器再次准备好再次 yield。<br>
//!
//! Individual async iterators may choose to resume iteration, and so calling `next` again may or may not eventually yield `Some(Item)` again at some point. <br>单个异步迭代器可能会选择恢复迭代，因此再次调用 `next` 最终可能会或可能不会最终在某个时候再次产生 `Some(Item)`。<br>
//!
//! [`AsyncIterator`]'s full definition includes a number of other methods as well, but they are default methods, built on top of [`poll_next`], and so you get them for free. <br>[`AsyncIterator`] 的完整定义还包括许多其他方法，但它们是默认方法，建立在 [`poll_next`] 之上，因此您可以免费获得它们。<br>
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: AsyncIterator::poll_next
//!
//! # Implementing Async Iterator <br>实现异步迭代器<br>
//!
//! Creating an async iterator of your own involves two steps: creating a `struct` to hold the async iterator's state, and then implementing [`AsyncIterator`] for that `struct`. <br>创建自己的异步迭代器涉及两个步骤：创建一个 `struct` 来保存异步迭代器的状态，然后为该 `struct` 实现 [`AsyncIterator`]。<br>
//!
//! Let's make an async iterator named `Counter` which counts from `1` to `5`: <br>让我们创建一个名为 `Counter` 的异步迭代器，它从 `1` 计数到 `5`:<br>
//!
//! ```no_run
//! #![feature(async_iterator)]
//! # use core::async_iter::AsyncIterator;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // First, the struct: <br>首先，结构体：<br>
//!
//! /// An async iterator which counts from one to five <br>一个从 1 计数到 5 的异步迭代器<br>
//! struct Counter {
//!     count: usize,
//! }
//!
//! // we want our count to start at one, so let's add a new() method to help. <br>我们希望计数从一开始，所以让我们添加一个 new() 方法来提供帮助。<br>
//! // This isn't strictly necessary, but is convenient. <br>这不是严格必要的，但很方便。<br>
//! // Note that we start `count` at zero, we'll see why in `poll_next()`'s implementation below. <br>请注意，我们将 `count` 从零开始，我们将在下面的 `poll_next () ` 的实现中看到其原因。<br>
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Then, we implement `AsyncIterator` for our `Counter`: <br>然后，我们为我们的 `Counter` 实现 `AsyncIterator`:<br>
//!
//! impl AsyncIterator for Counter {
//!     // we will be counting with usize <br>我们将使用 usize 进行计数<br>
//!     type Item = usize;
//!
//!     // poll_next() is the only required method <br>poll_next() 是唯一需要的方法<br>
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Increment our count. <br>增加我们的数量。<br> This is why we started at zero. <br>这就是为什么我们从零开始。<br>
//!         self.count += 1;
//!
//!         // Check to see if we've finished counting or not. <br>检查我们是否已经完成计数。<br>
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Async iterators are *lazy*. <br>异步迭代器是惰性的。<br> This means that just creating an async iterator doesn't _do_ a whole lot. <br>这意味着仅仅创建一个异步迭代器并不能做很多事情。<br> Nothing really happens until you call `poll_next`. <br>在您调用 `poll_next` 之前，什么都不会发生。<br>
//! This is sometimes a source of confusion when creating an async iterator solely for its side effects. <br>当创建一个异步迭代器仅仅为了它的副作用时，这有时是一个混乱的根源。<br>
//! The compiler will warn us about this kind of behavior: <br>编译器将警告我们这种行为：<br>
//!
//! ```text
//! warning: unused result that must be used: async iterators do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod async_iter;
mod from_iter;

pub use async_iter::AsyncIterator;
pub use from_iter::{from_iter, FromIter};
