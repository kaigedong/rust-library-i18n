/// Used for immutable dereferencing operations, like `*v`. <br>用于不可变解引用操作，例如 `*v`。<br>
///
/// In addition to being used for explicit dereferencing operations with the (unary) `*` operator in immutable contexts, `Deref` is also used implicitly by the compiler in many circumstances. <br>`Deref` 除了在不可变上下文中用于 (unary) `*` 运算符的显式解引用操作外，在许多情况下，编译器都隐式使用 `Deref`。<br>
/// This mechanism is called ['`Deref` coercion'][more]. <br>该机制称为 [`Deref` 强制多态][more]。<br>
/// In mutable contexts, [`DerefMut`] is used. <br>在可变上下文中，使用 [`DerefMut`]。<br>
///
/// Implementing `Deref` for smart pointers makes accessing the data behind them convenient, which is why they implement `Deref`. <br>为智能指针实现 `Deref` 使得访问它们背后的数据变得方便，这就是为什么它们实现 `Deref` 的原因。<br>
/// On the other hand, the rules regarding `Deref` and [`DerefMut`] were designed specifically to accommodate smart pointers. <br>另一方面，有关 `Deref` 和 [`DerefMut`] 的规则是专门为容纳智能指针而设计的。<br>
/// Because of this, **`Deref` should only be implemented for smart pointers** to avoid confusion. <br>因此，`Deref` 只应为智能指针实现，以避免混淆。<br>
///
/// For similar reasons, **this trait should never fail**. <br>出于类似的原因，这个 trait 永远不会失败。<br> Failure during dereferencing can be extremely confusing when `Deref` is invoked implicitly. <br>当隐式调用 `Deref` 时，解引用过程中的失败可能会造成极大的混乱。<br>
///
/// # More on `Deref` coercion <br>有关 `Deref` 强制多态的更多信息<br>
///
/// If `T` implements `Deref<Target = U>`, and `x` is a value of type `T`, then: <br>如果 `T` 实现 `Deref<Target = U>`，并且 `x` 是 `T` 类型的值，则：<br>
///
/// * In immutable contexts, `*x` (where `T` is neither a reference nor a raw pointer) is equivalent to `*Deref::deref(&x)`. <br>在不可变的上下文中，`*x` (其中 `T` 既不是引用也不是裸指针) 等效于 `*Deref::deref(&x)`。<br>
/// * Values of type `&T` are coerced to values of type `&U` <br>`&T` 类型的值被强制为 `&U` 类型的值<br>
/// * `T` implicitly implements all the (immutable) methods of the type `U`. <br>`T` 隐式地实现了 `U` 类型的所有 (immutable) 方法。<br>
///
/// For more details, visit [the chapter in *The Rust Programming Language*][book] as well as the reference sections on [the dereference operator][ref-deref-op], [method resolution] and [type coercions]. <br>有关更多详细信息，请访问 [Rust 编程语言中的章节][book] 以及 [解引用运算符][ref-deref-op]，[方法解析][method resolution] 和 [类型强制转换][type coercions] 上的引用部分。<br>
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// A struct with a single field which is accessible by dereferencing the struct. <br>具有解引用的结构体可访问的具有单个字段的结构体。<br>
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// The resulting type after dereferencing. <br>解引用后的结果类型。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[lang = "deref_target"]
    type Target: ?Sized;

    /// Dereferences the value. <br>解引用值。<br>
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_deref", issue = "88955")]
impl<T: ?Sized> const Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_deref", issue = "88955")]
impl<T: ?Sized> const Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Used for mutable dereferencing operations, like in `*v = 1;`. <br>用于可变解引用操作，例如在 `*v = 1;` 中。<br>
///
/// In addition to being used for explicit dereferencing operations with the (unary) `*` operator in mutable contexts, `DerefMut` is also used implicitly by the compiler in many circumstances. <br>`DerefMut` 除了可用于 (一元) `*` 运算符在可变上下文中的显式解引用操作外，还可以在许多情况下被编译器隐式使用。<br>
/// This mechanism is called ['`Deref` coercion'][more]. <br>该机制称为 [`Deref` 强制多态][more]。<br>
/// In immutable contexts, [`Deref`] is used. <br>在不可变的上下文中，使用 [`Deref`]。<br>
///
/// Implementing `DerefMut` for smart pointers makes mutating the data behind them convenient, which is why they implement `DerefMut`. <br>为智能指针实现 `DerefMut` 可以方便地对其背后的数据进行可变的，这就是为什么它们实现 `DerefMut` 的原因。<br>
/// On the other hand, the rules regarding [`Deref`] and `DerefMut` were designed specifically to accommodate smart pointers. <br>另一方面，有关 [`Deref`] 和 `DerefMut` 的规则是专门为容纳智能指针而设计的。<br>
/// Because of this, **`DerefMut` should only be implemented for smart pointers** to avoid confusion. <br>因此，`DerefMut` 仅应针对智能指针实现，以免造成混淆。<br>
///
/// For similar reasons, **this trait should never fail**. <br>出于类似的原因，这个 trait 永远不会失败。<br> Failure during dereferencing can be extremely confusing when `DerefMut` is invoked implicitly. <br>当隐式调用 `DerefMut` 时，解引用过程中的失败可能会非常令人困惑。<br>
///
/// # More on `Deref` coercion <br>有关 `Deref` 强制多态的更多信息<br>
///
/// If `T` implements `DerefMut<Target = U>`, and `x` is a value of type `T`, then: <br>如果 `T` 实现 `DerefMut<Target = U>`，并且 `x` 是 `T` 类型的值，则：<br>
///
/// * In mutable contexts, `*x` (where `T` is neither a reference nor a raw pointer) is equivalent to `*DerefMut::deref_mut(&mut x)`. <br>在可变上下文中，`*x` (其中 `T` 既不是引用也不是裸指针) 等效于 `* DerefMut::deref_mut(&mut x)`。<br>
/// * Values of type `&mut T` are coerced to values of type `&mut U` <br>`&mut T` 类型的值被强制为 `&mut U` 类型的值<br>
/// * `T` implicitly implements all the (mutable) methods of the type `U`. <br>`T` 隐式地实现了 `U` 类型的所有 (mutable) 方法。<br>
///
/// For more details, visit [the chapter in *The Rust Programming Language*][book] as well as the reference sections on [the dereference operator][ref-deref-op], [method resolution] and [type coercions]. <br>有关更多详细信息，请访问 [Rust 编程语言中的章节][book] 以及 [解引用运算符][ref-deref-op]，[方法解析][method resolution] 和 [类型强制转换][type coercions] 上的引用部分。<br>
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// A struct with a single field which is modifiable by dereferencing the struct. <br>具有单个字段的结构体，可以通过解引用该结构体进行修改。<br>
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mutably dereferences the value. <br>可变地解引用该值。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indicates that a struct can be used as a method receiver, without the `arbitrary_self_types` feature. <br>表示可以将结构体用作方法接收器，而无需使用 `arbitrary_self_types` 特性。<br>
///
/// This is implemented by stdlib pointer types like `Box<T>`, `Rc<T>`, `&T`, and `Pin<P>`. <br>这是由 stdlib 指针类型实现的 (例如 `Box<T>`，`Rc<T>`，`&T` 和 `Pin<P>`)。<br>
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}
