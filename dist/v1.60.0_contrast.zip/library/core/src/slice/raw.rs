//! Free functions to create `&[T]` and `&mut [T]`. <br>创建 `&[T]` 和 `&mut [T]` 的 free 函数。<br>

use crate::array;
use crate::ptr;

/// Forms a slice from a pointer and a length. <br>根据指针和长度形成切片。<br>
///
/// The `len` argument is the number of **elements**, not the number of bytes. <br>`len` 参数是 **元素** 的数量，而不是字节数。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `data` must be [valid] for reads for `len * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>对于 `len * mem::size_of::<T>()` 多个字节的读取，`data` 必须是 [valid]，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br> See [below](#incorrect-usage) for an example incorrectly not taking this into account. <br>请参见 [下文](#incorrect-usage) 了解一个没有考虑到这一点的错误示例。<br>
///     * `data` must be non-null and aligned even for zero-length slices. <br>即使对于零长度切片，`data` 也必须非空且对齐。<br>
///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
///
/// * `data` must point to `len` consecutive properly initialized values of type `T`. <br>`data` 必须指向 `len` 类型的 `T` 类型的连续正确初始化值。<br>
///
/// * The memory referenced by the returned slice must not be mutated for the duration of lifetime `'a`, except inside an `UnsafeCell`. <br>返回的切片引用的内存在生命周期 `'a` 期间不得更改，除非在 `UnsafeCell` 内部。<br>
///
/// * The total size `len * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `len * mem::size_of::<T>()` 必须不大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// # Caveat
///
/// The lifetime for the returned slice is inferred from its usage. <br>从使用中可以推断出返回切片的生命周期。<br>
/// To prevent accidental misuse, it's suggested to tie the lifetime to whichever source lifetime is safe in the context, such as by providing a helper function taking the lifetime of a host value for the slice, or by explicit annotation. <br>为防止意外滥用，建议将生命周期与生命周期中任何安全的来源联系起来，例如通过提供一个辅助函数，获取切片的宿主值的生命周期，或通过明确的注解法。<br>
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifest a slice for a single element <br>显示单个元素的切片<br>
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Incorrect usage <br>用法不正确<br>
///
/// The following `join_slices` function is **unsound** <br>下面的 `join_slices` 函数是不健全的<br> ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // The assertion above ensures `fst` and `snd` are contiguous, but they might still be contained within _different allocated objects_, in which case creating this slice is undefined behavior. <br>上面的断言确保 `fst` 和 `snd` 是连续的，但是它们仍可能包含在 _different allocated objects_ 中，在这种情况下，创建此切片是未定义的行为。<br>
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` and `b` are different allocated objects... <br>`a` 和 `b` 是不同的分配对象...<br>
///     let a = 42;
///     let b = 27;
///     // ... which may nevertheless be laid out contiguously in memory: | a | b | <br>但这可能会连续地放在内存中：一个 | b |<br>
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_check_data_len(data, len);

    // SAFETY: the caller must uphold the safety contract for `from_raw_parts`. <br>调用者必须遵守 `from_raw_parts` 的安全保证。<br>
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Performs the same functionality as [`from_raw_parts`], except that a mutable slice is returned. <br>执行与 [`from_raw_parts`] 相同的功能，除了返回可变切片。<br>
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `data` must be [valid] for both reads and writes for `len * mem::size_of::<T>()` many bytes, and it must be properly aligned. <br>对于 `len * mem::size_of::<T>()` 多个字节的读取和写入，`data` 必须是 [valid]，并且必须正确对齐。<br> This means in particular: <br>这尤其意味着：<br>
///
///     * The entire memory range of this slice must be contained within a single allocated object! <br>该切片的整个存储范围必须包含在一个分配的对象中！<br>
///       Slices can never span across multiple allocated objects. <br>切片永远不能跨越多个分配的对象。<br>
///     * `data` must be non-null and aligned even for zero-length slices. <br>即使对于零长度切片，`data` 也必须非空且对齐。<br>
///     One reason for this is that enum layout optimizations may rely on references (including slices of any length) being aligned and non-null to distinguish them from other data. <br>这样做的一个原因是，枚举布局优化可能依赖于对齐的引用 (包括任何长度的切片) 和非空值，以将它们与其他数据区分开。<br>
///
///     You can obtain a pointer that is usable as `data` for zero-length slices using [`NonNull::dangling()`]. <br>您可以使用 [`NonNull::dangling()`] 获得可用作零长度切片的 `data` 的指针。<br>
///
/// * `data` must point to `len` consecutive properly initialized values of type `T`. <br>`data` 必须指向 `len` 类型的 `T` 类型的连续正确初始化值。<br>
///
/// * The memory referenced by the returned slice must not be accessed through any other pointer (not derived from the return value) for the duration of lifetime `'a`. <br>在生命周期 `'a` 的持续时间内，不得通过任何其他指针 (不是从返回值派生) 访问返回的切片引用的内存。<br>
///   Both read and write accesses are forbidden. <br>读取和写入访问均被禁止。<br>
///
/// * The total size `len * mem::size_of::<T>()` of the slice must be no larger than `isize::MAX`. <br>切片的总大小 `len * mem::size_of::<T>()` 必须不大于 `isize::MAX`。<br>
///   See the safety documentation of [`pointer::offset`]. <br>请参见 [`pointer::offset`] 的安全文档。<br>
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_check_data_len(data as _, len);

    // SAFETY: the caller must uphold the safety contract for `from_raw_parts_mut`. <br>调用者必须遵守 `from_raw_parts_mut` 的安全保证。<br>
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

// In debug builds checks that `data` pointer is aligned and non-null and that slice with given `len` would cover less than half the address space <br>在调试版本中，检查 `data` 指针是否对齐且不为 null，并且具有给定 `len` 的切片将覆盖不到一半的地址空间<br>
#[cfg(debug_assertions)]
#[unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
const fn debug_check_data_len<T>(data: *const T, len: usize) {
    fn rt_check<T>(data: *const T) {
        use crate::intrinsics::is_aligned_and_not_null;

        assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    }

    const fn noop<T>(_: *const T) {}

    // SAFETY:
    //
    // `rt_check` is just a debug assert to hint users that they are causing UB, it is not required for safety (the safety must be guatanteed by the `from_raw_parts[_mut]` caller). <br>`rt_check` 只是一个调试断言，提示用户他们正在导致 UB，它不是安全必需的 (安全性必须由 `from_raw_parts[_mut]` 调用者保证)。<br>
    //
    //
    // As per our safety precondition, we may assume that assertion above never fails. <br>根据我们的安全先决条件，我们可以假设上面的断言永远不会失败。<br>
    // Therefore, noop and rt_check are observably equivalent. <br>因此，noop 和 rt_check 显然是等价的。<br>
    //
    unsafe {
        crate::intrinsics::const_eval_select((data,), noop, rt_check);
    }

    assert!(
        crate::mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
}

#[cfg(not(debug_assertions))]
const fn debug_check_data_len<T>(_data: *const T, _len: usize) {}

/// Converts a reference to T into a slice of length 1 (without copying). <br>将引用转换为 T 转换为长度为 1 的切片 (不进行复制)。<br>
#[stable(feature = "from_ref", since = "1.28.0")]
#[rustc_const_unstable(feature = "const_slice_from_ref", issue = "90206")]
pub const fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converts a reference to T into a slice of length 1 (without copying). <br>将引用转换为 T 转换为长度为 1 的切片 (不进行复制)。<br>
#[stable(feature = "from_ref", since = "1.28.0")]
#[rustc_const_unstable(feature = "const_slice_from_ref", issue = "90206")]
pub const fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}
