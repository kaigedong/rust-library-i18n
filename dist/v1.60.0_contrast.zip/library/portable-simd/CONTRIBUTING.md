# Contributing to `std::simd` <br>为 `std::simd` 做贡献<br>

Simple version: <br>简单版：<br>
1. Fork it and `git clone` it <br>Fork 它和 `git clone` 它<br>
2. Create your feature branch: `git checkout -b my-branch` <br>创建您的特性分支：`git checkout -b my-branch`<br>
3. Write your changes. <br>写下您的改变。<br>
4. Test it: `cargo test`. <br>测试一下: `cargo test`。<br> Remember to enable whatever SIMD features you intend to test by setting `RUSTFLAGS`. <br>请记住通过设置 `RUSTFLAGS` 来启用您打算测试的任何 SIMD 特性。<br>
5. Commit your changes: `git commit add ./path/to/changes && git commit -m 'Fix some bug'` <br>提交您的更改：`git commit add ./path/to/changes && git commit -m 'Fix some bug'`<br>
6. Push the branch: `git push --set-upstream origin my-branch` <br>推送到分支：`git push --set-upstream origin my-branch`<br>
7. Submit a pull request! <br>提交拉取请求！<br>

## Taking on an Issue <br>解决问题<br>

SIMD can be quite complex, and even a "simple" issue can be huge. <br>SIMD 可能非常复杂，甚至 "simple" 问题也可能很大。<br> If an issue is organized like a tracking issue, with an itemized list of items that don't necessarily have to be done in a specific order, please take the issue one item at a time. <br>如果问题的组织方式类似于跟踪问题，并且有一个项的逐项列表，而不必按特定顺序完成，请一次处理一个项。<br> This will help by letting work proceed apace on the rest of the issue. <br>这将有助于让工作在其余问题上快速进行。<br> If it's a (relatively) small issue, feel free to announce your intention to solve it on the issue tracker and take it in one go! <br>如果是 (relatively) 的小问题，请随时在问题跟踪器上宣布您的解决意向，并一次性解决！<br>

## CI

We currently use GitHub Actions which will automatically build and test your change in order to verify that `std::simd`'s portable API is, in fact, portable. <br>我们目前使用 GitHub Actions，它会自动构建和测试您的更改，以验证 `std::simd` 的可移植 API 实际上是可移植的。<br> If your change builds locally, but does not build in CI, this is likely due to a platform-specific concern that your code has not addressed. <br>如果您的更改在本地构建，但不在 CI 中构建，这可能是由于您的代码未解决特定于平台的问题。<br> Please consult the build logs and address the error, or ask for help if you need it. <br>请查阅构建日志并解决错误，或者在需要时寻求帮助。<br>

## Beyond stdsimd <br>超越 stdsimd<br>

A large amount of the core SIMD implementation is found in the rustc_codegen_* crates in the [main rustc repo](https://github.com/rust-lang/rust). <br>在 [rustc 仓库 main 分支](https://github.com/rust-lang/rust) 中的 rustc_codegen_* crates 中可以找到大量的核心 SIMD 实现。<br> In addition, actual platform-specific functions are implemented in [stdarch]. <br>此外，实际平台特定的函数是在 [stdarch] 中实现的。<br> Not all changes to `std::simd` require interacting with either of these, but if you're wondering where something is and it doesn't seem to be in this repository, those might be where to start looking. <br>并非所有对 `std::simd` 的更改都需要与其中任何一个进行交互，但是如果您想知道某物在哪里并且它似乎不在这个仓库中，那么这些可能是开始寻找的地方。<br>

## Questions? Concerns? <br>问题？担忧？<br> Need Help? <br>需要帮忙？<br>

Please feel free to ask in the [#project-portable-simd][zulip-portable-simd] stream on the [rust-lang Zulip][zulip] for help with making changes to `std::simd`! <br>请随时在 [rust-lang Zulip][zulip] 上的 [#project-portable-simd][zulip-portable-simd] 流中询问有关对 `std::simd` 进行更改的帮助！<br>
If your changes include directly modifying the compiler, it might also be useful to ask in [#t-compiler/help][zulip-compiler-help]. <br>如果您的更改包括直接修改编译器，那么在 [#t-compiler/help][zulip-compiler-help] 中询问也可能有用。<br>

[zulip-portable-simd]: https://rust-lang.zulipchat.com/#narrow/stream/257879-project-portable-simd
[zulip-compiler-help]: https://rust-lang.zulipchat.com/#narrow/stream/182449-t-compiler.2Fhelp
[zulip]: https://rust-lang.zulipchat.com
[stdarch]: https://github.com/rust-lang/stdarch
