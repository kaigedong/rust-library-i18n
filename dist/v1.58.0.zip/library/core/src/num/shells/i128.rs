//! 128 位有符号整数类型的常量。
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }
