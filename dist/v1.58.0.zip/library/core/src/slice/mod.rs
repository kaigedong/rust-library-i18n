//! 切片管理和操作。
//!
//! 有关更多详细信息，请参见 [`std::slice`]。
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// 纯粹的 rust memchr 实现，取自 rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// 该函数仅是公开的，因为没有其他方法可以进行单元测试堆排序。
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[unstable(feature = "inherent_ascii_escape", issue = "77174")]
pub use ascii::EscapeAscii;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// 返回切片中的元素数。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[lang = "slice_len_fn"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.39.0")]
    #[inline]
    // SAFETY: const sound，因为我们将长度字段转换为 usize (必须是)
    pub const fn len(&self) -> usize {
        // FIXME: 当 `crate::ptr::metadata(self)` 稳定时，替换为 `crate::ptr::metadata(self)`。
        // 在撰写本文时，这将导致 "Const-stable 只能调用其他 const-stable 函数" 的错误。
        //

        // SAFETY: 因为 *const T 和 PtrComponents<T> 具有相同的内存布局，所以从 `PtrRepr` union 访问值是安全的。
        // 只有 std 可以做出此保证。
        //
        unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
    }

    /// 如果切片的长度为 0，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.39.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 返回切片的第一个元素; 如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_first_last_not_mut", since = "1.56.0")]
    #[inline]
    pub const fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 返回指向切片第一个元素的可变指针，如果为空则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_slice_first_last", issue = "83570")]
    #[inline]
    pub const fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 返回切片的第一个元素和所有其他元素，如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[rustc_const_stable(feature = "const_slice_first_last_not_mut", since = "1.56.0")]
    #[inline]
    pub const fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 返回切片的第一个元素和所有其他元素，如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[rustc_const_unstable(feature = "const_slice_first_last", issue = "83570")]
    #[inline]
    pub const fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 返回切片的最后一个元素和所有其他元素，如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[rustc_const_stable(feature = "const_slice_first_last_not_mut", since = "1.56.0")]
    #[inline]
    pub const fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 返回切片的最后一个元素和所有其他元素，如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[rustc_const_unstable(feature = "const_slice_first_last", issue = "83570")]
    #[inline]
    pub const fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 返回切片的最后一个元素; 如果为空，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_first_last_not_mut", since = "1.56.0")]
    #[inline]
    pub const fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 返回指向切片中最后一个项的可变指针。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_slice_first_last", issue = "83570")]
    #[inline]
    pub const fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 根据索引的类型返回对元素或子切片的引用。
    ///
    /// - 如果给定位置，则返回该位置上的元素的引用，如果越界则返回 `None`。
    ///
    /// - 如果给定范围，则返回对应于该范围的子切片; 如果越界，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// 根据索引的类型 (请参见 [`get`]) 或 `None` (如果索引越界)，对元素或子切片返回可变引用。
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// 返回对元素或子切片的引用，而不进行边界检查。
    ///
    /// 有关安全的选择，请参见 [`get`]。
    ///
    /// # Safety
    ///
    /// 即使没有使用所得的引用，使用越界索引调用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: 调用者必须遵守 `get_unchecked` 的大多数安全要求；
        // 切片是可解引用的，因为 `self` 是一个安全的引用。
        // 返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。
        unsafe { &*index.get_unchecked(self) }
    }

    /// 返回元素或子切片的可变引用，而不进行边界检查。
    ///
    /// 有关安全的选择，请参见 [`get_mut`]。
    ///
    /// # Safety
    ///
    /// 即使没有使用所得的引用，使用越界索引调用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: 调用者必须遵守 `get_unchecked_mut` 的安全要求；
        // 切片是可解引用的，因为 `self` 是一个安全的引用。
        // 返回的指针是安全的，因为 `SliceIndex` 的 impls 必须保证它是正确的。
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// 将裸指针返回到切片的缓冲区。
    ///
    /// 调用者必须确保切片比该函数返回的指针有效，否则它将最终指向垃圾。
    ///
    /// 调用者还必须确保指针 (non-transitively) 所指向的内存 (从 `UnsafeCell` 内部除外) 永远不会使用此指针或从其派生的任何指针写入。
    /// 如果需要更改切片的内容，请使用 [`as_mut_ptr`]。
    ///
    /// 修改此切片引用的容器可能会导致重新分配其缓冲区，这也将使指向它的任何指针无效。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// 返回指向切片缓冲区的不安全可变指针。
    ///
    /// 调用者必须确保切片比该函数返回的指针有效，否则它将最终指向垃圾。
    ///
    /// 修改此切片引用的容器可能会导致重新分配其缓冲区，这也将使指向它的任何指针无效。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// 返回跨越切片的两个裸指针。
    ///
    /// 返回的范围是半开的，这意味着结束指针将 *one 指向* 切片的最后一个元素。
    /// 这样，一个空的切片由两个相等的指针表示，两个指针之间的差表示切片的大小。
    ///
    /// 有关使用这些指针的警告，请参见 [`as_ptr`]。结束指针需要格外小心，因为它没有指向切片中的有效元素。
    ///
    /// 此函数对于与外部接口进行交互很有用，该外部接口使用两个指针来引用内存中的一系列元素，这在 C++ 中很常见。
    ///
    ///
    /// 检查指向元素的指针是否引用了此切片的元素，这也可能很有用：
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: 这里的 `add` 是安全的，因为：
        //
        //   - 两个指针都是同一对象的一部分，因为直接指向该对象的指针也很重要。
        //
        //   - 切片的大小永远不会大于 isize::MAX 字节，如下所示：
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety (这似乎尚不规范，但是在很多地方都做出了相同的假设，包括切片的 Index 实现。)
        //
        //
        //   - 没有切片环绕，因为切片不会环绕地址空间的末尾。
        //
        // 请参见 pointer::add 的文档。
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 返回跨越切片的两个不安全的可变指针。
    ///
    /// 返回的范围是半开的，这意味着结束指针将 *one 指向* 切片的最后一个元素。
    /// 这样，一个空的切片由两个相等的指针表示，两个指针之间的差表示切片的大小。
    ///
    /// 有关使用这些指针的警告，请参见 [`as_mut_ptr`]。
    /// 结束指针需要格外小心，因为它没有指向切片中的有效元素。
    ///
    /// 此函数对于与外部接口进行交互很有用，该外部接口使用两个指针来引用内存中的一系列元素，这在 C++ 中很常见。
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETY: 有关为什么 `add` 此处安全的信息，请参见上面的 as_ptr_range()。
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 在切片中交换两个元素。
    ///
    /// # Arguments
    ///
    /// * a - 第一个元素的索引
    /// * b - 第二个元素的索引
    ///
    /// # Panics
    ///
    /// 如果 `a` 或 `b` 越界，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d", "e"];
    /// v.swap(2, 4);
    /// assert!(v == ["a", "b", "e", "d", "c"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_swap", issue = "83163")]
    #[inline]
    pub const fn swap(&mut self, a: usize, b: usize) {
        let _ = &self[a];
        let _ = &self[b];

        // SAFETY: 我们刚刚检查了 `a` 和 `b` 都在边界内
        unsafe { self.swap_unchecked(a, b) }
    }

    /// 在不做边界检查的情况下交换切片中的两个元素。
    ///
    /// 有关安全的替代方案，请参见 [`swap`]。
    ///
    /// # Arguments
    ///
    /// * a - 第一个元素的索引
    /// * b - 第二个元素的索引
    ///
    /// # Safety
    ///
    /// 使用越界索引调用此方法是 [未定义的行为][undefined behavior]。
    /// 调用者必须保证 `a < self.len()` 和 `b < self.len()`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_swap_unchecked)]
    ///
    /// let mut v = ["a", "b", "c", "d"];
    /// // SAFETY: 我们知道 1 和 3 都是切片的索引
    /// unsafe { v.swap_unchecked(1, 3) };
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    ///
    /// [`swap`]: slice::swap
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    #[unstable(feature = "slice_swap_unchecked", issue = "88539")]
    #[rustc_const_unstable(feature = "const_swap", issue = "83163")]
    pub const unsafe fn swap_unchecked(&mut self, a: usize, b: usize) {
        #[cfg(debug_assertions)]
        {
            let _ = &self[a];
            let _ = &self[b];
        }

        let ptr = self.as_mut_ptr();
        // SAFETY: 调用者必须保证 `a < self.len()` 和 `b < self.len()`
        unsafe {
            ptr::swap(ptr.add(a), ptr.add(b));
        }
    }

    /// 适当地反转切片中元素的顺序。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let half_len = self.len() / 2;
        let Range { start, end } = self.as_mut_ptr_range();

        // 这些切片将跳过奇数长度的中间项，因为该项不需要移动。
        //
        let (front_half, back_half) =
            // SAFETY: 两者都是原始切片的子部分，因此内存范围是有效的，并且它们不会重叠，因为它们每个都只是原始切片的一半 (或更少)。
            //
            //
            unsafe {
                (
                    slice::from_raw_parts_mut(start, half_len),
                    slice::from_raw_parts_mut(end.sub(half_len), half_len),
                )
            };

        // 这里引入函数边界意味着两个部分得到 `noalias` 标记，允许更好的优化，因为 LLVM 知道它们是不相交的，不像在原始切片中那样。
        //
        //
        revswap(front_half, back_half, half_len);

        #[inline]
        fn revswap<T>(a: &mut [T], b: &mut [T], n: usize) {
            debug_assert_eq!(a.len(), n);
            debug_assert_eq!(b.len(), n);

            // 因为这个函数首先是独立编译的，所以这个检查告诉 LLVM 下面的索引是在边界内的。
            // 然后在内联之后 -- 一旦知道了切片的实际长度 -- 它就会被删除。
            //
            //
            let (a, b) = (&mut a[..n], &mut b[..n]);

            for i in 0..n {
                mem::swap(&mut a[i], &mut b[n - 1 - i]);
            }
        }
    }

    /// 返回切片上的迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// 返回允许修改每个值的迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// 返回长度为 `size` 的所有连续 windows 上的迭代器。
    /// windows 重叠。
    /// 如果切片短于 `size`，则迭代器不返回任何值。
    ///
    /// # Panics
    ///
    /// 如果 `size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果切片短于 `size`：
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// 从切片的开头开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是切片，并且不重叠。如果 `chunk_size` 不划分切片的长度，则最后一块的长度将不为 `chunk_size`。
    ///
    /// 有关此迭代器的变体的信息，请参见 [`chunks_exact`]，它返回始终完全由 `chunk_size` 元素组成的块; 对于相同迭代器，请参见 [`rchunks`]，但均从切片的末尾开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// 从切片的开头开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是可变切片，并且不重叠。如果 `chunk_size` 不划分切片的长度，则最后一块的长度将不为 `chunk_size`。
    ///
    /// 有关此迭代器的变体的信息，请参见 [`chunks_exact_mut`]，该变体返回始终完全相同的 `chunk_size` 元素的块; 对于相同的迭代器，请参见 [`rchunks_mut`]，但均从切片的末尾开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// 从切片的开头开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是切片，并且不重叠。
    /// 如果 `chunk_size` 不划分切片的长度，则最后 `chunk_size-1` 个元素将被省略，并可从迭代器的 `remainder` 函数中检索。
    ///
    ///
    /// 由于每个块都具有完全 `chunk_size` 元素，因此与 [`chunks`] 相比，编译器通常可以更好地优化结果代码。
    ///
    /// 请参见 [`chunks`] 以获取此迭代器的变体，该变体还以较小的块的形式返回其余部分，并以 [`rchunks_exact`] 获取相同的迭代器，但从切片的末尾开始。
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// 从切片的开头开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是可变切片，并且不重叠。
    /// 如果 `chunk_size` 不划分切片的长度，则最后 `chunk_size-1` 个元素将被省略，并可从迭代器的 `into_remainder` 函数中检索。
    ///
    ///
    /// 由于每个块都具有完全 `chunk_size` 元素，因此与 [`chunks_mut`] 相比，编译器通常可以更好地优化结果代码。
    ///
    /// 请参见 [`chunks_mut`] 以获取此迭代器的变体，该变体还以较小的块的形式返回其余部分，并以 [`rchunks_exact_mut`] 获取相同的迭代器，但从切片的末尾开始。
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// 假设没有余数，将切片拆分为 N 个元素数组的切片。
    ///
    ///
    /// # Safety
    ///
    /// 只能在以下情况下调用
    /// - 切片精确地分为 `N` 个元素块 (也称为 `self.len() % N == 0`)。
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: 1 个元素的块永远不会剩余
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: 切片长度 (6) 是 3 的倍数
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // 这些是不健全的：
    /// // `let chunks: &[[_; 5]] = slice.as_chunks_unchecked()` // 切片长度不是 5 个的倍数: `let chunks: &[[_; 0]] = slice.as_chunks_unchecked()` // 永远不允许零长度的块
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: 我们的先决条件恰恰是调用此命令所需要的
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: 我们将 `new_len * N` 元素的切片转换为 `new_len` 的切片，其中包含许多 `N` 元素块。
        //
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// 从切片的开头开始，将切片分成 `N` 个元素数组的切片，然后将其长度严格小于 `N` 的其余切片切成薄片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: 我们已经 panic 为零，并通过构造确保子切片的长度是 N 的倍数。
        //
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// 从切片的末尾开始，将切片分成 `N` 个元素数组的切片，然后将其长度严格小于 `N` 的其余切片切成薄片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: 我们已经 panic 为零，并通过构造确保子切片的长度是 N 的倍数。
        //
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// 从切片的开头开始，一次返回对切片的 `N` 元素的迭代器。
    ///
    /// 这些块是数组引用，并且不重叠。
    /// 如果 `N` 不划分切片的长度，则最后 `N-1` 个元素将被省略，并可从迭代器的 `remainder` 函数中检索。
    ///
    ///
    /// 此方法与 [`chunks_exact`] 等效为 const 泛型。
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// 假设没有余数，将切片拆分为 N 个元素数组的切片。
    ///
    ///
    /// # Safety
    ///
    /// 只能在以下情况下调用
    /// - 切片精确地分为 `N` 个元素块 (也称为 `self.len() % N == 0`)。
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: 1 个元素的块永远不会剩余
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: 切片长度 (6) 是 3 的倍数
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // 这些是不健全的：
    /// // `let chunks: &[[_; 5]] = slice.as_chunks_unchecked_mut()` // 切片长度不是 5 的倍数: `let chunks: &[[_; 0]] = slice.as_chunks_unchecked_mut()` // 永远不允许零长度的块
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: 我们的先决条件恰恰是调用此命令所需要的
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: 我们将 `new_len * N` 元素的切片转换为 `new_len` 的切片，其中包含许多 `N` 元素块。
        //
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// 从切片的开头开始，将切片分成 `N` 个元素数组的切片，然后将其长度严格小于 `N` 的其余切片切成薄片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: 我们已经 panic 为零，并通过构造确保子切片的长度是 N 的倍数。
        //
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// 从切片的末尾开始，将切片分成 `N` 个元素数组的切片，然后将其长度严格小于 `N` 的其余切片切成薄片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: 我们已经 panic 为零，并通过构造确保子切片的长度是 N 的倍数。
        //
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// 从切片的开头开始，一次返回对切片的 `N` 元素的迭代器。
    ///
    /// 这些块是可变数组引用，并且不重叠。
    /// 如果 `N` 不划分切片的长度，则最后 `N-1` 个元素将被省略，并可从迭代器的 `into_remainder` 函数中检索。
    ///
    ///
    /// 此方法与 [`chunks_exact_mut`] 等效为 const 泛型。
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// 从切片的开头开始，在切片的 `N` 元素的重叠 windows 上返回迭代器。
    ///
    ///
    /// 这是 [`windows`] 的 const 泛型等效项。
    ///
    /// 如果 `N` 大于切片的大小，则不会返回 windows。
    ///
    /// # Panics
    ///
    /// 如果 `N` 为 0，就会出现 panics。
    /// 在此方法稳定之前，此检查很可能会更改为编译时错误。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// 从切片的末尾开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是切片，并且不重叠。如果 `chunk_size` 不划分切片的长度，则最后一块的长度将不为 `chunk_size`。
    ///
    /// 有关此迭代器的变体的信息，请参见 [`rchunks_exact`]，该变体返回始终完全相同的 `chunk_size` 元素的块; 对于相同的迭代器，请参见 [`chunks`]，但从切片的开头开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// 从切片的末尾开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是可变切片，并且不重叠。如果 `chunk_size` 不划分切片的长度，则最后一块的长度将不为 `chunk_size`。
    ///
    /// 有关此迭代器的变体的信息，请参见 [`rchunks_exact_mut`]，该变体返回始终完全相同的 `chunk_size` 元素的块; 对于相同的迭代器，请参见 [`chunks_mut`]，但从切片的开头开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// 从切片的末尾开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是切片，并且不重叠。
    /// 如果 `chunk_size` 不划分切片的长度，则最后 `chunk_size-1` 个元素将被省略，并可从迭代器的 `remainder` 函数中检索。
    ///
    /// 由于每个块都具有完全 `chunk_size` 元素，因此与 [`chunks`] 相比，编译器通常可以更好地优化结果代码。
    ///
    /// 请参见 [`rchunks`] 以获取此迭代器的变体，该变体还以较小的块的形式返回其余部分，并以 [`chunks_exact`] 获取相同的迭代器，但从切片的开头开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// 从切片的末尾开始，一次返回对切片的 `chunk_size` 元素的迭代器。
    ///
    /// 块是可变切片，并且不重叠。
    /// 如果 `chunk_size` 不划分切片的长度，则最后 `chunk_size-1` 个元素将被省略，并可从迭代器的 `into_remainder` 函数中检索。
    ///
    /// 由于每个块都具有完全 `chunk_size` 元素，因此与 [`chunks_mut`] 相比，编译器通常可以更好地优化结果代码。
    ///
    /// 请参见 [`rchunks_mut`] 以获取此迭代器的变体，该变体还以较小的块的形式返回其余部分，并以 [`chunks_exact_mut`] 获取相同的迭代器，但从切片的开头开始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 为 0，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// 返回在切片上使用迭代器生成迭代器的迭代器，这些谓词使用谓词将它们分隔开。
    ///
    /// 谓词在紧随其后的两个元素上调用，这意味着谓词在 `slice[0]` 和 `slice[1]` 上调用，然后在 `slice[1]` 和 `slice[2]` 上调用，依此类推。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 此方法可用于提取排序的子切片：
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// 返回在切片上使用谓词将其分离的迭代器，以生成不重叠的可变元素游程。
    ///
    /// 谓词在紧随其后的两个元素上调用，这意味着谓词在 `slice[0]` 和 `slice[1]` 上调用，然后在 `slice[1]` 和 `slice[2]` 上调用，依此类推。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 此方法可用于提取排序的子切片：
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// 在索引处将一个切片分为两个。
    ///
    /// 第一个将包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二个将包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果为 `mid > len`，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` 和 `[mid; len]` 在 `self` 内部，可以满足 `from_raw_parts_mut` 的要求。
        //
        unsafe { self.split_at_unchecked(mid) }
    }

    /// 在索引处将一个可变切片分成两个。
    ///
    /// 第一个将包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二个将包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果为 `mid > len`，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` 和 `[mid; len]` 在 `self` 内部，可以满足 `from_raw_parts_mut` 的要求。
        //
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// 在索引处将一个切片分为两个，而无需进行边界检查。
    ///
    /// 第一个将包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二个将包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// 有关安全的选择，请参见 [`split_at`]。
    ///
    /// # Safety
    ///
    /// 即使没有使用所得的引用，使用越界索引调用此方法也是 *[undefined behavior]*。调用者必须确保 `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    pub unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: 调用者必须检查 `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// 在索引处将一个可变切片分为两个，而无需进行边界检查。
    ///
    /// 第一个将包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二个将包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// 有关安全的选择，请参见 [`split_at_mut`]。
    ///
    /// # Safety
    ///
    /// 即使没有使用所得的引用，使用越界索引调用此方法也是 *[undefined behavior]*。调用者必须确保 `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // 限制借用的生命周期
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    pub unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: 调用者必须检查 `0 <= mid <= self.len()`。
        //
        // `[ptr; mid]` 和 `[mid; len]` 不重叠，所以返回一个资源引用就好了。
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// 将一个切片分成一个数组和一个索引处的剩余切片。
    ///
    /// 该数组将包含来自 `[0, N)` 的所有索引 (不包括索引 `N` 本身)，并且切片将包含来自 `[N, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N > len`，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(split_array)]
    ///
    /// let v = &[1, 2, 3, 4, 5, 6][..];
    ///
    /// {
    ///    let (left, right) = v.split_array_ref::<0>();
    ///    assert_eq!(left, &[]);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_array_ref::<2>();
    ///     assert_eq!(left, &[1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_array_ref::<6>();
    ///     assert_eq!(left, &[1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[unstable(feature = "split_array", reason = "new API", issue = "90091")]
    #[inline]
    pub fn split_array_ref<const N: usize>(&self) -> (&[T; N], &[T]) {
        let (a, b) = self.split_at(N);
        // SAFETY: 一个指针指向了 [T; N]？ 是的，它是长度 N 的 [T] (由 split_at 检查)
        unsafe { (&*(a.as_ptr() as *const [T; N]), b) }
    }

    /// 将一个可变切片分成一个数组和一个索引处的剩余切片。
    ///
    /// 该数组将包含来自 `[0, N)` 的所有索引 (不包括索引 `N` 本身)，并且切片将包含来自 `[N, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N > len`，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(split_array)]
    ///
    /// let mut v = &mut [1, 0, 3, 0, 5, 6][..];
    /// let (left, right) = v.split_array_mut::<2>();
    /// assert_eq!(left, &mut [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[unstable(feature = "split_array", reason = "new API", issue = "90091")]
    #[inline]
    pub fn split_array_mut<const N: usize>(&mut self) -> (&mut [T; N], &mut [T]) {
        let (a, b) = self.split_at_mut(N);
        // SAFETY: 一个指针指向了 [T; N]？ 是的，它是长度 N 的 [T] (由 split_at_mut 检查)
        unsafe { (&mut *(a.as_mut_ptr() as *mut [T; N]), b) }
    }

    /// 返回由与 `pred` 匹配的元素分隔的子切片上的迭代器。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果第一个元素匹配，则空切片将是迭代器返回的第一个项。
    /// 同样，如果切片中的最后一个元素匹配，则空切片将是迭代器返回的最后一个项：
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果两个匹配的元素直接相邻，则它们之间将出现一个空的切片：
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// 返回由匹配 `pred` 的元素分隔的可变子切片上的迭代器。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// 返回由与 `pred` 匹配的元素分隔的子切片上的迭代器。
    /// 匹配的元素包含在上一个子切片的末尾作为终止符。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果切片的最后一个元素匹配，则该元素将被视为前一个切片的终止符。
    ///
    /// 该切片将是迭代器返回的最后一个项目。
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// 返回由匹配 `pred` 的元素分隔的可变子切片上的迭代器。
    /// 匹配的元素作为终止符包含在先前的子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// 在子切片上返回一个迭代器，该迭代器由与 `pred` 匹配的元素分隔，从切片的末尾开始并向后工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 与 `split()` 一样，如果第一个或最后一个元素匹配，则空切片将是迭代器返回的第一个 (或最后一个) 项。
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// 返回在可变子切片上的迭代器，该子切片由与 `pred` 匹配的元素分隔，从切片的末尾开始并向后工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// 在子切片上返回一个迭代器，该子切片由与 `pred` 匹配的元素分隔，限于最多返回 `n` 项。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最后一个元素 (如果有) 将包含切片的其余部分。
    ///
    /// # Examples
    ///
    /// 按 3 的整数倍数 (即 `[10, 40]`，`[20, 60, 50]`) 打印一次切片分割：
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// 在子切片上返回一个迭代器，该子切片由与 `pred` 匹配的元素分隔，限于最多返回 `n` 项。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最后一个元素 (如果有) 将包含切片的其余部分。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// 在子切片上返回一个迭代器，该子切片由与 `pred` 匹配的元素分隔，最多只能返回 `n` 项。
    /// 该操作从切片的末尾开始并向后工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最后一个元素 (如果有) 将包含切片的其余部分。
    ///
    /// # Examples
    ///
    /// 从末尾开始，将切片拆分打印一次，并被 3 整除的数字 (即 `[50]`，`[10, 40, 30, 20]`) ：
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// 在子切片上返回一个迭代器，该子切片由与 `pred` 匹配的元素分隔，最多只能返回 `n` 项。
    /// 该操作从切片的末尾开始并向后工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最后一个元素 (如果有) 将包含切片的其余部分。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// 如果切片包含具有给定值的元素，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// 如果您没有 `&T`，但有其他一些可以与之比较的值 (例如，`String` 实现 `PartialEq<str>`)，则可以使用 `iter().any`：
    ///
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` 切片
    /// assert!(v.iter().any(|e| e == "hello")); // 用 `&str` 搜索
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// 如果 `needle` 是切片的前缀，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// 如果 `needle` 为空切片，则始终返回 `true`：
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// 如果 `needle` 是切片的后缀，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// 如果 `needle` 为空切片，则始终返回 `true`：
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// 返回带有删除的前缀的子切片。
    ///
    /// 如果切片以 `prefix` 开头，则返回前缀在 `Some` 中的子切片。
    /// 如果 `prefix` 为空，则只需返回原始切片。
    ///
    /// 如果切片不是以 `prefix` 开头，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 当 SlicePattern 变得更加复杂时，将需要重写此函数。
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// 返回删除后缀的子分片。
    ///
    /// 如果切片以 `suffix` 结尾，则返回后缀在 `Some` 中的子切片。
    /// 如果 `suffix` 为空，则只需返回原始切片。
    ///
    /// 如果切片不以 `suffix` 结尾，则返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 当 SlicePattern 变得更加复杂时，将需要重写此函数。
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary 在排序后的切片中搜索给定的元素。
    ///
    /// 如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。
    /// 如果有多个匹配项，则可以返回任何一个匹配项。
    /// 索引的选择是确定的，但在 Rust 的未来版本中可能会发生变化。
    /// 如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。
    ///
    ///
    /// 另请参见 [`binary_search_by`]，[`binary_search_by_key`] 和 [`partition_point`]。
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 查找一系列四个元素。
    /// 找到第一个，具有唯一确定的位置； 没有找到第二个和第三个； 第四个可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// 如果要在排序的 vector 中插入项目，同时保持排序顺序，请执行以下操作：
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary 使用比较器函数搜索排序后的切片。
    ///
    /// comparator 函数应该实现一个与底层切片的排序顺序一致的顺序，返回一个顺序代码，并指示其参数期望的目标是 `Less`，`Equal` 还是 `Greater`。
    ///
    ///
    /// 如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。如果有多个匹配项，则可以返回任何一个匹配项。
    /// 索引的选择是确定的，但在 Rust 的未来版本中可能会发生变化。
    /// 如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。
    ///
    /// 另请参见 [`binary_search`]，[`binary_search_by_key`] 和 [`partition_point`]。
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 查找一系列四个元素。找到第一个，具有唯一确定的位置； 没有找到第二个和第三个； 第四个可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SAFETY: 通过以下不变量可以确保调用的安全性：
            // - `mid >= 0`
            // - `mid < size`: `mid` 受 `[left; right)` 约束。
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // 我们之所以使用 if/else 控制流而不是 match 的原因是因为 match 对性能比较敏感的比较操作进行重新排序。
            //
            // 这是 u8 的 x86 汇编: https://rust.godbolt.org/z/8Y8Pra。
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                // SAFETY: 与上面的 `get_unchecked` 相同
                unsafe { crate::intrinsics::assume(mid < self.len()) };
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary 使用关键字提取函数搜索排序后的切片。
    ///
    /// 假定按关键字对切片进行排序，例如使用相同的关键字提取函数对 [`sort_by_key`] 进行排序。
    ///
    /// 如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。
    /// 如果有多个匹配项，则可以返回任何一个匹配项。
    /// 索引的选择是确定的，但在 Rust 的未来版本中可能会发生变化。
    /// 如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。
    ///
    ///
    /// 另请参见 [`binary_search`]，[`binary_search_by`] 和 [`partition_point`]。
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 在成对的切片中按其第二个元素排序的一系列四个元素中查找。
    /// 找到第一个，具有唯一确定的位置； 没有找到第二个和第三个； 第四个可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links 是允许的，因为 `slice::sort_by_key` 在 crate `alloc` 中，因此在构建 `core`: #74481 时还不存在。
    //
    // 当切片显示在核心中时，这会断开链接，但将其更改为使用相对链接会在项目重新导出时断开。
    // 所以现在允许核心链接被破坏。
    #[allow(rustdoc::broken_intra_doc_links)]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// 对三个元素进行排序，但可能不保留相等元素的顺序。
    ///
    /// 这种排序是不稳定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(*n*\*log(* n*)) 最坏的情况)。
    ///
    /// # 当前实现
    ///
    /// 当前算法基于 Orson Peters 的 [pattern-defeating 的快速排序][pdqsort]，该算法将随机快速排序的快速平均情况与堆排序的快速最坏情况相结合，同时在具有特定模式的切片上实现了线性时间。
    /// 它使用一些随机化来避免退化的情况，但是使用固定的 seed 来始终提供确定性的行为。
    ///
    /// 除了在一些特殊情况下 (例如，当切片由多个串联的排序序列组成) 以外，它通常比稳定排序快。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// 使用比较器函数对三元进行排序，但可能不保留相等元素的顺序。
    ///
    /// 这种排序是不稳定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(*n*\*log(* n*)) 最坏的情况)。
    ///
    /// 比较器函数必须为切片中的元素定义总顺序。如果排序不全，则元素的顺序是未指定的。如果一个顺序是 (对于所有的`a`, `b` 和 `c`)，那么它就是一个总体顺序
    ///
    /// * 完全和反对称的: `a < b`，`a == b` 或 `a > b` 之一正确，并且
    /// * 可传递的，`a < b` 和 `b < c` 表示 `a < c`。`==` 和 `>` 必须保持相同。
    ///
    /// 例如，虽然 [`f64`] 由于 `NaN != NaN` 而不实现 [`Ord`]，但是当我们知道切片不包含 `NaN` 时，可以将 `partial_cmp` 用作我们的排序函数。
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # 当前实现
    ///
    /// 当前算法基于 Orson Peters 的 [pattern-defeating 的快速排序][pdqsort]，该算法将随机快速排序的快速平均情况与堆排序的快速最坏情况相结合，同时在具有特定模式的切片上实现了线性时间。
    /// 它使用一些随机化来避免退化的情况，但是使用固定的 seed 来始终提供确定性的行为。
    ///
    /// 除了在一些特殊情况下 (例如，当切片由多个串联的排序序列组成) 以外，它通常比稳定排序快。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 反向排序
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// 使用键提取函数对三个元素进行排序，但可能不保留相等元素的顺序。
    ///
    /// 这种排序是不稳定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(m\* * n *\* log(*n*)) 最坏的情况，其中键函数为 *O*(*m*)。
    ///
    /// # 当前实现
    ///
    /// 当前算法基于 Orson Peters 的 [pattern-defeating 的快速排序][pdqsort]，该算法将随机快速排序的快速平均情况与堆排序的快速最坏情况相结合，同时在具有特定模式的切片上实现了线性时间。
    /// 它使用一些随机化来避免退化的情况，但是使用固定的 seed 来始终提供确定性的行为。
    ///
    /// 由于其键调用策略，在键函数很昂贵的情况下，[`sort_unstable_by_key`](#method.sort_unstable_by_key) 可能比 [`sort_by_cached_key`](#method.sort_by_cached_key) 慢。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// 重新排序切片，以使 `index` 处的元素处于其最终排序位置。
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// 使用比较器函数对切片进行重新排序，以使 `index` 处的元素处于其最终排序位置。
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// 使用键提取函数对切片进行重新排序，以使 `index` 处的元素处于其最终排序位置。
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// 重新排序切片，以使 `index` 处的元素处于其最终排序位置。
    ///
    /// 此重新排序具有附加属性，即位置 `i < index` 处的任何值都将小于或等于位置 `j > index` 处的任何值。
    /// 此外，这种重新排序是不稳定的 (即
    /// 任何数量的相等元素都可以在位置 `index` 处就位 (即
    /// 不分配)，以及 *O*(*n*) 最坏的情况。
    /// 在其他库中，该函数也被称为 "kth element"。
    /// 它返回以下值的三元组：所有元素在给定索引处小于一个，在给定索引处的值，以及所有在给定索引处大于一个的元素。
    ///
    ///
    /// # 当前实现
    ///
    /// 当前算法基于用于 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 时为 Panics，这意味着在空片上始终为 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 找到中位数
    /// v.select_nth_unstable(2);
    ///
    /// // 根据我们对指定索引的排序方式，我们仅保证切片将是以下内容之一。
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// 使用比较器函数对切片进行重新排序，以使 `index` 处的元素处于其最终排序位置。
    ///
    /// 此重排序具有附加属性，即使用比较器函数，位置 `i < index` 处的任何值将小于或等于位置 `j > index` 处的任何值。
    /// 另外，这种重新排序是不稳定的 (即，任意数量的相等元素可能会在位置 `index` 处结束)，就地 (即，未分配) 和 *O*(*n*) 最坏的情况。
    /// 此函数在其他库中也称为 "kth element"。
    /// 它使用提供的比较器函数返回以下值的三元组：所有元素小于给定索引处的元素，给定索引处的值以及所有元素大于给定索引处的元素。
    ///
    ///
    /// # 当前实现
    ///
    /// 当前算法基于用于 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 时为 Panics，这意味着在空片上始终为 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 查找中间值，好像切片是按降序排序的。
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // 根据我们对指定索引的排序方式，我们仅保证切片将是以下内容之一。
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// 使用键提取函数对切片进行重新排序，以使 `index` 处的元素处于其最终排序位置。
    ///
    /// 此重新排序具有附加属性，即使用键提取函数，位置 `i < index` 处的任何值将小于或等于位置 `j > index` 处的任何值。
    /// 另外，这种重新排序是不稳定的 (即，任意数量的相等元素可能会在位置 `index` 处结束)，就地 (即，未分配) 和 *O*(*n*) 最坏的情况。
    /// 此函数在其他库中也称为 "kth element"。
    /// 它使用提供的键提取函数返回以下值的三元组：所有元素小于给定索引处的元素，给定索引处的值以及所有元素大于给定索引处的元素。
    ///
    ///
    /// # 当前实现
    ///
    /// 当前算法基于用于 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 时为 Panics，这意味着在空片上始终为 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 返回中间值，就好像数组是根据绝对值排序的一样。
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // 根据我们对指定索引的排序方式，我们仅保证切片将是以下内容之一。
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// 根据 [`PartialEq`] trait 实现，将所有连续的重复元素移动到切片的末尾。
    ///
    ///
    /// 返回两个切片。第一个不包含连续的重复元素。
    /// 第二个包含没有指定顺序的所有重复项。
    ///
    /// 如果对切片进行排序，则第一个返回的切片不包含重复项。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// 将除第一个连续元素之外的所有元素移动到满足给定相等关系的切片的末尾。
    ///
    /// 返回两个切片。第一个不包含连续的重复元素。
    /// 第二个包含没有指定顺序的所有重复项。
    ///
    /// `same_bucket` 函数被引用传递给切片中的两个元素，并且必须确定这些元素是否相等。
    /// 元素以与它们在切片中的顺序相反的顺序传递，因此，如果 `same_bucket(a, b)` 返回 `true`，则 `a` 将在切片的末尾移动。
    ///
    ///
    /// 如果对切片进行排序，则第一个返回的切片不包含重复项。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // 尽管我们对 `self` 有一个可变的引用，但是我们不能进行 *任意* 的更改。`same_bucket` 调用可能为 panic，因此我们必须确保切片始终处于有效状态。
        //
        // 我们处理此问题的方法是使用交换。我们遍历所有元素，并随即交换，以使最后我们希望保留的元素在最前面，而我们希望拒绝的元素在后面。
        // 然后我们可以分割切片。
        // 此操作仍为 `O(n)`。
        //
        // 示例：我们从这种状态开始，其中 `r` 代表 "next read"，`w` 代表 `next_write`。
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // 将 self[r] 与 self[w-1] 进行比较，这不是重复项，因此我们交换 self[r] 和 self[w] (因为 r == w 无效)，然后将 r 和 w 都递增，所以我们得到：
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // 将 self[r] 与 self[w-1] 进行比较，该值是重复的，因此我们增加 `r`，但其他所有内容保持不变：
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // 比较 self[r] 与 self[w-1]，这不是重复项，因此交换 self[r] 和 self[w] 并前进 r 和 w：
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // 不能重复，请重复：
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // 重复，前进 r。切片的末尾。在 w 处分割。
        //
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: `while` 条件确保 `next_read` 和 `next_write` 小于 `len`，因此在 `self` 内部。
        // `prev_ptr_write` 指向 `ptr_write` 之前的一个元素，但 `next_write` 从 1 开始，因此 `prev_ptr_write` 永远不会小于 0 并且在切片内。
        // 这满足了解引用 `ptr_read`，`prev_ptr_write` 和 `ptr_write` 以及使用 `ptr.add(next_read)`，`ptr.add(next_write - 1)` 和 `prev_ptr_write.offset(1)` 的要求。
        //
        //
        // `next_write` 也最多在每个循环中递增一次，这意味着在可能需要交换元素时不会跳过任何元素。
        //
        // `ptr_read` 和 `prev_ptr_write` 从不指向同一个元素。为了确保 `&mut *ptr_read`，`&mut* prev_ptr_write` 的安全，这是必需的。
        // 解释很简单，如果 `next_read >= next_write` 始终为 true，那么 `next_read > next_write - 1` 也是如此。
        //
        //
        //
        //
        //
        //
        unsafe {
            // 通过使用裸指针避免边界检查。
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// 将除了第一个连续元素之外的所有元素移动到解析为相同键的切片的末尾。
    ///
    ///
    /// 返回两个切片。第一个不包含连续的重复元素。
    /// 第二个包含没有指定顺序的所有重复项。
    ///
    /// 如果对切片进行排序，则第一个返回的切片不包含重复项。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// 就地旋转切片，以使切片的第一个 `mid` 元素移至末尾，而最后一个 `self.len() - mid` 元素移至前端。
    /// 调用 `rotate_left` 后，先前在索引 `mid` 处的元素将成为切片中的第一个元素。
    ///
    /// # Panics
    ///
    /// 如果 `mid` 大于切片的长度，则此函数将为 panic。请注意，`mid == self.len()` 执行 _not_ panic，并且是无操作旋转。
    ///
    /// # Complexity
    ///
    /// 花费线性时间 (以 `self.len()` 为单位)。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// 旋转子切片：
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: 根据 `ptr_rotate` 的要求，范围 `[p.add(mid) - mid, p.add(mid) + k)` 对于读取和写入非常有效。
        //
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// 就地旋转切片，以使切片的第一个 `self.len() - k` 元素移至末尾，而最后一个 `k` 元素移至前端。
    /// 调用 `rotate_right` 后，先前在索引 `self.len() - k` 处的元素将成为切片中的第一个元素。
    ///
    /// # Panics
    ///
    /// 如果 `k` 大于切片的长度，则此函数将为 panic。请注意，`k == self.len()` 执行 _not_ panic，并且是无操作旋转。
    ///
    /// # Complexity
    ///
    /// 花费线性时间 (以 `self.len()` 为单位)。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// 旋转子切片：
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: 根据 `ptr_rotate` 的要求，范围 `[p.add(mid) - mid, p.add(mid) + k)` 对于读取和写入非常有效。
        //
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// 通过克隆 `value`，用元素填充 `self`。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// 用重复调用闭包返回的元素填充 `self`。
    ///
    /// 此方法使用闭包创建新值。如果您希望给定值 [`Clone`]，请使用 [`fill`]。
    /// 如果要使用 [`Default`] trait 生成值，则可以传递 [`Default::default`] 作为参数。
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// 将元素从 `src` 复制到 `self`。
    ///
    /// `src` 的长度必须与 `self` 相同。
    ///
    /// # Panics
    ///
    /// 如果两个切片的长度不同，则此函数将为 panic。
    ///
    /// # Examples
    ///
    /// 将一个切片中的两个元素克隆到另一个中：
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 由于切片必须具有相同的长度，因此我们将源切片从四个元素切成两个。
    /// // 如果不这样做，它将为 panic。
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 强制规定在特定范围内只能有一个可变引用，而没有对特定数据段的不可变引用。
    /// 因此，尝试在单个切片上使用 `clone_from_slice` 将导致编译失败：
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // 编译失败！
    /// ```
    ///
    /// 要解决此问题，我们可以使用 [`split_at_mut`] 从切片创建两个不同的子切片：
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    #[track_caller]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// 使用 memcpy 将所有元素从 `src` 复制到 `self`。
    ///
    /// `src` 的长度必须与 `self` 相同。
    ///
    /// 如果 `T` 未实现 `Copy`，请使用 [`clone_from_slice`]。
    ///
    /// # Panics
    ///
    /// 如果两个切片的长度不同，则此函数将为 panic。
    ///
    /// # Examples
    ///
    /// 将切片中的两个元素复制到另一个中：
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 由于切片必须具有相同的长度，因此我们将源切片从四个元素切成两个。
    /// // 如果不这样做，它将为 panic。
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 强制规定在特定范围内只能有一个可变引用，而没有对特定数据段的不可变引用。
    /// 因此，尝试在单个切片上使用 `copy_from_slice` 将导致编译失败：
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // 编译失败！
    /// ```
    ///
    /// 要解决此问题，我们可以使用 [`split_at_mut`] 从切片创建两个不同的子切片：
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    #[track_caller]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic 代码路径被放入到 cold 函数中，以免使调用点 (call site) 膨胀 (bloat)。
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: 根据定义，`self` 对 `self.len()` 元素有效，并且检查 `src` 具有相同的长度。
        // 切片不能重叠，因为可变引用是排他的。
        //
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// 使用记忆膜将元素从切片的一部分复制到自身的另一部分。
    ///
    /// `src` 是 `self` 内要复制的范围。
    /// `dest` 是要复制到的 `self` 范围内的起始索引，其长度与 `src` 相同。
    /// 这两个范围可能会重叠。
    /// 两个范围的末端必须小于或等于 `self.len()`。
    ///
    /// # Panics
    ///
    /// 如果任一范围超出了切片的末尾，或者 `src` 的末尾在开始点之前，则此函数将为 panic。
    ///
    ///
    /// # Examples
    ///
    /// 在切片中复制四个字节：
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: `ptr::copy` 的条件以及 `ptr::add` 的条件均已在上面进行了检查。
        //
        unsafe {
            // 从同一个 loan 派生 `src_ptr` 和 `dest_ptr`
            let ptr = self.as_mut_ptr();
            let src_ptr = ptr.add(src_start);
            let dest_ptr = ptr.add(dest);
            ptr::copy(src_ptr, dest_ptr, count);
        }
    }

    /// 交换 `self` 中的所有元素和 `other` 中的所有元素。
    ///
    /// `other` 的长度必须与 `self` 相同。
    ///
    /// # Panics
    ///
    /// 如果两个切片的长度不同，则此函数将为 panic。
    ///
    /// # Example
    ///
    /// 在切片之间交换两个元素：
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust 强制规定在特定范围内只能有一个对特定数据的可变引用。
    ///
    /// 因此，尝试在单个切片上使用 `swap_with_slice` 将导致编译失败：
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // 编译失败！
    /// ```
    ///
    /// 要解决此问题，我们可以使用 [`split_at_mut`] 从切片创建两个不同的可变子切片：
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    #[track_caller]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: 根据定义，`self` 对 `self.len()` 元素有效，并且检查 `src` 具有相同的长度。
        // 切片不能重叠，因为可变引用是排他的。
        //
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// 该函数可计算 `align_to{,_mut}` 的中间和尾随切片的长度。
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // 我们要对 `rest` 采取的措施是弄清楚我们可以在最低数量的 T 中放入 U 的倍数。
        //
        // 对于每个这样的 "multiple"，我们需要多少个 T。
        //
        // 考虑例如 T = u8 U = u16。然后我们可以在 2 Ts 中放入 1U。Simple.
        // 现在，考虑一个例子，其中 size_of::<T>=16，size_of::<U>=24。</u>
        // 我们可以在 `rest` 切片中每 3 个 T 放 2 个 Us。
        // 有点复杂。
        //
        // 计算公式为：
        //
        // Us = lcm(size_of::<T>, size_of::<U>) / size_of::<U> Ts = lcm(size_of::<T>, size_of::<U>) / size_of::<T>
        //
        // 扩展和简化：
        //
        // Us = size_of::<T> / gcd(size_of::<T>, size_of::<U>) Ts = size_of::<U> / gcd(size_of::<T>, size_of::<U>)
        //
        // 幸运的是，由于所有这些都是经过常量评估的... 这里的性能无关紧要！
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // 迭代施泰因算法我们仍然应该使这个 `const fn` (如果需要的话，请还原为递归算法)，因为依靠 llvm 来约束所有这些都是……好吧，这让我感到不舒服。
            //
            //

            // SAFETY: `a` 和 `b` 被检查为非零值。
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 从 b 删除 2 的所有因子
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: `b` 被检查为非零。
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // 有了这些知识，我们就能找到可以容纳多少个 `U`s!
        let us_len = self.len() / ts * us;
        // 以及后面的切片中将有多少个 T`s!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// 将切片转换为其他类型的切片，以确保保持类型的对齐。
    ///
    /// 此方法将切片分为三个不同的切片：前缀，正确对齐的新类型的中间切片和后缀切片。
    /// 该方法可以使中间切片对于给定类型和输入切片的最大长度成为可能，但是仅算法的性能应取决于此，而不取决于其正确性。
    ///
    /// 允许所有输入数据作为前缀或后缀切片返回。
    ///
    /// 当输入元素 `T` 或输出元素 `U` 的大小为零时，此方法无用，并且将返回原始切片而不拆分任何内容。
    ///
    /// # Safety
    ///
    /// 对于返回的中间切片中的元素，此方法本质上是 `transmute`，因此，与 `transmute::<T, U>` 有关的所有常见警告也适用于此。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // 请注意，大多数此函数将进行常量评估，
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // 专门处理 ZST，这是 - 根本不处理它们。
            return (self, &[], &[]);
        }

        // 首先，找出我们在第一和第二切片之间分割的时间。
        // ptr.align_offset 轻松实现。
        let ptr = self.as_ptr();
        // SAFETY: 有关详细的安全说明，请参见 `align_to_mut` 方法。
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: 现在 `rest` 绝对对齐，因此下面的 `from_raw_parts` 没问题，因为调用者保证我们可以安全地将 `T` 转换为 `U`。
            //
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// 将切片转换为其他类型的切片，以确保保持类型的对齐。
    ///
    /// 此方法将切片分为三个不同的切片：前缀，正确对齐的新类型的中间切片和后缀切片。
    /// 该方法可以使中间切片对于给定类型和输入切片的最大长度成为可能，但是仅算法的性能应取决于此，而不取决于其正确性。
    ///
    /// 允许所有输入数据作为前缀或后缀切片返回。
    ///
    /// 当输入元素 `T` 或输出元素 `U` 的大小为零时，此方法无用，并且将返回原始切片而不拆分任何内容。
    ///
    /// # Safety
    ///
    /// 对于返回的中间切片中的元素，此方法本质上是 `transmute`，因此，与 `transmute::<T, U>` 有关的所有常见警告也适用于此。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // 请注意，大多数此函数将进行常量评估，
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // 专门处理 ZST，这是 - 根本不处理它们。
            return (self, &mut [], &mut []);
        }

        // 首先，找出我们在第一和第二切片之间分割的时间。
        // ptr.align_offset 轻松实现。
        let ptr = self.as_ptr();
        // SAFETY: 在这里，我们确保在方法的其余部分中将对 U 使用对齐的指针。这是通过向 &[T] with 传递一个指向 U 的对齐方式来完成的。
        // 使用正确对齐且有效的指针 `ptr` (它来自对 `self` 的引用) 和大小为 2 的幂 (因为它来自 U 的对齐) 调用 `crate::ptr::align_offset`，满足其安全约束。
        //
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // 此后我们将无法再次使用 `rest`，这将使其别名 `mut_ptr` 失效！
            // SAFETY: 请参见 `align_to` 的注释。
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// 检查此切片的元素是否已排序。
    ///
    /// 也就是说，对于每个元素 `a` 及其后续元素 `b`，`a <= b` 必须成立。如果切片产生恰好产生零个或一个元素，则返回 `true`。
    ///
    /// 请注意，如果 `Self::Item` 仅是 `PartialOrd`，而不是 `Ord`，则上述定义意味着，如果任何两个连续的项都不具有可比性，则此函数将返回 `false`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// 检查此切片的元素是否使用给定的比较器函数进行排序。
    ///
    /// 该函数使用给定的 `compare` 函数来确定两个元素的顺序，而不是使用 `PartialOrd::partial_cmp`。
    /// 除此之外，它等效于 [`is_sorted`]。有关更多信息，请参见其文档。
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// 检查此切片的元素是否使用给定的键提取函数进行排序。
    ///
    /// 该函数将直接比较由 `f` 确定的元素的键，而不是直接比较切片的元素。
    /// 除此之外，它等效于 [`is_sorted`]。有关更多信息，请参见其文档。
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// 根据给定的谓词返回分区点的索引 (第二个分区的第一个元素的索引)。
    ///
    /// 假定切片根据给定的谓词进行了分区。
    /// 这意味着谓词返回 true 的所有元素都在切片的开头，谓词返回 false 的所有元素都在切片的结尾。
    ///
    /// 例如，[7, 15, 3, 5, 4, 12, 6] 在谓词 `x % 2 != 0` 下进行了分区 (所有的奇数都在开头，所有的偶数都在结尾)。
    ///
    /// 如果未对该切片进行分区，则返回的结果是不确定的且无意义的，因为此方法执行一种二进制搜索。
    ///
    /// 另请参见 [`binary_search`]，[`binary_search_by`] 和 [`binary_search_by_key`]。
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        self.binary_search_by(|x| if pred(x) { Less } else { Greater }).unwrap_or_else(|i| i)
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    #[track_caller]
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: 我们需要显式地将它们切片为相同的长度，以使优化程序更容易忽略边界检查。
        //
        // 但是由于不能依靠它，我们还对 T: Copy 有一个明确的专长。
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    #[track_caller]
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl<T> const Default for &[T] {
    /// 创建一个空的切片。
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl<T> const Default for &mut [T] {
    /// 创建一个可变的空切片。
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// 切片中的模式 - 当前，仅由 `strip_prefix` 和 `strip_suffix` 使用。
/// 在 future 指针上，我们希望将 `core::str::Pattern` (在撰写本文时仅限于 `str`) 推广到切片，然后将替换或废除此 trait。
///
pub trait SlicePattern {
    /// 匹配的切片的元素类型。
    type Item;

    /// 当前，`SlicePattern` 的消费者需要切片。
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}
