---
名称：特性请求关于：请求添加到 core::simd API 标签: C-feature-request
---
<!--
  Hello!

  我们对您可能提出的任何特性请求非常感兴趣。

  但是，请注意 core::simd 的存在是为了解决为 Rust 创建可移植 SIMD API 的问题。
  
  对编译器特性扩展的请求，例如 `target_feature`、SIMD API 的二进制版本控制，或
  improving specific compilation issues in general should be discussed at https://internals.rust-lang.org/
-->
