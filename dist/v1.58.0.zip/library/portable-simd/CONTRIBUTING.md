# 为 `std::simd` 做贡献

简单版：
1. Fork 它和 `git clone` 它
2. 创建您的特性分支：`git checkout -b my-branch`
3. 写下您的改变。
4. 测试一下: `cargo test`。请记住通过设置 `RUSTFLAGS` 来启用您打算测试的任何 SIMD 特性。
5. 提交您的更改：`git commit add ./path/to/changes && git commit -m 'Fix some bug'`
6. 推送到分支：`git push --set-upstream origin my-branch`
7. 提交拉取请求！

## 解决问题

SIMD 可能非常复杂，甚至 "simple" 问题也可能很大。如果问题的组织方式类似于跟踪问题，并且有一个项的逐项列表，而不必按特定顺序完成，请一次处理一个项。这将有助于让工作在其余问题上快速进行。如果是 (relatively) 的小问题，请随时在问题跟踪器上宣布您的解决意向，并一次性解决！

## CI

我们目前通过 Travis CI 和 GitHub Actions 有 2 个 CI 矩阵，它们将自动构建和测试您的更改，以验证 `std::simd` 的可移植 API 实际上是可移植的。如果您的更改是在本地构建的，但没有在两者之上构建，这可能是由于您的代码没有解决特定于平台的问题。请查阅构建日志并解决错误，或者在需要时寻求帮助。

## 超越 stdsimd

在 [rustc 仓库 main 分支](https://github.com/rust-lang/rust) 中的 rustc_codegen_* crates 中可以找到大量的核心 SIMD 实现。此外，实际平台特定的函数是在 [stdarch] 中实现的。并非所有对 `std::simd` 的更改都需要与其中任何一个进行交互，但是如果您想知道某物在哪里并且它似乎不在这个仓库中，那么这些可能是开始寻找的地方。

## 问题？担忧？ 需要帮忙？

请随时在 [rust-lang Zulip][zulip] 上的 [#project-portable-simd][zulip-portable-simd] 流中询问有关对 `std::simd` 进行更改的帮助！
如果您的更改包括直接修改编译器，那么在 [#t-compiler/help][zulip-compiler-help] 中询问也可能有用。

[zulip-portable-simd]: https://rust-lang.zulipchat.com/#narrow/stream/257879-project-portable-simd
[zulip-compiler-help]: https://rust-lang.zulipchat.com/#narrow/stream/182449-t-compiler.2Fhelp
[zulip]: https://rust-lang.zulipchat.com
[stdarch]: https://github.com/rust-lang/stdarch
