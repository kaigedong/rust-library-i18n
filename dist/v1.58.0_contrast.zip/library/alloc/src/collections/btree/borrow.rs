use core::marker::PhantomData;
use core::ptr::NonNull;

/// Models a reborrow of some unique reference, when you know that the reborrow and all its descendants (i.e., all pointers and references derived from it) will not be used any more at some point, after which you want to use the original unique reference again. <br>当您知道重借项及其所有后代 (即从中衍生的所有指针和引用) 在某个时候将不再使用时，对某个重借项的重借进行建模。<br>
///
///
/// The borrow checker usually handles this stacking of borrows for you, but some control flows that accomplish this stacking are too complicated for the compiler to follow. <br>借用检查器通常为您处理借用的这种堆叠，但是完成该堆叠的某些控制流对于编译器而言太复杂了。<br>
/// A `DormantMutRef` allows you to check borrowing yourself, while still expressing its stacked nature, and encapsulating the raw pointer code needed to do this without undefined behavior. <br>`DormantMutRef` 允许您自己检查借用，同时仍然表示其堆叠性质，并且封装执行此操作所需的裸指针代码而没有未定义的行为。<br>
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Capture a unique borrow, and immediately reborrow it. <br>捕获一个独特的借用，然后立即重新借用。<br>
    /// For the compiler, the lifetime of the new reference is the same as the lifetime of the original reference, but you promise to use it for a shorter period. <br>对于编译器，新引用的生命周期与原始引用的生命周期相同，但您 promise 可以将其使用更短的时间。<br>
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: we hold the borrow throughout 'a via `_marker`, and we expose only this reference, so it is unique. <br>我们通过 `_marker` 在整个 'a 中持有借用，并且仅公开此引用，因此它是唯一的。<br>
        //
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Revert to the unique borrow initially captured. <br>恢复为最初捕获的唯一借用。<br>
    ///
    /// # Safety
    ///
    /// The reborrow must have ended, i.e., the reference returned by `new` and all pointers and references derived from it, must not be used anymore. <br>重新借用必须已经结束，即不再使用 `new` 返回的引用以及从该指针派生的所有指针和引用。<br>
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: our own safety conditions imply this reference is again unique. <br>我们自己的的安全条件意味着该引用仍然是独一无二的。<br>
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;
