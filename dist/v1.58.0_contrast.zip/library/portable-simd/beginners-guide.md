
# Beginner's Guide To SIMD <br>SIMD 初学者指南<br>

Hello and welcome to our SIMD basics guide! <br>您好，欢迎阅读我们的 SIMD 基础指南！<br>

Because SIMD is a subject that many programmers haven't worked with before, we thought that it's best to outline some terms and other basics for you to get started with. <br>因为 SIMD 是许多程序员以前从未接触过的主题，所以我们认为最好概述一些术语和其他基础知识以供您入门。<br>

## Quick Background <br>快速背景<br>

**SIMD** stands for *Single Instruction, Multiple Data*. <br>**SIMD** 代表 *单指令多数据*。<br> In other words, SIMD is when the CPU performs a single action on more than one logical piece of data at the same time. <br>换句话说，SIMD 是指 CPU 同时对多个逻辑数据执行单个操作。<br> Instead of adding two registers that each contain one `f32` value and getting an `f32` as the result, you might add two registers that each contain `f32x4` (128 bits of data) and then you get an `f32x4` as the output. <br>您可以添加两个寄存器，每个寄存器包含一个 `f32`，并获得一个 `f32` 作为结果，不如添加两个寄存器，每个寄存器包含 `f32x4` (128 位数据)，然后您将获得一个 `f32x4` 作为输出。<br>

This might seem a tiny bit weird at first, but there's a good reason for it. <br>起初这可能看起来有点奇怪，但有一个很好的理由。<br> Back in the day, as CPUs got faster and faster, eventually they got so fast that the CPU would just melt itself. <br>回到过去，随着 CPU 变得越来越快，最终它们变得如此之快，以至于 CPU 会自行融化。<br> The heat management (heat sinks, fans, etc) simply couldn't keep up with how much electricity was going through the metal. <br>热量管理 (散热器、风扇等) 根本无法跟上通过金属的电流量。<br> Two main strategies were developed to help get around the limits of physics. <br>开发了两种主要策略来帮助绕过物理极限。<br>
* One of them you're probably familiar with: Multi-core processors. By giving a processor more than one core, each core can do its own work, and because they're physically distant (at least on the CPU's scale) the heat can still be managed. <br>您可能熟悉其中之一：多核处理器。通过为处理器提供多个内核，每个内核都可以完成自己的工作，并且由于它们在物理上相距遥远 (至少在 CPU 的规模上)，因此仍然可以管理热量。<br> Unfortunately, not all tasks can just be split up across cores in an efficient way. <br>不幸的是，并非所有任务都可以有效地跨内核拆分。<br>
* The second strategy is SIMD. <br>第二种策略是 SIMD。<br> If you can't make the register go any faster, you can still make the register *wider*. <br>如果您不能让寄存器运行得更快，您仍然可以让寄存器*更宽*。<br> This lets you process more data at a time, which is *almost* as good as just having a faster CPU. <br>这使您可以一次处理更多数据，这*几乎*与拥有更快的 CPU 一样好。<br> As with multi-core programming, SIMD doesn't fit every kind of task, so you have to know when it will improve your program. <br>与多核编程一样，SIMD 并不适合所有类型的任务，因此您必须知道它何时会改进您的程序。<br>

## Terms

SIMD has a few special vocabulary terms you should know: <br>SIMD 有一些您应该知道的特殊词汇术语：<br>

* **Vector:** A SIMD value is called a vector. <br>**Vector: ** 一个 SIMD 值被称为 vector。<br> This shouldn't be confused with the `Vec<T>` type. <br>这不应与 `Vec<T>` 类型混淆。<br> A SIMD vector has a fixed size, known at compile time. <br>SIMD vector 具有固定大小，在编译时已知。<br> All of the elements within the vector are of the same type. <br>vector 中的所有元素都属于同一类型。<br> This makes vectors *similar to* arrays. <br>这使得 vectors 类似于数组。<br> One difference is that a vector is generally aligned to its *entire* size (eg: 16 bytes, 32 bytes, etc), not just the size of an individual element. <br>一个区别是 vector 通常与其整个大小对齐 (例如: 16 字节、32 字节等)，而不仅仅是单个元素的大小。<br> Sometimes vector data is called "packed" data. <br>有时 vector 数据称为包装的数据。<br>

* **Vectorize**: An operation that uses SIMD instructions to operate over a vector is often referred to as "vectorized". <br>**Vectorize**: 使用 SIMD 指令对 vector 进行操作的操作通常称为 "vectorized"。<br>

* **Autovectorization**: Also known as _implicit vectorization_. <br>**自动向量化**: 也称为隐式向量化。<br> This is when a compiler can automatically recognize a situation where scalar instructions may be replaced with SIMD instructions, and use those instead. <br>这是编译器可以自动识别标量指令可能被 SIMD 指令替换的情况，并使用这些指令代替。<br>

* **Scalar:** "Scalar" in mathematical contexts refers to values that can be represented as a single element, mostly numbers like 6, 3.14, or -2. <br>**标量: **在数学上下文中，"Scalar" 是指可以表示为单个元素的值，主要是 6、3.14 或 -2 等数字。<br> It can also be used to describe "scalar operations" that use strictly scalar values, like addition. <br>它还可用于描述严格使用标量值的 "scalar operations"，例如加法。<br> This term is mostly used to differentiate between vectorized operations that use SIMD instructions and scalar operations that don't. <br>该术语主要用于区分使用 SIMD 指令的矢量化运算和不使用 SIMD 指令的标量运算。<br>

* **Lane:** A single element position within a vector is called a lane. <br>**Lane:** vector 内的单个元素位置称为 lane。<br> If you have `N` lanes available then they're numbered from `0` to `N-1` when referring to them, again like an array. <br>如果您有可用的 `N` lanes，那么在引用它们时它们的编号从 `0` 到 `N-1`，再次像数组一样。<br> The biggest difference between an array element and a vector lane is that in general is *relatively costly* to access an individual lane value. <br>数组元素和 vector lane 之间的最大区别在于，访问单个 lane 值通常*相对昂贵*。<br> On most architectures, the vector has to be pushed out of the SIMD register onto the stack, then an individual lane is accessed while it's on the stack (and possibly the stack value is read back into a register). <br>在大多数体系结构中，vector 必须从 SIMD 寄存器中推出到栈中，然后在它位于栈上时访问单个 lane (并且可能将栈值读回到寄存器中)。<br> For this reason, when working with SIMD you should avoid reading or writing the value of an individual lane during hot loops. <br>因此，在使用 SIMD 时，应避免在热循环期间读取或写入单个 lane 的值。<br>

* **Bit Widths:** When talking about SIMD, the bit widths used are the bit size of the vectors involved, *not* the individual elements. <br>**位宽: **在谈到 SIMD 时，所使用的位宽是所涉及的 vectors 的位大小，*不是*单个元素。<br> So "128-bit SIMD" has 128-bit vectors, and that might be `f32x4`, `i32x4`, `i16x8`, or other variations. <br>所以 "128-bit SIMD" 有 128 位 vectors，这可能是 `f32x4`、`i32x4`、`i16x8` 或其他变体。<br> While 128-bit SIMD is the most common, there's also 64-bit, 256-bit, and even 512-bit on the newest CPUs. <br>虽然 128 位 SIMD 是最常见的，但在最新的 CPU 上也有 64 位、256 位甚至 512 位。<br>

* **Vector Register:** The extra-wide registers that are used for SIMD operations are commonly called vector registers, though you may also see "SIMD registers", vendor names for specific features, or even "floating-point register" as it is common for the same registers to be used with both scalar and vectorized floating-point operations. <br>**Vector 寄存器: ** 用于 SIMD 操作的超宽寄存器通常称为 vector 寄存器，但您也可能会看到 "SIMD registers"、特定特性的供应商名称，甚至是浮点寄存器，因为相同的寄存器很常见与标量和向量化浮点运算一起使用。<br>

* **Vertical:** When an operation is "vertical", each lane processes individually without regard to the other lanes in the same vector. <br>**垂直: **当操作为 "vertical" 时，每个 lane 单独处理，而不考虑同一 vector 中的其他 lanes。<br> For example, a "vertical add" between two vectors would add lane 0 in `a` with lane 0 in `b`, with the total in lane 0 of `out`, and then the same thing for lanes 1, 2, etc. Most SIMD operations are vertical operations, so if your problem is a vertical problem then you can probably solve it with SIMD. <br>例如，两个 vectors 之间的 "vertical add" 会将 `a` 中的 lane 0 与 `b` 中的 lane 0 相加，总计在 `out` 的 lane 0 中，然后对 lane 1、2 等进行相同的操作。大多数 SIMD 操作都是垂直操作，因此如果您的问题是垂直问题，那么您可能可以使用 SIMD 解决它。<br>

* **Horizontal:** When an operation is "horizontal", the lanes within a single vector interact in some way. <br>**水平: **当操作为 "horizontal" 时，单个 vector 内的 lanes 以某种方式交互。<br> A "horizontal add" might add up lane 0 of `a` with lane 1 of `a`, with the total in lane 0 of `out`. <br>"horizontal add" 可能会将 `a` 的第 0 道与 `a` 的第 1 道相加，总计在 `out` 的第 0 道。<br>

* **Target Feature:** Rust calls a CPU architecture extension a `target_feature`. <br>**目标特性: ** Rust 将 CPU 架构扩展称为 `target_feature`。<br> Proper SIMD requires various CPU extensions to be enabled (details below). <br>正确的 SIMD 需要启用各种 CPU 扩展 (详情如下)。<br> Don't confuse this with `feature`, which is a Cargo crate concept. <br>不要将此与 `feature` 混淆，后者是 Cargo crate 概念。<br>

## Target Features <br>目标特性<br>

When using SIMD, you should be familiar with the CPU feature set that you're targeting. <br>使用 SIMD 时，您应该熟悉所针对的 CPU 特性集。<br>

On `arm` and `aarch64` it's fairly simple. <br>在 `arm` 和 `aarch64` 上，它相当简单。<br> There's just one CPU feature that controls if SIMD is available: `neon` (or "NEON", all caps, as the ARM docs often put it). <br>只有一个 CPU 特性可以控制 SIMD 是否可用: `neon` (或 "NEON"，全部大写，正如 ARM 文档经常所说的那样)。<br> Neon registers can be used as 64-bit or 128-bit. <br>Neon 寄存器可用作 64 位或 128 位。<br> When doing 128-bit operations it just uses two 64-bit registers as a single 128-bit register. <br>在进行 128 位操作时，它只使用两个 64 位寄存器作为一个 128 位寄存器。<br>

> By default, the `aarch64`, `arm`, and `thumb` Rust targets generally do not enable `neon` unless it's in the target string. <br>默认情况下，`aarch64`、`arm` 和 `thumb` Rust 目标通常不会启用 `neon`，除非它在目标字符串中。<br>

On `x86` and `x86_64` it's slightly more complicated. <br>在 `x86` 和 `x86_64` 上，它稍微复杂一些。<br> The SIMD support is split into many levels: <br>SIMD 支持分为多个级别：<br>
* 128-bit: `sse`, `sse2`, `sse3`, `ssse3` (not a typo!), `sse4.1`, `sse4.2`, `sse4a` (AMD only) <br>128 位: `sse`、`sse2`、`sse3`、`ssse3` (不是打字错误！)、`sse4.1`、`sse4.2`、`sse4a` (仅限 AMD)<br>
* 256-bit (mostly): `avx`, `avx2`, `fma` <br>256 位 (mostly)：`avx`、`avx2`、`fma`<br>
* 512-bit (mostly): a *wide* range of `avx512` variations <br>512 位 (mostly): *广泛*范围的 `avx512` 变化<br>

The list notes the bit widths available at each feature level, though the operations of the more advanced features can generally be used with the smaller register sizes as well. <br>该列表指出了每个特性级别可用的位宽，尽管更高级的特性的操作通常也可以用于较小的寄存器大小。<br> For example, new operations introduced in `avx` generally have a 128-bit form as well as a 256-bit form. <br>例如，`avx` 中引入的新操作通常有 128 位形式和 256 位形式。<br> This means that even if you only do 128-bit work you can still benefit from the later feature levels. <br>这意味着即使您只进行 128 位工作，您仍然可以从更高的特性级别中受益。<br>

> By default, the `i686` and `x86_64` Rust targets enable `sse` and `sse2`. <br>默认情况下，`i686` 和 `x86_64` Rust 目标启用 `sse` 和 `sse2`。<br>

### Selecting Additional Target Features <br>选择额外的目标特性<br>

If you want to enable support for a target feature within your build, generally you should use a [target-feature](https://rust-lang.github.io/packed_simd/perf-guide/target-feature/rustflags.html#target-feature) setting within you `RUSTFLAGS` setting. <br>如果要在构建中启用对目标特性的支持，通常应在 `RUSTFLAGS` 设置中使用 [目标特性](https://rust-lang.github.io/packed_simd/perf-guide/target-feature/rustflags.html#target-feature) 设置。<br>

If you know that you're targeting a specific CPU you can instead use the [target-cpu](https://rust-lang.github.io/packed_simd/perf-guide/target-feature/rustflags.html#target-cpu) flag and the compiler will enable the correct set of features for that CPU. <br>如果您知道您的目标是特定 CPU，则可以改用 [目标 CPU](https://rust-lang.github.io/packed_simd/perf-guide/target-feature/rustflags.html#target-cpu) 标志，编译器将为该 CPU 启用正确的特性集。<br>

The [Steam Hardware Survey](https://store.steampowered.com/hwsurvey/Steam-Hardware-Software-Survey-Welcome-to-Steam) is one of the few places with data on how common various CPU features are. <br>[Steam 硬件调查](https://store.steampowered.com/hwsurvey/Steam-Hardware-Software-Survey-Welcome-to-Steam) 是为数不多的提供各种 CPU 特性普遍性数据的地方之一。<br> The dataset is limited to "the kinds of computers owned by people who play computer games", so the info only covers `x86`/`x86_64`, and it also probably skews to slightly higher quality computers than average. <br>数据集仅限于 "the kinds of computers owned by people who play computer games"，因此信息仅涵盖 `x86`/`x86_64`，并且它也可能偏向于比平均质量稍高的计算机。<br> Still, we can see that the `sse` levels have very high support, `avx` and `avx2` are quite common as well, and the `avx-512` family is still so early in adoption you can barely find it in consumer grade stuff. <br>尽管如此，我们仍然可以看到 `sse` 级别的支持非常高，`avx` 和 `avx2` 也很常见，而且 `avx-512` 系列仍然处于早期采用阶段，您在消费级产品中几乎找不到它。<br>

## Running a program compiled for a CPU feature level that the CPU doesn't support is automatic undefined behavior. <br>运行为 CPU 不支持的 CPU 特性级别编译的程序是自动未定义行为。<br>

This means that if you build your program with `avx` support enabled and run it on a CPU without `avx` support, it's **instantly** undefined behavior. <br>这意味着，如果您在启用 `avx` 支持的情况下构建您的程序并在没有 `avx` 支持的 CPU 上运行它，它是**立即**未定义的行为。<br>

Even without an `unsafe` block in sight. <br>即使看不到 `unsafe` 块。<br>

This is no bug in Rust, or soundness hole in the type system. <br>这不是 Rust 中的错误，也不是类型系统中的健全性 hole。<br> You just plain can't make a CPU do what it doesn't know how to do. <br>您只是不能让 CPU 做它不知道如何做的事情。<br>

This is why the various Rust targets *don't* enable many CPU feature flags by default: requiring a more advanced CPU makes the final binary *less* portable. <br>这就是为什么各种 Rust 目标默认*不*启用许多 CPU 特性标志的原因：需要更高级的 CPU 使最终的二进制文件*不*可移植。<br>

So please select an appropriate CPU feature level when building your programs. <br>因此，请在构建程序时选择合适的 CPU 特性级别。<br>

## Size, Alignment, and Unsafe Code <br>大小、对齐和不安全代码<br>

Most of the portable SIMD API is designed to allow the user to gloss over the details of different architectures and avoid using unsafe code. <br>大多数可移植的 SIMD API 旨在允许用户掩盖不同架构的细节并避免使用不安全的代码。<br> However, there are plenty of reasons to want to use unsafe code with these SIMD types, such as using an intrinsic function from `core::arch` to further accelerate particularly specialized SIMD operations on a given platform, while still using the portable API elsewhere. <br>然而，有很多理由想要对这些 SIMD 类型使用不安全的代码，例如使用 `core::arch` 的内部函数函数来进一步加速给定平台上特别专业的 SIMD 操作，同时在其他地方仍然使用可移植的 API。<br> For these cases, there are some rules to keep in mind. <br>对于这些情况，需要记住一些规则。<br>

Fortunately, most SIMD types have a fairly predictable size. <br>幸运的是，大多数 SIMD 类型具有相当可预测的大小。<br> `i32x4` is bit-equivalent to `[i32; 4]` and so can be bitcast to it, e.g. using [`mem::transmute`], though the API usually offers a safe cast you can use instead. <br>`i32x4` 与 `[i32; 4]` 位等效，因此可以对其进行位转换，例如使用 [`mem::transmute`]，尽管 API 通常提供您可以使用的安全转换。<br>

However, this is not the same as alignment. <br>但是，这与对齐不同。<br> Computer architectures generally prefer aligned accesses, especially when moving data between memory and vector registers, and while some support specialized operations that can bend the rules to help with this, unaligned access is still typically slow, or even undefined behavior. <br>计算机体系结构通常更喜欢对齐访问，尤其是在内存和 vector 寄存器之间移动数据时，虽然有些支持可以改变规则以帮助解决此问题的专门操作，但未对齐访问通常仍然很慢，甚至是未定义的行为。<br> In addition, different architectures can require different alignments when interacting with their native SIMD types. <br>此外，不同的架构在与其原生 SIMD 类型交互时可能需要不同的对齐方式。<br> For this reason, any `#[repr(simd)]` type has a non-portable alignment. <br>出于这个原因，任何 `#[repr(simd)]` 类型都具有非便携式对齐方式。<br> If it is necessary to directly interact with the alignment of these types, it should be via [`mem::align_of`]. <br>如果需要直接与这些类型的对齐进行交互，应该通过 [`mem::align_of`]。<br>

[`mem::transmute`]: https://doc.rust-lang.org/core/mem/fn.transmute.html
[`mem::align_of`]: https://doc.rust-lang.org/core/mem/fn.align_of.html
