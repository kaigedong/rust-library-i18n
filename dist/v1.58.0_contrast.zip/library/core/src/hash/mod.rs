//! Generic hashing support. <br>通用哈希支持。<br>
//!
//! This module provides a generic way to compute the [hash] of a value. <br>该模块提供了一种计算值的 [哈希][hash] 的通用方法。<br>
//! Hashes are most commonly used with [`HashMap`] and [`HashSet`]. <br>哈希最常与 [`HashMap`] 和 [`HashSet`] 一起使用。<br>
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! The simplest way to make a type hashable is to use `#[derive(Hash)]`: <br>使类型可哈希化的最简单方法是使用 `#[derive(Hash)]`：<br>
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! If you need more control over how a value is hashed, you need to implement the [`Hash`] trait: <br>如果您需要更多地控制值的散列方式，则需要实现 [`Hash`] trait：<br>
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// A hashable type. <br>可散列的类型。<br>
///
/// Types implementing `Hash` are able to be [`hash`]ed with an instance of [`Hasher`]. <br>实现 `Hash` 的类型可以通过 [`Hasher`] 的实例进行 [`hash`] 化。<br>
///
/// ## Implementing `Hash` <br>实现 `Hash`<br>
///
/// You can derive `Hash` with `#[derive(Hash)]` if all fields implement `Hash`. <br>如果所有字段都要实现 `Hash`，则可以用 `#[derive(Hash)]` 派生 `Hash`。<br>
/// The resulting hash will be the combination of the values from calling [`hash`] on each field. <br>产生的哈希将是在每个字段上调用 [`hash`] 的值的组合。<br>
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// If you need more control over how a value is hashed, you can of course implement the `Hash` trait yourself: <br>如果您需要更多地控制值的散列方式，则当然可以自己实现 `Hash` trait：<br>
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` and `Eq` <br>`Hash` 和 `Eq`<br>
///
/// When implementing both `Hash` and [`Eq`], it is important that the following property holds: <br>同时实现 `Hash` 和 [`Eq`] 时，保持以下属性很重要：<br>
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// In other words, if two keys are equal, their hashes must also be equal. <br>换句话说，如果两个键相等，则它们的哈希也必须相等。<br>
/// [`HashMap`] and [`HashSet`] both rely on this behavior. <br>[`HashMap`] 和 [`HashSet`] 都依赖于这种行为。<br>
///
/// Thankfully, you won't need to worry about upholding this property when deriving both [`Eq`] and `Hash` with `#[derive(PartialEq, Eq, Hash)]`. <br>值得庆幸的是，在使用 `#[derive(PartialEq, Eq, Hash)]` 派生 [`Eq`] 和 `Hash` 时，您不必担心维护此属性。<br>
///
/// ## Prefix collisions <br>前缀冲突<br>
///
/// Implementations of `hash` should ensure that the data they pass to the `Hasher` are prefix-free. <br>`hash` 的实现应该确保它们传递给 `Hasher` 的数据是无前缀的。<br>
/// That is, unequal values should cause two different sequences of values to be written, and neither of the two sequences should be a prefix of the other. <br>也就是说，不相等的值应该导致写入两个不同的值序列，并且两个序列中的任何一个都不应该是另一个的前缀。<br>
///
/// For example, the standard implementation of [`Hash` for `&str`][impl] passes an extra `0xFF` byte to the `Hasher` so that the values `("ab", "c")` and `("a", "bc")` hash differently. <br>例如，[`Hash` for `&str`][impl] 的标准实现将额外的 `0xFF` 字节传递给 `Hasher`，以便值 `("ab", "c")` 和 `("a", "bc")` 哈希不同。<br>
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
/// [impl]: ../../std/primitive.str.html#impl-Hash
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Hash"]
pub trait Hash {
    /// Feeds this value into the given [`Hasher`]. <br>将该值输入给定的 [`Hasher`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// Feeds a slice of this type into the given [`Hasher`]. <br>将这种类型的切片送入给定的 [`Hasher`] 中。<br>
    ///
    /// This method is meant as a convenience, but its implementation is also explicitly left unspecified. <br>此方法是为了方便起见，但它的实现也明确未指定。<br>
    /// It isn't guaranteed to be equivalent to repeated calls of [`hash`] and implementations of [`Hash`] should keep that in mind and call [`hash`] themselves if the slice isn't treated as a whole unit in the [`PartialEq`] implementation. <br>它不能保证等同于 [`hash`] 的重复调用，并且 [`Hash`] 的实现应该记住这一点，如果在 [`PartialEq`] 实现中没有将 6 视为整个单元，则调用 [`hash`] 本身。<br>
    ///
    /// For example, a [`VecDeque`] implementation might naïvely call [`as_slices`] and then [`hash_slice`] on each slice, but this is wrong since the two slices can change with a call to [`make_contiguous`] without affecting the [`PartialEq`] result. <br>例如，一个 [`VecDeque`] 实现可能天真地调用 [`as_slices`] 然后 [`hash_slice`] 对每个调用 [`hash_slice`]，但这是错误的，因为两个切片可以随调用更改为 [`make_contiguous`] 而不会影响 [`PartialEq`] 结果。<br>
    ///
    /// Since these slices aren't treated as singular units, and instead part of a larger deque, this method cannot be used. <br>由于这些切片不被视为单一单元，而是更大双端队列的一部分，因此无法使用此方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`VecDeque`]: ../../std/collections/struct.VecDeque.html
    /// [`as_slices`]: ../../std/collections/struct.VecDeque.html#method.as_slices
    /// [`make_contiguous`]: ../../std/collections/struct.VecDeque.html#method.make_contiguous
    /// [`hash`]: Hash::hash
    /// [`hash_slice`]: Hash::hash_slice
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// Separate module to reexport the macro `Hash` from prelude without the trait `Hash`. <br>单独的模块，用于从 prelude 重导出 `Hash` 宏，而无需 `Hash` trait。<br>
pub(crate) mod macros {
    /// Derive macro generating an impl of the trait `Hash`. <br>派生宏，生成 `Hash` trait 的实现。<br>
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// A trait for hashing an arbitrary stream of bytes. <br>对任意字节流进行散列的 trait。<br>
///
/// Instances of `Hasher` usually represent state that is changed while hashing data. <br>`Hasher` 的实例通常表示在对数据进行哈希处理时更改的状态。<br>
///
/// `Hasher` provides a fairly basic interface for retrieving the generated hash (with [`finish`]), and writing integers as well as slices of bytes into an instance (with [`write`] and [`write_u8`] etc.). <br>`Hasher` 提供了一个相当基本的接口，用于检索生成的散列 (使用 [`finish`])，并将整数和字节片写入实例 (使用 [`write`] 和 [`write_u8`] 等)。<br>
///
/// Most of the time, `Hasher` instances are used in conjunction with the [`Hash`] trait. <br>大多数情况下，`Hasher` 实例与 [`Hash`] trait 结合使用。<br>
///
/// This trait makes no assumptions about how the various `write_*` methods are defined and implementations of [`Hash`] should not assume that they work one way or another. <br>这个 trait 不假设各种 `write_*` 方法是如何定义的，并且 [`Hash`] 的实现不应该假设它们以一种或另一种方式工作。<br>
/// You cannot assume, for example, that a [`write_u32`] call is equivalent to four calls of [`write_u8`]. <br>例如，您不能假设一个 [`write_u32`] 调用等同于 [`write_u8`] 的四个调用。<br>
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
/// [`write_u32`]: Hasher::write_u32
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// Returns the hash value for the values written so far. <br>返回到目前为止写入的值的哈希值。<br>
    ///
    /// Despite its name, the method does not reset the hasher’s internal state. <br>尽管名称如此，该方法不会重置哈希器的内部状态。<br>
    /// Additional [`write`]s will continue from the current value. <br>额外的 [`write`] 将从当前值继续。<br>
    /// If you need to start a fresh hash value, you will have to create a new hasher. <br>如果需要开始一个新的哈希值，则必须创建一个新的哈希器。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// Writes some data into this `Hasher`. <br>将一些数据写入此 `Hasher`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// Writes a single `u8` into this hasher. <br>将单个 `u8` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// Writes a single `u16` into this hasher. <br>将单个 `u16` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// Writes a single `u32` into this hasher. <br>将单个 `u32` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// Writes a single `u64` into this hasher. <br>将单个 `u64` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// Writes a single `u128` into this hasher. <br>将单个 `u128` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// Writes a single `usize` into this hasher. <br>将单个 `usize` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// Writes a single `i8` into this hasher. <br>将单个 `i8` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// Writes a single `i16` into this hasher. <br>将单个 `i16` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// Writes a single `i32` into this hasher. <br>将单个 `i32` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// Writes a single `i64` into this hasher. <br>将单个 `i64` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// Writes a single `i128` into this hasher. <br>将单个 `i128` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// Writes a single `isize` into this hasher. <br>将单个 `isize` 写入此哈希器。<br>
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// A trait for creating instances of [`Hasher`]. <br>用于创建 [`Hasher`] 实例的 trait。<br>
///
/// A `BuildHasher` is typically used (e.g., by [`HashMap`]) to create [`Hasher`]s for each key such that they are hashed independently of one another, since [`Hasher`]s contain state. <br>`BuildHasher` 通常用于 (例如，由 [`HashMap`] 来) 为每个键创建 [`Hasher`]，使得它们彼此独立地进行哈希处理，因为 [`Hasher`] 包含状态。<br>
///
///
/// For each instance of `BuildHasher`, the [`Hasher`]s created by [`build_hasher`] should be identical. <br>对于 `BuildHasher` 的每个实例，由 [`build_hasher`] 创建的 [`Hasher`] 应该相同。<br>
/// That is, if the same stream of bytes is fed into each hasher, the same output will also be generated. <br>也就是说，如果将相同的字节流馈送到每个哈希器中，则还将生成相同的输出。<br>
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// Type of the hasher that will be created. <br>将创建的哈希器的类型。<br>
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// Creates a new hasher. <br>创建一个新的哈希器。<br>
    ///
    /// Each call to `build_hasher` on the same instance should produce identical [`Hasher`]s. <br>在同一实例上对 `build_hasher` 的每次调用都应产生相同的 [`Hasher`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;

    /// Calculates the hash of a single value. <br>计算单个值的哈希值。<br>
    ///
    /// This is intended as a convenience for code which *consumes* hashes, such as the implementation of a hash table or in unit tests that check whether a custom [`Hash`] implementation behaves as expected. <br>这是为了方便*消耗*哈希的代码，例如哈希表的实现或在单元测试中检查自定义 [`Hash`] 实现是否按预期运行。<br>
    ///
    ///
    /// This must not be used in any code which *creates* hashes, such as in an implementation of [`Hash`]. <br>这不能用在任何*创建*哈希的代码中，例如在 [`Hash`] 的实现中。<br>
    /// The way to create a combined hash of multiple values is to call [`Hash::hash`] multiple times using the same [`Hasher`], not to call this method repeatedly and combine the results. <br>创建多个值的组合哈希的方法是使用同一个 [`Hasher`] 多次调用 [`Hash::hash`]，而不是重复调用此方法并组合结果。<br>
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(build_hasher_simple_hash_one)]
    ///
    /// use std::cmp::{max, min};
    /// use std::hash::{BuildHasher, Hash, Hasher};
    /// struct OrderAmbivalentPair<T: Ord>(T, T);
    /// impl<T: Ord + Hash> Hash for OrderAmbivalentPair<T> {
    ///     fn hash<H: Hasher>(&self, hasher: &mut H) {
    ///         min(&self.0, &self.1).hash(hasher);
    ///         max(&self.0, &self.1).hash(hasher);
    ///     }
    /// }
    ///
    /// // Then later, in a `#[test]` for the type... <br>然后，在 `#[test]` 类型中...<br>
    /// let bh = std::collections::hash_map::RandomState::new();
    /// assert_eq!(
    ///     bh.hash_one(OrderAmbivalentPair(1, 2)),
    ///     bh.hash_one(OrderAmbivalentPair(2, 1))
    /// );
    /// assert_eq!(
    ///     bh.hash_one(OrderAmbivalentPair(10, 2)),
    ///     bh.hash_one(&OrderAmbivalentPair(2, 10))
    /// );
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "build_hasher_simple_hash_one", issue = "86161")]
    fn hash_one<T: Hash>(&self, x: T) -> u64
    where
        Self: Sized,
    {
        let mut hasher = self.build_hasher();
        x.hash(&mut hasher);
        hasher.finish()
    }
}

/// Used to create a default [`BuildHasher`] instance for types that implement [`Hasher`] and [`Default`]. <br>用于为实现 [`Hasher`] 和 [`Default`] 的类型创建默认的 [`BuildHasher`] 实例。<br>
///
/// `BuildHasherDefault<H>` can be used when a type `H` implements [`Hasher`] and [`Default`], and you need a corresponding [`BuildHasher`] instance, but none is defined. <br>`BuildHasherDefault<H>` 可以在类型 `H` 实现 [`Hasher`] 和 [`Default`] 时使用，并且您需要相应的 [`BuildHasher`] 实例，但没有定义。<br>
///
///
/// Any `BuildHasherDefault` is [zero-sized]. <br>任何 `BuildHasherDefault` 都是 [零大小][zero-sized]。<br> It can be created with [`default`][method.default]. <br>可以用 [`default`][method.default] 创建。<br>
/// When using `BuildHasherDefault` with [`HashMap`] or [`HashSet`], this doesn't need to be done, since they implement appropriate [`Default`] instances themselves. <br>当将 `BuildHasherDefault` 与 [`HashMap`] 或 [`HashSet`] 一起使用时，不需要这样做，因为它们自己实现了适当的 [`Default`] 实例。<br>
///
/// # Examples
///
/// Using `BuildHasherDefault` to specify a custom [`BuildHasher`] for <br>使用 `BuildHasherDefault` 指定用于的自定义 [`BuildHasher`]<br>
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // Your hashing algorithm goes here! <br>您的哈希算法就在这里！<br>
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // Your hashing algorithm goes here! <br>您的哈希算法就在这里！<br>
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BuildHasherDefault").finish()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl<H> const Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // SAFETY: `ptr` is valid and aligned, as this macro is only used for numeric primitives which have no padding. <br>`ptr` 有效且已对齐，因为此宏仅用于没有填充的数字原语。<br>
                    // The new slice only spans across `data` and is never mutated, and its total size is the same as the original `data` so it can't be over `isize::MAX`. <br>新切片仅跨越 `data`，并且不会发生可变的，并且其总大小与原始 `data` 相同，因此不能超过 `isize::MAX`。<br>
                    //
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            let (address, metadata) = self.to_raw_parts();
            state.write_usize(address as usize);
            metadata.hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            let (address, metadata) = self.to_raw_parts();
            state.write_usize(address as usize);
            metadata.hash(state);
        }
    }
}
