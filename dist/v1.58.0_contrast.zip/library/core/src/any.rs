//! This module implements the `Any` trait, which enables dynamic typing of any `'static` type through runtime reflection. <br>该模块实现了 `Any` trait，它可以通过运行时反射来动态键入任何 `'static` 类型。<br>
//!
//! `Any` itself can be used to get a `TypeId`, and has more features when used as a trait object. <br>`Any` 本身可以用来得到一个 `TypeId`，当用作 trait 对象时，它有更多的特性。<br>
//! As `&dyn Any` (a borrowed trait object), it has the `is` and `downcast_ref` methods, to test if the contained value is of a given type, and to get a reference to the inner value as a type. <br>作为 `&dyn Any` (借用的 trait 对象)，它具有 `is` 和 `downcast_ref` 方法，以测试所包含的值是否为给定类型，并对该类型的内部值进行引用。<br>
//! As `&mut dyn Any`, there is also the `downcast_mut` method, for getting a mutable reference to the inner value. <br>作为 `&mut dyn Any`，还有 `downcast_mut` 方法，用于获取内部值的变量引用。<br>
//! `Box<dyn Any>` adds the `downcast` method, which attempts to convert to a `Box<T>`. <br>`Box<dyn Any>` 添加了 `downcast` 方法，该方法尝试转换为 `Box<T>`。<br>
//! See the [`Box`] documentation for the full details. <br>有关完整的详细信息，请参见 [`Box`] 文档。<br>
//!
//! Note that `&dyn Any` is limited to testing whether a value is of a specified concrete type, and cannot be used to test whether a type implements a trait. <br>请注意，`&dyn Any` 仅限于测试值是否为指定的具体类型，而不能用于测试某个类型是否实现 trait。<br>
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers and `dyn Any` <br>智能指针和 `dyn Any`<br>
//!
//! One piece of behavior to keep in mind when using `Any` as a trait object, especially with types like `Box<dyn Any>` or `Arc<dyn Any>`, is that simply calling `.type_id()` on the value will produce the `TypeId` of the *container*, not the underlying trait object. <br>将 `Any` 用作 trait 对象时要记住的一种行为，尤其是对于 `Box<dyn Any>` 或 `Arc<dyn Any>` 之类的类型，只需在值上调用 `.type_id()` 即可生成容器的 `TypeId`，而不是底层 trait 对象。<br>
//!
//! This can be avoided by converting the smart pointer into a `&dyn Any` instead, which will return the object's `TypeId`. <br>可以通过将智能指针转换为 `&dyn Any` 来避免，这将返回对象的 `TypeId`。<br>
//! For example: <br>例如：<br>
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // You're more likely to want this: <br>您更可能希望这样做：<br>
//! let actual_id = (&*boxed).type_id();
//! // ... than this: <br>比这个：<br>
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Consider a situation where we want to log out a value passed to a function. <br>考虑一下我们要注销传递给函数的值的情况。<br>
//! We know the value we're working on implements Debug, but we don't know its concrete type. <br>我们知道我们正在实现的值实现了 Debug，但是我们不知道它的具体类型。<br> We want to give special treatment to certain types: in this case printing out the length of String values prior to their value. <br>我们要对某些类型进行特殊处理：在这种情况下，应先打印 String 值的长度，然后再打印它们的值。<br>
//! We don't know the concrete type of our value at compile time, so we need to use runtime reflection instead. <br>我们在编译时不知道我们值的具体类型，因此我们需要使用运行时反射。<br>
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger function for any type that implements Debug. <br>用于实现 Debug 的任何类型的 Logger 函数。<br>
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Try to convert our value to a `String`. <br>尝试将我们的值转换为 `String`。<br>
//!     // If successful, we want to output the String`'s length as well as its value. <br>如果成功，我们要输出 String 的长度及其值。<br>
//!     // If not, it's a different type: just print it out unadorned. <br>如果不是，那就是另一种类型：只需将其打印出来即可。<br>
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // This function wants to log its parameter out prior to doing work with it. <br>该函数要先注销其参数，然后再使用它。<br>
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ...do some other work <br>... 做一些其他的工作<br>
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Any trait <br>任何 trait<br>
///////////////////////////////////////////////////////////////////////////////

/// A trait to emulate dynamic typing. <br>一个用来模拟动态类型的 trait。<br>
///
/// Most types implement `Any`. <br>大多数类型都实现了 `Any`。<br> However, any type which contains a non-`'static` reference does not. <br>但是，任何包含非 `static' 引用的类型都不会。<br>
/// See the [module-level documentation][mod] for more details. <br>有关更多详细信息，请参见 [模块级文档][mod]。<br>
///
/// [mod]: crate::any
// This trait is not unsafe, though we rely on the specifics of it's sole impl's `type_id` function in unsafe code (e.g., `downcast`). <br>这个 trait 并不是不安全的，尽管我们依靠不安全代码 (例如 `downcast`) 中唯一的 impl 的 `type_id` 函数的细节。<br> Normally, that would be a problem, but because the only impl of `Any` is a blanket implementation, no other code can implement `Any`. <br>通常，这将是一个问题，但是由于 `Any` 的唯一含义是全面实现，因此没有其他代码可以实现 `Any`。<br>
//
// We could plausibly make this trait unsafe -- it would not cause breakage, since we control all the implementations -- but we choose not to as that's both not really necessary and may confuse users about the distinction of unsafe traits and unsafe methods (i.e., `type_id` would still be safe to call, but we would likely want to indicate as such in documentation). <br>我们可以合理地使此 trait 不安全 - 因为我们控制所有实现，因此不会造成破坏 - 但我们选择不这样做，因为这既不是真正必要的，并且可能使用户混淆不安全的 traits 和不安全的方法 (即，`type_id` 仍然可以安全调用，但我们可能希望在文档中对此进行说明。<br>
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "Any")]
pub trait Any: 'static {
    /// Gets the `TypeId` of `self`. <br>获取 `self` 的 `TypeId`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Extension methods for Any trait objects. <br>任何 trait 对象的扩展方法。<br>
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

// Ensure that the result of e.g., joining a thread can be printed and hence used with `unwrap`. <br>确保可以打印出例如连接螺纹的结果，并因此可以与 `unwrap` 一起使用。<br>
// May eventually no longer be needed if dispatch works with upcasting. <br>如果调度与向上转换一起使用，则最终可能不再需要。<br>
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

impl dyn Any {
    /// Returns `true` if the boxed type is the same as `T`. <br>如果 boxed 类型与 `T` 相同，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Get `TypeId` of the type this function is instantiated with. <br>获取实例化此函数的类型的 `TypeId`。<br>
        let t = TypeId::of::<T>();

        // Get `TypeId` of the type in the trait object (`self`). <br>在 trait 对象 (`self`) 中获取该类型的 `TypeId`。<br>
        let concrete = self.type_id();

        // Compare both `TypeId`s on equality. <br>比较两个 `TypeId` 的相等性。<br>
        t == concrete
    }

    /// Returns some reference to the boxed value if it is of type `T`, or `None` if it isn't. <br>如果 boxed 的类型为 `T`，则返回一些引用，如果不是，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: just checked whether we are pointing to the correct type, and we can rely on that check for memory safety because we have implemented Any for all types; <br>只需检查我们是否指向正确的类型，就可以依靠该检查来检查内存安全性，因为我们对所有类型都实现了 Any；<br> no other impls can exist as they would conflict with our impl. <br>没有其他迹象可能会存在，因为它们会与我们的迹象发生冲突。<br>
            //
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Returns some mutable reference to the boxed value if it is of type `T`, or `None` if it isn't. <br>如果 boxed 的类型为 `T`，则返回一些可变引用; 如果不是，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: just checked whether we are pointing to the correct type, and we can rely on that check for memory safety because we have implemented Any for all types; <br>只需检查我们是否指向正确的类型，就可以依靠该检查来检查内存安全性，因为我们对所有类型都实现了 Any；<br> no other impls can exist as they would conflict with our impl. <br>没有其他迹象可能会存在，因为它们会与我们的迹象发生冲突。<br>
            //
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID and its methods <br>TypeID 及其方法<br>
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` represents a globally unique identifier for a type. <br>`TypeId` 代表类型的全局唯一标识符。<br>
///
/// Each `TypeId` is an opaque object which does not allow inspection of what's inside but does allow basic operations such as cloning, comparison, printing, and showing. <br>每个 `TypeId` 是不透明的对象，它不允许检查内部内容，但可以进行基本操作，例如克隆，比较，打印和显示。<br>
///
///
/// A `TypeId` is currently only available for types which ascribe to `'static`, but this limitation may be removed in the future. <br>`TypeId` 当前仅适用于归因于 `'static` 的类型，但是可以在 future 中消除此限制。<br>
///
/// While `TypeId` implements `Hash`, `PartialOrd`, and `Ord`, it is worth noting that the hashes and ordering will vary between Rust releases. <br>虽然 `TypeId` 实现 `Hash`，`PartialOrd` 和 `Ord`，但值得注意的是，在 Rust 版本之间，哈希值和顺序将有所不同。<br>
/// Beware of relying on them inside of your code! <br>注意不要在代码中依赖它们！<br>
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Returns the `TypeId` of the type this generic function has been instantiated with. <br>返回已实例化此泛型函数的类型的 `TypeId`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Returns the name of a type as a string slice. <br>以字符串切片的形式返回类型的名称。<br>
///
/// # Note
///
/// This is intended for diagnostic use. <br>这旨在用于诊断。<br>
/// The exact contents and format of the string returned are not specified, other than being a best-effort description of the type. <br>除了作为尽力而为的类型描述之外，未指定返回的字符串的确切内容和格式。<br>
/// For example, amongst the strings that `type_name::<Option<String>>()` might return are `"Option<String>"` and `"std::option::Option<std::string::String>"`. <br>例如，在 `type_name::<Option<String>>()` 可能返回的字符串中，有 `"Option<String>"` 和 `"std::option::Option<std::string::String>"`。<br>
///
///
/// The returned string must not be considered to be a unique identifier of a type as multiple types may map to the same type name. <br>返回的字符串不得视为类型的唯一标识符，因为多个类型可能会 map 变为相同的类型名称。<br>
/// Similarly, there is no guarantee that all parts of a type will appear in the returned string: for example, lifetime specifiers are currently not included. <br>同样，不能保证类型的所有部分都将出现在返回的字符串中：例如，当前不包括生命周期说明符。<br>
/// In addition, the output may change between versions of the compiler. <br>此外，输出可能会在编译器的版本之间改变。<br>
///
/// The current implementation uses the same infrastructure as compiler diagnostics and debuginfo, but this is not guaranteed. <br>当前的实现使用与编译器诊断和 debuginfo 相同的基础结构，但这不能保证。<br>
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[must_use]
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Returns the name of the type of the pointed-to value as a string slice. <br>以字符串切片的形式返回指向的值的类型的名称。<br>
/// This is the same as `type_name::<T>()`, but can be used where the type of a variable is not easily available. <br>这与 `type_name::<T>()` 相同，但是可以在不容易获得变量类型的地方使用。<br>
///
/// # Note
///
/// This is intended for diagnostic use. <br>这旨在用于诊断。<br> The exact contents and format of the string are not specified, other than being a best-effort description of the type. <br>没有指定字符串的确切内容和格式，只是对类型的尽力描述。<br>
/// For example, `type_name_of_val::<Option<String>>(None)` could return `"Option<String>"` or `"std::option::Option<std::string::String>"`, but not `"foobar"`. <br>例如，`type_name_of_val::<Option<String>>(None)` 可以返回 `"Option<String>"` 或 `"std::option::Option<std::string::String>"`，但不能返回 `"foobar"`。<br>
///
/// In addition, the output may change between versions of the compiler. <br>此外，输出可能会在编译器的版本之间改变。<br>
///
/// This function does not resolve trait objects, meaning that `type_name_of_val(&7u32 as &dyn Debug)` may return `"dyn Debug"`, but not `"u32"`. <br>此函数不能解析 trait 对象，这意味着 `type_name_of_val(&7u32 as &dyn Debug)` 可以返回 `"dyn Debug"`，但不能返回 `"u32"`。<br>
///
/// The type name should not be considered a unique identifier of a type; <br>类型名称不应视为类型的唯一标识符；<br>
/// multiple types may share the same type name. <br>多个类型可以共享相同的类型名称。<br>
///
/// The current implementation uses the same infrastructure as compiler diagnostics and debuginfo, but this is not guaranteed. <br>当前的实现使用与编译器诊断和 debuginfo 相同的基础结构，但这不能保证。<br>
///
/// # Examples
///
/// Prints the default integer and float types. <br>打印默认的整数和浮点类型。<br>
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[must_use]
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}
