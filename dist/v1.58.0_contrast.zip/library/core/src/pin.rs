//! Types that pin data to its location in memory. <br>键入将数据固定到其在内存中的位置的类型。<br>
//!
//! It is sometimes useful to have objects that are guaranteed not to move, in the sense that their placement in memory does not change, and can thus be relied upon. <br>从对象在内存中的位置不变的意义上讲，保证对象不移动有时很有用。<br>
//! A prime example of such a scenario would be building self-referential structs, as moving an object with pointers to itself will invalidate them, which could cause undefined behavior. <br>这种情况的一个主要示例是构建自引用结构体，因为移动带有指向自身的指针的对象会使它们无效，这可能导致未定义的行为。<br>
//!
//! At a high level, a <code>[Pin]\<P></code> ensures that the pointee of any pointer type `P` has a stable location in memory, meaning it cannot be moved elsewhere and its memory cannot be deallocated until it gets dropped. <br>在高层次上，<code>[Pin]\</code><P> 确保任何指针类型 `P` 的指针在内存中都有一个稳定的位置，这意味着它不能被移动到其他地方，并且它的内存不能被释放，直到它被丢弃。<br> We say that the pointee is "pinned". <br>我们说该对象是 "pinned"。<br> Things get more subtle when discussing types that combine pinned with non-pinned data; <br>当讨论将固定数据与非固定数据结合在一起的类型时，事情变得更加微妙。<br> [see below](#projections-and-structural-pinning) for more details. <br>[查看下文](#projections-and-structural-pinning) 了解更多详细信息。<br>
//!
//! By default, all types in Rust are movable. <br>默认情况下，Rust 中的所有类型都是可移动的。<br>
//! Rust allows passing all types by-value, and common smart-pointer types such as <code>[Box]\<T></code> and <code>[&mut] T</code> allow replacing and moving the values they contain: you can move out of a <code>[Box]\<T></code>, or you can use [`mem::swap`]. <br>Rust 允许按值传递所有类型，以及常见的智能指针类型，例如 <code>[Box]\</code><T> 和 <code>[&mut] T</code> 允许替换和移动它们包含的值：您可以移出 <code>[Box]\</code><T>，或者您可以使用 [`mem::swap`]。<br> <code>[Pin]\<P></code> wraps a pointer type `P`, so <code>[Pin]<[Box]\<T>></code> functions much like a regular <code>[Box]\<T></code>: <br><code>[Pin]\</code><P> 包装一个指针类型 `P`，所以 <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code> 函数很像一个普通的 <code>[Box]\</code><T>：<br>
//! when a <code>[Pin]<[Box]\<T>></code> gets dropped, so do its contents, and the memory gets deallocated. <br>当 <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code> 被丢弃，其内容也被丢弃，内存被释放。<br> Similarly, <code>[Pin]<[&mut] T></code> is a lot like <code>[&mut] T</code>. <br>类似地，<code>[Pin]<[&mut] T></code>很像 <code>[&mut] T</code>。<br>
//! However, <code>[Pin]\<P></code> does not let clients actually obtain a <code>[Box]\<T></code> or <code>[&mut] T</code> to pinned data, which implies that you cannot use operations such as [`mem::swap`]: <br>然而，<code>[Pin]\</code><P> 不让客户实际获得 <code>[Box]\</code><T> 或 <code>[&mut] T</code> 固定数据，这意味着您不能使用 [`mem::swap`] 之类的操作：<br>
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` needs `&mut T`, but we cannot get it. <br>`mem::swap` 需要 `&mut T`，但我们无法得到它。<br>
//!     // We are stuck, we cannot swap the contents of these references. <br>我们被困住了，我们不能交换这些引用的内容。<br>
//!     // We could use `Pin::get_unchecked_mut`, but that is unsafe for a reason: <br>我们可以使用 `Pin::get_unchecked_mut`，但这是不安全的，原因如下：<br>
//!     // we are not allowed to use it for moving things out of the `Pin`. <br>我们不允许将其用于将物品移出 `Pin`。<br>
//! }
//! ```
//!
//! It is worth reiterating that <code>[Pin]\<P></code> does *not* change the fact that a Rust compiler considers all types movable. <br>值得重申的是 <code>[Pin]\</code><P> 不会改变一个事实，即 Rust 编译器认为所有类型都是可移动的。<br>
//! [`mem::swap`] remains callable for any `T`. <br>[`mem::swap`] 仍可用于任何 `T`。<br>
//! Instead, <code>[Pin]\<P></code> prevents certain *values* (pointed to by pointers wrapped in <code>[Pin]\<P></code>) from being moved by making it impossible to call methods that require <code>[&mut] T</code> on them (like [`mem::swap`]). <br>相反，<code>[Pin]\</code><P> 防止某些值 (由 <code>[Pin]\</code><P>) 使其无法调用需要 <code>[&mut] T</code> 方法 (如 [`mem::swap`]) 而被移动。<br>
//!
//! <code>[Pin]\<P></code> can be used to wrap any pointer type `P`, and as such it interacts with [`Deref`] and [`DerefMut`]. <br><code>[Pin]\</code><P> 可用于包装任何指针类型 `P`，因此它与 [`Deref`] 和 [`DerefMut`] 交互。<br> A <code>[Pin]\<P></code> where <code>P: [Deref]</code> should be considered as a "`P`-style pointer" to a pinned <code>P::[Target]</code> – so, a <code>[Pin]<[Box]\<T>></code> is an owned pointer to a pinned `T`, and a <code>[Pin]<[Rc]\<T>></code> is a reference-counted pointer to a pinned `T`. <br><code>[Pin]\</code><P>其中 <code>P: [Deref]</code> 应被视为固定 <code>P::[Target]</code>的 "`P`-style pointer" - 因此，<code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code>是指向固定 `T` 的拥有指针，以及 <code>[Pin]<[Rc]\></code><T><code>[Pin]<[Rc]\></code> 是指向固定 `T` 的引用计数指针。<br>
//! For correctness, <code>[Pin]\<P></code> relies on the implementations of [`Deref`] and [`DerefMut`] not to move out of their `self` parameter, and only ever to return a pointer to pinned data when they are called on a pinned pointer. <br>为正确起见，<code>[Pin]\</code><P> 依赖于 [`Deref`] 和 [`DerefMut`] 的实现不会移出它们的 `self` 参数，并且只在固定指针上调用它们时才返回指向固定数据的指针。<br>
//!
//! # `Unpin`
//!
//! Many types are always freely movable, even when pinned, because they do not rely on having a stable address. <br>即使不固定，许多类型也始终可以自由移动，因为它们不依赖于具有稳定的地址。<br> This includes all the basic types (like [`bool`], [`i32`], and references) as well as types consisting solely of these types. <br>这包括所有原始类型 (如 [`bool`]，[`i32`] 和引用) 以及仅由这些类型组成的类型。<br> Types that do not care about pinning implement the [`Unpin`] auto-trait, which cancels the effect of <code>[Pin]\<P></code>. <br>不关心 pinning 的类型实现了 [`Unpin`] auto-trait，取消了 <code>[Pin]\</code><P>.<br>
//! For <code>T: [Unpin]</code>, <code>[Pin]<[Box]\<T>></code> and <code>[Box]\<T></code> function identically, as do <code>[Pin]<[&mut] T></code> and <code>[&mut] T</code>. <br>对于 <code>T: [Unpin]</code>, <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code> 和 <code>[Box]\</code><T> 函数相同，<code>[Pin]<[&mut] T></code> 和 <code>[&mut] T</code>。<br>
//!
//! Note that pinning and [`Unpin`] only affect the pointed-to type <code>P::[Target]</code>, not the pointer type `P` itself that got wrapped in <code>[Pin]\<P></code>. <br>请注意，固定和 [`Unpin`] 仅影响指向类型 <code>P::[Target]</code>，而不影响包含在 <code>[Pin]\</code> 的指针类型 `P` 本身 <P>.<br>
//! For example, whether or not <code>[Box]\<T></code> is [`Unpin`] has no effect on the behavior of <code>[Pin]<[Box]\<T>></code> (here, `T` is the pointed-to type). <br>例如，是否 <code>[Box]\</code><T> 是 [`Unpin`] 对 <code>[Pin]<[Box]\></code> 的行为没有影响 <T><code>[Pin]<[Box]\></code> (这里，`T` 是指向类型)。<br>
//!
//! # Example: self-referential struct <br>示例：自引用结构体<br>
//!
//! Before we go into more details to explain the guarantees and choices associated with <code>[Pin]\<P></code>, we discuss some examples for how it might be used. <br>在我们详细解释与 <code>[Pin]\</code> 相关的保证和选择之前 <code>[Pin]\</code><P>，我们讨论了一些如何使用它的例子。<br>
//! Feel free to [skip to where the theoretical discussion continues](#drop-guarantee). <br>请随意 [跳到理论讨论的地方继续](#drop-guarantee)。<br>
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // This is a self-referential struct because the slice field points to the data field. <br>这是一个自引用结构体，因为切片字段指向数据字段。<br>
//! // We cannot inform the compiler about that with a normal reference, as this pattern cannot be described with the usual borrowing rules. <br>我们无法通过正常的引用将其告知编译器，因为无法使用通常的借用规则来描述此模式。<br>
//! //
//! // Instead we use a raw pointer, though one which is known not to be null, as we know it's pointing at the string. <br>取而代之的是，我们使用一个裸指针，尽管我们知道它指向的是一个不为 null 的指针。<br>
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // To ensure the data doesn't move when the function returns, we place it in the heap where it will stay for the lifetime of the object, and the only way to access it would be through a pointer to it. <br>为了确保函数返回时数据不会移动，我们将其放置在堆中，以保留对象的生命周期，唯一的访问方法是通过指向它的指针。<br>
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // we only create the pointer once the data is in place otherwise it will have already moved before we even started <br>我们仅在数据到位后创建指针，否则数据将在我们开始之前就已经移动<br>
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // we know this is safe because modifying a field doesn't move the whole struct <br>我们知道这是安全的，因为修改字段不会移动整个结构体<br>
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // The pointer should point to the correct location, so long as the struct hasn't moved. <br>只要结构体没有移动，指针应指向正确的位置。<br>
//! //
//! // Meanwhile, we are free to move the pointer around. <br>同时，我们可以随意移动指针。<br>
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Since our type doesn't implement Unpin, this will fail to compile: <br>由于我们的类型未实现 Unpin，因此无法编译：<br>
//! // let mut new_unmoved = Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Example: intrusive doubly-linked list <br>示例：侵入式双向链表列表<br>
//!
//! In an intrusive doubly-linked list, the collection does not actually allocate the memory for the elements itself. <br>在侵入式双向链表中，集合实际上并未为元素本身分配内存。<br>
//! Allocation is controlled by the clients, and elements can live on a stack frame that lives shorter than the collection does. <br>分配由客户端控制，元素可以驻留在比集合短的栈框架上。<br>
//!
//! To make this work, every element has pointers to its predecessor and successor in the list. <br>为了使此工作有效，列表中的每个元素都有指向其前任和后任的指针。<br> Elements can only be added when they are pinned, because moving the elements around would invalidate the pointers. <br>元素只能在固定时添加，因为四处移动元素会使指针无效。<br> Moreover, the [`Drop`][Drop] implementation of a linked list element will patch the pointers of its predecessor and successor to remove itself from the list. <br>此外，链表元素的 [`Drop`][Drop] 实现将修补其前任和后继的指针以将其从列表中删除。<br>
//!
//! Crucially, we have to be able to rely on [`drop`] being called. <br>至关重要的是，我们必须能够依靠被调用的 [`drop`]。<br> If an element could be deallocated or otherwise invalidated without calling [`drop`], the pointers into it from its neighboring elements would become invalid, which would break the data structure. <br>如果在不调用 [`drop`] 的情况下可以释放元素或使元素无效，则来自其相邻元素的指针将变为无效，这将破坏数据结构体。<br>
//!
//! Therefore, pinning also comes with a [`drop`]-related guarantee. <br>因此，固定还会附带 [丢弃][drop] 相关的保证。<br>
//!
//! # `Drop` guarantee <br>`Drop` 保证<br>
//!
//! The purpose of pinning is to be able to rely on the placement of some data in memory. <br>固定的目的是能够依靠某些数据在内存中的放置。<br>
//! To make this work, not just moving the data is restricted; <br>为了使这项工作有效，不仅限制了移动数据，还限制了数据的传输。<br> deallocating, repurposing, or otherwise invalidating the memory used to store the data is restricted, too. <br>限制用于存储数据的内存的重新分配，重新分配用途或以其他方式使之无效。<br>
//! Concretely, for pinned data you have to maintain the invariant that *its memory will not get invalidated or repurposed from the moment it gets pinned until when [`drop`] is called*. <br>具体来说，对于固定的数据，必须保持不变，即从固定 *its memory 到调用 [`drop`]*，*its memory 都不会失效或重新使用。<br> Only once [`drop`] returns or panics, the memory may be reused. <br>只有 [`drop`] 返回或 panics，才可以重用该内存。<br>
//!
//! Memory can be "invalidated" by deallocation, but also by replacing a <code>[Some]\(v)</code> by [`None`], or calling [`Vec::set_len`] to "kill" some elements off of a vector. <br>内存可以通过释放为 "invalidated"，也可以通过将 <code>[Some]\(v)</code> 替换为 [`None`]，或将 vector 中的某些元素从 [`Vec::set_len`] 调用到 "kill"。<br> It can be repurposed by using [`ptr::write`] to overwrite it without calling the destructor first. <br>可以通过使用 [`ptr::write`] 覆盖它来重新利用它，而无需先调用析构函数。<br> None of this is allowed for pinned data without calling [`drop`]. <br>在不调用 [`drop`] 的情况下，不允许对固定数据进行任何此操作。<br>
//!
//! This is exactly the kind of guarantee that the intrusive linked list from the previous section needs to function correctly. <br>这正是上一节中的侵入式链表需要正确执行函数的一种保证。<br>
//!
//! Notice that this guarantee does *not* mean that memory does not leak! <br>请注意，此保证不代表内存不会泄漏！<br> It is still completely okay to not ever call [`drop`] on a pinned element (e.g., you can still call [`mem::forget`] on a <code>[Pin]<[Box]\<T>></code>). <br>永远不要在固定元素上调用 [`drop`] 仍然是完全可以的 (例如，您仍然可以在 <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code>)。<br> In the example of the doubly-linked list, that element would just stay in the list. <br>在双向链表的示例中，该元素将仅保留在列表中。<br> However you must not free or reuse the storage *without calling [`drop`]*. <br>但是，您不得释放或重用调用 [`drop`]* 的存储 *without。<br>
//!
//! # `Drop` implementation <br>`Drop` 实现<br>
//!
//! If your type uses pinning (such as the two examples above), you have to be careful when implementing [`Drop`][Drop]. <br>如果您的类型使用固定 (例如上面的两个示例)，则在实现 [`Drop`][Drop] 时必须小心。<br> The [`drop`] function takes <code>[&mut] self</code>, but this is called *even if your type was previously pinned*! <br>[`drop`] 函数采用 <code>[&mut] self</code>，但这被称为即使您的类型之前已固定！</code><br> It is as if the compiler automatically called [`Pin::get_unchecked_mut`]. <br>好像编译器自动调用了 [`Pin::get_unchecked_mut`]。<br>
//!
//! This can never cause a problem in safe code because implementing a type that relies on pinning requires unsafe code, but be aware that deciding to make use of pinning in your type (for example by implementing some operation on <code>[Pin]<[&]Self></code> or <code>[Pin]<[&mut] Self></code>) has consequences for your [`Drop`][Drop]implementation as well: if an element of your type could have been pinned, you must treat [`Drop`][Drop] as implicitly taking <code>[Pin]<[&mut] Self></code>. <br>这永远不会在安全代码中导致问题，因为实现依赖于固定的类型需要不安全的代码，但请注意决定在您的类型中使用固定 (例如通过对 <code>[Pin]<[&] Self></code> 或 <code>[Pin]<[&mut] Self></code>) 对您的 [`Drop`][Drop] 实现也有影响：如果您的类型的元素可以被固定，则您必须将 [`Drop`][Drop] 视为隐式使用 <code>[Pin]<[&mut] Self></code> .<br>
//!
//!
//! For example, you could implement [`Drop`][Drop] as follows: <br>例如，您可以按如下方式实现 [`Drop`][Drop]：<br>
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` is okay because we know this value is never used again after being dropped. <br>`new_unchecked` 可以，因为我们知道这个值在被丢弃后再也不会使用了。<br>
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Actual drop code goes here. <br>实际丢弃的代码在此处。<br>
//!         }
//!     }
//! }
//! ```
//!
//! The function `inner_drop` has the type that [`drop`] *should* have, so this makes sure that you do not accidentally use `self`/`this` in a way that is in conflict with pinning. <br>函数 `inner_drop` 具有 *应该* 具有 [`drop`] 的类型，因此可以确保您不会以与固定冲突的方式意外使用 `self`/`this`。<br>
//!
//! Moreover, if your type is `#[repr(packed)]`, the compiler will automatically move fields around to be able to drop them. <br>此外，如果您的类型是 `#[repr(packed)]`，则编译器将自动移动字段以将其删除。<br> It might even do that for fields that happen to be sufficiently aligned. <br>它甚至可以对恰好足够对齐的字段执行此操作。<br> As a consequence, you cannot use pinning with a `#[repr(packed)]` type. <br>因此，您不能使用 `#[repr(packed)]` 类型的固定。<br>
//!
//! # Projections and Structural Pinning <br>投影和结构固定<br>
//!
//! When working with pinned structs, the question arises how one can access the fields of that struct in a method that takes just <code>[Pin]<[&mut] Struct></code>. <br>在使用固定结构体时，问题是如何在只需要 <code>[Pin]<[&mut] 结构体></code> 的方法中访问该结构体的字段。<br>
//! The usual approach is to write helper methods (so called *projections*) that turn <code>[Pin]<[&mut] Struct></code> into a reference to the field, but what type should that reference have? <br>通常的方法是编写辅助方法 (所谓的 *projections*)，将 <code>[Pin]<[&mut] 结构体 ></code> 转换为对字段的引用，但该引用应该具有什么类型？<br> Is it <code>[Pin]<[&mut] Field></code> or <code>[&mut] Field</code>? <br>是 <code>[Pin]<[&mut] Field></code> 还是 <code>[&mut] Field</code>?</code><br>
//! The same question arises with the fields of an `enum`, and also when considering container/wrapper types such as <code>[Vec]\<T></code>, <code>[Box]\<T></code>, or <code>[RefCell]\<T></code>. <br>`enum` 的字段以及在考虑 container/wrapper 类型 (例如 <code>[Vec]\</code><T>, <code>[Box]\</code><T>，或 <code>[RefCell]\</code><T>.<br>
//! (This question applies to both mutable and shared references, we just use the more common case of mutable references here for illustration.) <br>(此问题适用于可变引用和共享引用，我们仅在此处使用可变引用的更常见情况进行说明。)<br>
//!
//! It turns out that it is actually up to the author of the data structure to decide whether the pinned projection for a particular field turns <code>[Pin]<[&mut] Struct></code> into <code>[Pin]<[&mut] Field></code> or <code>[&mut] Field</code>. <br>事实证明，实际上是由数据结构的作者决定特定字段的固定 projection 是将 <code>[Pin]<[&mut] 结构体 ></code> 转换为 <code>[Pin]<[&mut] Field></code> 或 <code>[&mut] Field</code>.</code><br> There are some constraints though, and the most important constraint is *consistency*: <br>但是有一些约束，最重要的约束是 *consistency*：<br>
//! every field can be *either* projected to a pinned reference, *or* have pinning removed as part of the projection. <br>每个字段都可以 *或者* 投影到固定的引用，或者 * 可以删除固定作为投影的一部分。<br>
//! If both are done for the same field, that will likely be unsound! <br>如果两者都是针对同一个字段进行的，那很可能是不合理的！<br>
//!
//! As the author of a data structure you get to decide for each field whether pinning "propagates" to this field or not. <br>作为数据结构体的作者，您可以为每个字段决定是否将 "propagates" 固定到该字段。<br>
//! Pinning that propagates is also called "structural", because it follows the structure of the type. <br>传播的固定也称为 "structural"，因为它遵循该类型的结构体。<br>
//! In the following subsections, we describe the considerations that have to be made for either choice. <br>在以下各小节中，我们描述了两种选择都必须考虑的因素。<br>
//!
//! ## Pinning *is not* structural for `field` <br>Pinning 不是用于结构体的 `field`<br>
//!
//! It may seem counter-intuitive that the field of a pinned struct might not be pinned, but that is actually the easiest choice: if a <code>[Pin]<[&mut] Field></code> is never created, nothing can go wrong! <br>固定结构体的字段可能不被固定似乎违反直觉，但这实际上是最简单的选择：如果从未创建 <code>[Pin]<[&mut] Field></code> 则不会出错！<br> So, if you decide that some field does not have structural pinning, all you have to ensure is that you never create a pinned reference to that field. <br>因此，如果您确定某个字段不具有结构固定，则只需确保您从未创建对该字段的固定引用即可。<br>
//!
//! Fields without structural pinning may have a projection method that turns <code>[Pin]<[&mut] Struct></code> into <code>[&mut] Field</code>: <br>没有结构固定的字段可能具有将 <code>[Pin]<[&mut] 结构体 ></code> 转换为 <code>[&mut] Field</code>:</code> 的 projection 方法 <code>[&mut] Field</code>:</code><br>
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // This is okay because `field` is never considered pinned. <br>可以，因为 `field` 从未被视为固定。<br>
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! You may also <code>impl [Unpin] for Struct</code> *even if* the type of `field` is not [`Unpin`]. <br>您也可以 <code>impl [Unpin] for Struct</code> 即使 `field` 的类型不是 [`Unpin`].</code><br> What that type thinks about pinning is not relevant when no <code>[Pin]<[&mut] Field></code> is ever created. <br>当没有创建 <code>[Pin]<[&mut] Field></code>时，该类型对固定的看法 <code>[Pin]<[&mut] Field></code>。<br>
//!
//! ## Pinning *is* structural for `field` <br>Pinning 是结构体的 `field`<br>
//!
//! The other option is to decide that pinning is "structural" for `field`, meaning that if the struct is pinned then so is the field. <br>另一个选择是确定钉扎是 `field` 还是 `field`，这意味着如果钉扎结构体，则字段也钉扎。<br>
//!
//! This allows writing a projection that creates a <code>[Pin]<[&mut] Field></code>, thus witnessing that the field is pinned: <br>这允许编写一个创建 <code>[Pin]<[&mut] Field></code> 的 projection，从而见证该字段被固定：<br>
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // This is okay because `field` is pinned when `self` is. <br>可以，因为 `self` 固定在 `field` 上。<br>
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! However, structural pinning comes with a few extra requirements: <br>但是，结构固定需要一些额外的要求：<br>
//!
//! 1. The struct must only be [`Unpin`] if all the structural fields are [`Unpin`]. <br>如果所有结构字段均为 [`Unpin`]，则结构体必须仅为 [`Unpin`]。<br> This is the default, but [`Unpin`] is a safe trait, so as the author of the struct it is your responsibility *not* to add something like <code>impl\<T> [Unpin] for Struct\<T></code>. <br>这是默认值，但 [`Unpin`] 是一个安全的 trait，因此作为结构体的作者，您有责任*不*添加类似 <code>impl\[Unpin] for 结构体 \</code><T> <code>impl\[Unpin] for 结构体 \</code><T>.<br> (Notice that adding a projection operation requires unsafe code, so the fact that [`Unpin`] is a safe trait does not break the principle that you only have to worry about any of this if you use [`unsafe`].) <br>(请注意，添加投影操作需要不安全的代码，因此 [`Unpin`] 是安全的 trait 的事实并没有破坏您只需要在使用 [`unsafe`] 时担心任何这些的原则。)<br>
//! 2. The destructor of the struct must not move structural fields out of its argument. <br>结构体的析构函数不得将结构域移出其参数。<br> This is the exact point that was raised in the [previous section][drop-impl]: [`drop`] takes <code>[&mut] self</code>, but the struct (and hence its fields) might have been pinned before. <br>这正是 [上一节][drop-impl] 中提出的要点: [`drop`] 采用 <code>[&mut] self</code>，但是结构体 (以及它的字段) 之前可能已经被固定了。</code><br> You have to guarantee that you do not move a field inside your [`Drop`][Drop] implementation. <br>您必须保证不会在您的 [`Drop`][Drop] 实现中移动任何字段。<br> In particular, as explained previously, this means that your struct must *not* be `#[repr(packed)]`. <br>特别是，如前所述，这意味着您的结构体 *不能* 为 `#[repr(packed)]`。<br>
//!     See that section for how to write [`drop`] in a way that the compiler can help you not accidentally break pinning. <br>有关如何编写 [`drop`] 的方法，请参见该部分，以使编译器可以帮助您避免意外破坏固定。<br>
//! 3. You must make sure that you uphold the [`Drop` guarantee][drop-guarantee]: <br>您必须确保遵守使用 [`Drop` 保证][drop-guarantee]：<br>
//!     once your struct is pinned, the memory that contains the content is not overwritten or deallocated without calling the content's destructors. <br>一旦固定了您的结构体，包含内容的内存就不会被覆盖或释放，而无需调用内容的析构函数。<br>
//!     This can be tricky, as witnessed by <code>[VecDeque]\<T></code>: the destructor of <code>[VecDeque]\<T></code> can fail to call [`drop`] on all elements if one of the destructors panics. <br>这可能很棘手，正如 <code>[VecDeque]\</code><T>: <code>[VecDeque]\</code> 的析构函数 <code>[VecDeque]\</code><T> 如果析构函数 panics 之一，则可能无法在所有元素上调用 [`drop`]。<br> This violates the [`Drop`][Drop] guarantee, because it can lead to elements being deallocated without their destructor being called. <br>这违反了 [`Drop`][Drop] 保证，因为它可能导致元素在没有调用析构函数的情况下被释放。<br>
//!     (<code>[VecDeque]\<T></code> has no pinning projections, so this does not cause unsoundness.) <br>(<code>[VecDeque]\</code><T> 没有固定 projection，所以这不会导致不稳定。)<br>
//! 4. You must not offer any other operations that could lead to data being moved out of the structural fields when your type is pinned. <br>固定类型时，不得提供可能导致数据移出结构字段的任何其他操作。<br> For example, if the struct contains an <code>[Option]\<T></code> and there is a [`take`][Option::take]-like operation with type <code>fn([Pin]<[&mut] Struct\<T>>) -> [Option]\<T></code>, that operation can be used to move a `T` out of a pinned `Struct<T>` – which means pinning cannot be structural for the field holding this data. <br>例如，如果结构体包含一个 <code>[Option]\</code><T>并且有一个类似 [`take`][Option::take] 的操作，类型为 <code>fn ([Pin]<[&mut] 结构体 \>) -> [Option]\</code><T> <code>fn ([Pin]<[&mut] 结构体 \>) -> [Option]\</code><T>，该操作可用于将 `T` 从固定的 `Struct<T>` 中移出 - 这意味着固定不能对保存此数据的字段进行结构化。<br>
//!
//!     For a more complex example of moving data out of a pinned type, imagine if <code>[RefCell]\<T></code> had a method <code>fn get_pin_mut(self: [Pin]<[&mut] Self>) -> [Pin]<[&mut] T></code>. <br>有关将数据移出固定类型的更复杂示例，请想象如果 <code>[RefCell]\</code><T>有一个方法 <code>fn get_pin_mut(self: [Pin]<[&mut] Self>) -> [Pin]<[&mut] T></code>。<br>
//!     Then we could do the following: <br>然后，我们可以执行以下操作：<br>
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`. <br>在这里，我们可以固定访问 `T`。<br>
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data. <br>这里我们有 `&mut T` 到相同的数据。<br>
//!     }
//!     ```
//!
//!     This is catastrophic, it means we can first pin the content of the <code>[RefCell]\<T></code> (using <code>[RefCell]::get_pin_mut</code>) and then move that content using the mutable reference we got later. <br>这是灾难性的，这意味着我们可以先固定 <code>[RefCell]\</code><T> (使用 <code>[RefCell]::get_pin_mut</code> ) 然后使用我们稍后获得的 <code>[RefCell]::get_pin_mut</code> 引用移动该内容。<br>
//!
//! ## Examples
//!
//! For a type like <code>[Vec]\<T></code>, both possibilities (structural pinning or not) make sense. <br>对于像 <code>[Vec]\</code> 这样的类型 <T>，两种可能性 (结构固定与否) 都有意义。<br> A <code>[Vec]\<T></code> with structural pinning could have `get_pin`/`get_pin_mut` methods to get pinned references to elements. <br><code>[Vec]\</code><T> 使用结构固定可以有 `get_pin`/`get_pin_mut` 方法来固定引用到元素。<br> However, it could *not* allow calling [`pop`][Vec::pop] on a pinned <code>[Vec]\<T></code> because that would move the (structurally pinned) contents! <br>但是，它可能*不允许*在固定的 <code>[Vec]\</code> 上调用 [`pop`][Vec::pop]<T> 因为那会移动 (结构固定的) 内容！<br> Nor could it allow [`push`][Vec::push], which might reallocate and thus also move the contents. <br>它也不允许 [`push`][Vec::push]，它可能会重新分配并因此也移动内容。<br>
//!
//! A <code>[Vec]\<T></code> without structural pinning could <code>impl\<T> [Unpin] for [Vec]\<T></code>, because the contents are never pinned and the <code>[Vec]\<T></code> itself is fine with being moved as well. <br><code>[Vec]\</code><T>没有结构固定可以 <code>impl\[Unpin] for [Vec]\</code><T> <code>impl\[Unpin] for [Vec]\</code><T>，因为内容永远不会被固定并且 <code>[Vec]\</code><T> 本身也可以移动。<br>
//! At that point pinning just has no effect on the vector at all. <br>那时，固定对 vector 完全没有影响。<br>
//!
//! In the standard library, pointer types generally do not have structural pinning, and thus they do not offer pinning projections. <br>在标准库中，指针类型通常不具有结构固定，因此它们不提供固定投影。<br> This is why <code>[Box]\<T>: [Unpin]</code> holds for all `T`. <br>这就是为什么 <code>[Box]\: [Unpin]</code><T><code>[Box]\: [Unpin]</code> Unpin <code>[Box]\: [Unpin]</code> 适用于所有 `T`。<br> It makes sense to do this for pointer types, because moving the <code>[Box]\<T></code> does not actually move the `T`: the <code>[Box]\<T></code> can be freely movable (aka [`Unpin`]) even if the `T` is not. <br>对指针类型这样做是有意义的，因为移动 <code>[Box]\</code><T> 实际上并没有移动 `T`: <code>[Box]\</code><T> 即使 `T` 不是，也可以自由移动 (又名 [`Unpin`])。<br>
//! In fact, even <code>[Pin]<[Box]\<T>></code> and <code>[Pin]<[&mut] T></code> are always [`Unpin`] themselves, for the same reason: <br>事实上，即使 <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code> 和 <code>[Pin]<[&mut] T></code> 总是 [`Unpin`] 本身，原因相同：<br>
//! their contents (the `T`) are pinned, but the pointers themselves can be moved without moving the pinned data. <br>它们的内容 (`T`) 是固定的，但指针本身可以在不移动固定数据的情况下移动。<br>
//! For both <code>[Box]\<T></code> and <code>[Pin]<[Box]\<T>></code>, whether the content is pinned is entirely independent of whether the pointer is pinned, meaning pinning is *not* structural. <br>对于 <code>[Box]\</code><T> 和 <code>[Pin]<[Box]\></code><T><code>[Pin]<[Box]\></code>，内容是否固定完全独立于指针是否固定，意味着固定是*非*结构的。<br>
//!
//! When implementing a [`Future`] combinator, you will usually need structural pinning for the nested futures, as you need to get pinned references to them to call [`poll`]. <br>当实现 [`Future`] 组合器时，通常需要对嵌套的 futures 进行结构钉扎，因为您需要将引用的钉扎到 [`poll`] 上。<br>
//! But if your combinator contains any other data that does not need to be pinned, you can make those fields not structural and hence freely access them with a mutable reference even when you just have <code>[Pin]<[&mut] Self></code> (such as in your own [`poll`] implementation). <br>但是，如果您的组合器包含任何其他不需要固定的数据，您可以使这些字段不是结构化的，因此即使您只有 <code>[Pin]<[&mut] Self></code> (例如在您自己的 [`poll`] 实现中)。<br>
//!
//! [Deref]: crate::ops::Deref "ops::Deref"
//! [`Deref`]: crate::ops::Deref "ops::Deref"
//! [Target]: crate::ops::Deref::Target "ops::Deref::Target"
//! [`DerefMut`]: crate::ops::DerefMut "ops::DerefMut"
//! [`mem::swap`]: crate::mem::swap "mem::swap"
//! [`mem::forget`]: crate::mem::forget "mem::forget"
//! [Vec]: ../../std/vec/struct.Vec.html "Vec"
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len "Vec::set_len"
//! [Box]: ../../std/boxed/struct.Box.html "Box"
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop "Vec::pop"
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push "Vec::push"
//! [Rc]: ../../std/rc/struct.Rc.html "rc::Rc"
//! [RefCell]: crate::cell::RefCell "cell::RefCell"
//! [`drop`]: Drop::drop
//! [VecDeque]: ../../std/collections/struct.VecDeque.html "collections::VecDeque"
//! [`ptr::write`]: crate::ptr::write "ptr::write"
//! [`Future`]: crate::future::Future "future::Future"
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll "future::Future::poll"
//! [&]: reference "shared reference"
//! [&mut]: reference "mutable reference"
//! [`unsafe`]: ../../std/keyword.unsafe.html "keyword unsafe"
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// A pinned pointer. <br>固定的指针。<br>
///
/// This is a wrapper around a kind of pointer which makes that pointer "pin" its value in place, preventing the value referenced by that pointer from being moved unless it implements [`Unpin`]. <br>这是一种指针的包装，该指针使该指针 "pin" 成为其值，从而防止该指针引用的值被移动，除非它实现 [`Unpin`]。<br>
///
///
/// *See the [`pin` module] documentation for an explanation of pinning. <br>有关固定的说明，请参见 [`pin` module] 文档。<br>*
///
/// [`pin` module]: self
///
// Note: the `Clone` derive below causes unsoundness as it's possible to implement `Clone` for mutable references. <br>下面的 `Clone` 派生导致不完善，因为可以为可变引用实现 `Clone`。<br>
//
// See <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> for more details. <br>有关更多详细信息，请参见 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>。<br>
//
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// The following implementations aren't derived in order to avoid soundness issues. <br>为了避免出现健全性问题，没有实现以下实现。<br>
// `&self.pointer` should not be accessible to untrusted trait implementations. <br>不受信任的 trait 实现不应访问 `&self.pointer`。<br>
//
// See <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> for more details. <br>有关更多详细信息，请参见 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>。<br>
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construct a new `Pin<P>` around a pointer to some data of a type that implements [`Unpin`]. <br>围绕一个指向实现 [`Unpin`] 类型的数据的指针，创建一个新的 `Pin<P>`。<br>
    ///
    /// Unlike `Pin::new_unchecked`, this method is safe because the pointer `P` dereferences to an [`Unpin`] type, which cancels the pinning guarantees. <br>与 `Pin::new_unchecked` 不同，此方法是安全的，因为指针 `P` 解引用了 [`Unpin`] 类型，从而取消了固定保证。<br>
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: the value pointed to is `Unpin`, and so has no requirements around pinning. <br>指向的值是 `Unpin`，因此对固定没有要求。<br>
        //
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps this `Pin<P>` returning the underlying pointer. <br>解包此 `Pin<P>`，返回底层指针。<br>
    ///
    /// This requires that the data inside this `Pin` is [`Unpin`] so that we can ignore the pinning invariants when unwrapping it. <br>这要求该 `Pin` 内部的数据为 [`Unpin`]，以便我们在展开包装时可以忽略固定不变量。<br>
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construct a new `Pin<P>` around a reference to some data of a type that may or may not implement `Unpin`. <br>围绕引用可能会或可能不会实现 `Unpin` 的某些数据，创建一个新的 `Pin<P>`。<br>
    ///
    /// If `pointer` dereferences to an `Unpin` type, `Pin::new` should be used instead. <br>如果 `pointer` 解引用 `Unpin` 类型，则应改用 `Pin::new`。<br>
    ///
    /// # Safety
    ///
    /// This constructor is unsafe because we cannot guarantee that the data pointed to by `pointer` is pinned, meaning that the data will not be moved or its storage invalidated until it gets dropped. <br>此构造函数是不安全的，因为我们不能保证 `pointer` 指向的数据是固定的，这意味着在丢弃数据之前，数据将不会移动或存储空间无效。<br>
    /// If the constructed `Pin<P>` does not guarantee that the data `P` points to is pinned, that is a violation of the API contract and may lead to undefined behavior in later (safe) operations. <br>如果构造的 `Pin<P>` 不能保证数据 `P` 指向固定的，则违反了 API 约定，并可能在以后的 (safe) 操作中导致未定义的行为。<br>
    ///
    /// By using this method, you are making a promise about the `P::Deref` and `P::DerefMut` implementations, if they exist. <br>通过使用此方法，您正在制作有关 `P::Deref` 和 `P::DerefMut` 实现的 promise (如果存在)。<br>
    /// Most importantly, they must not move out of their `self` arguments: `Pin::as_mut` and `Pin::as_ref` will call `DerefMut::deref_mut` and `Deref::deref` *on the pinned pointer* and expect these methods to uphold the pinning invariants. <br>最重要的是，它们一定不能移出 `self` 参数: `Pin::as_mut` 和 `Pin::as_ref` 将调用 `DerefMut::deref_mut` 和 `Deref::deref`*on the 固定指针*，并期望这些方法支持固定不变性。<br>
    /// Moreover, by calling this method you promise that the reference `P` dereferences to will not be moved out of again; <br>此外，通过调用此方法，不会再移出引用 `P` 引用的 promise；<br> in particular, it must not be possible to obtain a `&mut P::Target` and then move out of that reference (using, for example [`mem::swap`]). <br>特别是，必须不可能先获得 `&mut P::Target`，然后再移出该引用 (例如，使用 [`mem::swap`])。<br>
    ///
    ///
    /// For example, calling `Pin::new_unchecked` on an `&'a mut T` is unsafe because while you are able to pin it for the given lifetime `'a`, you have no control over whether it is kept pinned once `'a` ends: <br>例如，在 `&'a mut T` 上调用 `Pin::new_unchecked` 是不安全的，因为虽然可以为给定的生命周期 `'a` 固定 `Pin::new_unchecked`，但是您无法控制 `'a` 结束后是否保持固定状态：<br>
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // This should mean the pointee `a` can never move again. <br>这应该意味着指针 `a` 再也无法移动了。<br>
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // The address of `a` changed to `b`'s stack slot, so `a` got moved even though we have previously pinned it! <br>`a` 的地址更改为 `b` 的栈插槽，因此即使我们先前已将其固定，`a` 还是被移动了！<br> We have violated the pinning API contract. <br>我们违反了固定 API 契约。<br>
    /////
    /// }
    /// ```
    ///
    /// A value, once pinned, must remain pinned forever (unless its type implements `Unpin`). <br>固定后的值必须永远固定 (除非其类型实现 `Unpin`)。<br>
    ///
    /// Similarly, calling `Pin::new_unchecked` on an `Rc<T>` is unsafe because there could be aliases to the same data that are not subject to the pinning restrictions: <br>同样，在 `Rc<T>` 上调用 `Pin::new_unchecked` 是不安全的，因为相同数据的别名可能不受固定限制的限制：<br>
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // This should mean the pointee can never move again. <br>这应该意味着指向者永远不能再移动。<br>
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Now, if `x` was the only reference, we have a mutable reference to data that we pinned above, which we could use to move it as we have seen in the previous example. <br>现在，如果 `x` 是唯一的引用，则对上面固定的数据有一个变量引用，就像在上一个示例中看到的那样，我们可以使用它来移动它。<br>
    ///     // We have violated the pinning API contract. <br>我们违反了固定 API 契约。<br>
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Gets a pinned shared reference from this pinned pointer. <br>从此固定指针获取固定共享引用。<br>
    ///
    /// This is a generic method to go from `&Pin<Pointer<T>>` to `Pin<&T>`. <br>这是从 `&Pin<Pointer<T>>` 到 `Pin<&T>` 的通用方法。<br>
    /// It is safe because, as part of the contract of `Pin::new_unchecked`, the pointee cannot move after `Pin<Pointer<T>>` got created. <br>这是安全的，因为作为 `Pin::new_unchecked` 契约的一部分，在创建 `Pin<Pointer<T>>` 之后，指针无法移动。<br>
    ///
    /// "Malicious" implementations of `Pointer::Deref` are likewise ruled out by the contract of `Pin::new_unchecked`. <br>`Pointer::Deref` 的 "Malicious" 实现同样被 `Pin::new_unchecked` 的契约排除在外。<br>
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: see documentation on this function <br>请参见此函数的文档<br>
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps this `Pin<P>` returning the underlying pointer. <br>解包此 `Pin<P>`，返回底层指针。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe. <br>该函数是不安全的。<br> You must guarantee that you will continue to treat the pointer `P` as pinned after you call this function, so that the invariants on the `Pin` type can be upheld. <br>您必须保证在调用此函数后，将继续将指针 `P` 视为固定指针，以便可以支持 `Pin` 类型上的不变量。<br>
    /// If the code using the resulting `P` does not continue to maintain the pinning invariants that is a violation of the API contract and may lead to undefined behavior in later (safe) operations. <br>如果使用生成的 `P` 的代码不能继续维护违反 API 约定的固定不变量，则可能会在以后的 (safe) 操作中导致未定义的行为。<br>
    ///
    ///
    /// If the underlying data is [`Unpin`], [`Pin::into_inner`] should be used instead. <br>如果底层数据是 [`Unpin`]，则应改为使用 [`Pin::into_inner`]。<br>
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Gets a pinned mutable reference from this pinned pointer. <br>从此固定指针获取固定变量引用。<br>
    ///
    /// This is a generic method to go from `&mut Pin<Pointer<T>>` to `Pin<&mut T>`. <br>这是从 `&mut Pin<Pointer<T>>` 到 `Pin<&mut T>` 的通用方法。<br>
    /// It is safe because, as part of the contract of `Pin::new_unchecked`, the pointee cannot move after `Pin<Pointer<T>>` got created. <br>这是安全的，因为作为 `Pin::new_unchecked` 契约的一部分，在创建 `Pin<Pointer<T>>` 之后，指针无法移动。<br>
    ///
    /// "Malicious" implementations of `Pointer::DerefMut` are likewise ruled out by the contract of `Pin::new_unchecked`. <br>`Pointer::DerefMut` 的 "Malicious" 实现同样被 `Pin::new_unchecked` 的契约排除在外。<br>
    ///
    /// This method is useful when doing multiple calls to functions that consume the pinned type. <br>当对使用固定类型的函数进行多次调用时，此方法很有用。<br>
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // do something <br>做一点事<br>
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consumes `self`, so reborrow the `Pin<&mut Self>` via `as_mut`. <br>`method` 消耗 `self`，因此通过 `as_mut` 重新借用 `Pin<&mut Self>`。<br>
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: see documentation on this function <br>请参见此函数的文档<br>
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Assigns a new value to the memory behind the pinned reference. <br>为固定的引用后面的内存分配一个新值。<br>
    ///
    /// This overwrites pinned data, but that is okay: its destructor gets run before being overwritten, so no pinning guarantee is violated. <br>这会覆盖固定的数据，但是没关系：它的析构函数在被覆盖之前就已运行，因此不会违反固定保证。<br>
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Constructs a new pin by mapping the interior value. <br>通过映射内部值创建一个新的引脚。<br>
    ///
    /// For example, if you  wanted to get a `Pin` of a field of something, you could use this to get access to that field in one line of code. <br>例如，如果要获取某字段的 `Pin`，则可以使用它在一行代码中访问该字段。<br>
    /// However, there are several gotchas with these "pinning projections"; <br>但是，这些 "pinning projections" 有一些陷阱。<br>
    /// see the [`pin` module] documentation for further details on that topic. <br>有关该主题的更多详细信息，请参见 [`pin` module] 文档。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe. <br>该函数是不安全的。<br>
    /// You must guarantee that the data you return will not move so long as the argument value does not move (for example, because it is one of the fields of that value), and also that you do not move out of the argument you receive to the interior function. <br>您必须确保只要参数值不移动，返回的数据就不会移动 (例如，因为它是该值的字段之一)，并且还必须确保不会将其移出接收到的参数内部功能。<br>
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: the safety contract for `new_unchecked` must be upheld by the caller. <br>调用者必须遵守 `new_unchecked` 的安全保证。<br>
        //
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Gets a shared reference out of a pin. <br>从 pin 中获取共享引用。<br>
    ///
    /// This is safe because it is not possible to move out of a shared reference. <br>这是安全的，因为不可能移出共享引用。<br>
    /// It may seem like there is an issue here with interior mutability: in fact, it *is* possible to move a `T` out of a `&RefCell<T>`. <br>内部可变性似乎存在问题：实际上，可以将 `T` 从 `&RefCell<T>` 中移出。<br>
    /// However, this is not a problem as long as there does not also exist a `Pin<&T>` pointing to the same data, and `RefCell<T>` does not let you create a pinned reference to its contents. <br>但是，只要不存在指向相同数据的 `Pin<&T>`，并且 `RefCell<T>` 不允许您创建对其内容的固定引用，这也不是问题。<br>
    ///
    /// See the discussion on ["pinning projections"] for further details. <br>有关更多详细信息，请参见 ["pinning projections"] 上的讨论。<br>
    ///
    /// Note: `Pin` also implements `Deref` to the target, which can be used to access the inner value. <br>`Pin` 还对目标实现 `Deref`，可用于访问内部值。<br>
    /// However, `Deref` only provides a reference that lives for as long as the borrow of the `Pin`, not the lifetime of the `Pin` itself. <br>但是，`Deref` 仅提供一个引用，该引用的生命周期与 `Pin` 的借用时间一样长，而不是 `Pin` 本身的生命周期。<br>
    /// This method allows turning the `Pin` into a reference with the same lifetime as the original `Pin`. <br>这种方法可以将 `Pin` 转换为引用，并具有与原始 `Pin` 相同的生命周期。<br>
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[must_use]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converts this `Pin<&mut T>` into a `Pin<&T>` with the same lifetime. <br>将此 `Pin<&mut T>` 转换为具有相同生命周期的 `Pin<&T>`。<br>
    #[inline(always)]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Gets a mutable reference to the data inside of this `Pin`. <br>获取对此 `Pin` 内部数据的可变引用。<br>
    ///
    /// This requires that the data inside this `Pin` is `Unpin`. <br>这要求该 `Pin` 内部的数据为 `Unpin`。<br>
    ///
    /// Note: `Pin` also implements `DerefMut` to the data, which can be used to access the inner value. <br>`Pin` 还对数据实现 `DerefMut`，可用于访问内部值。<br>
    /// However, `DerefMut` only provides a reference that lives for as long as the borrow of the `Pin`, not the lifetime of the `Pin` itself. <br>但是，`DerefMut` 仅提供一个引用，该引用生命周期与 `Pin` 的借用时间一样长，而不是 `Pin` 本身的生命周期。<br>
    ///
    /// This method allows turning the `Pin` into a reference with the same lifetime as the original `Pin`. <br>这种方法可以将 `Pin` 转换为引用，并具有与原始 `Pin` 相同的生命周期。<br>
    ///
    #[inline(always)]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Gets a mutable reference to the data inside of this `Pin`. <br>获取对此 `Pin` 内部数据的可变引用。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe. <br>该函数是不安全的。<br>
    /// You must guarantee that you will never move the data out of the mutable reference you receive when you call this function, so that the invariants on the `Pin` type can be upheld. <br>您必须保证在调用此函数时，永远不会将数据移出您收到的可变引用，以便可以支持 `Pin` 类型的不变量。<br>
    ///
    ///
    /// If the underlying data is `Unpin`, `Pin::get_mut` should be used instead. <br>如果底层数据是 `Unpin`，则应改用 `Pin::get_mut`。<br>
    ///
    #[inline(always)]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construct a new pin by mapping the interior value. <br>通过映射内部值创建一个新的引脚。<br>
    ///
    /// For example, if you  wanted to get a `Pin` of a field of something, you could use this to get access to that field in one line of code. <br>例如，如果要获取某字段的 `Pin`，则可以使用它在一行代码中访问该字段。<br>
    /// However, there are several gotchas with these "pinning projections"; <br>但是，这些 "pinning projections" 有一些陷阱。<br>
    /// see the [`pin` module] documentation for further details on that topic. <br>有关该主题的更多详细信息，请参见 [`pin` module] 文档。<br>
    ///
    /// # Safety
    ///
    /// This function is unsafe. <br>该函数是不安全的。<br>
    /// You must guarantee that the data you return will not move so long as the argument value does not move (for example, because it is one of the fields of that value), and also that you do not move out of the argument you receive to the interior function. <br>您必须确保只要参数值不移动，返回的数据就不会移动 (例如，因为它是该值的字段之一)，并且还必须确保不会将其移出接收到的参数内部功能。<br>
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: the caller is responsible for not moving the value out of this reference. <br>调用者负责不将值移出该引用。<br>
        //
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: as the value of `this` is guaranteed to not have been moved out, this call to `new_unchecked` is safe. <br>由于保证 `this` 的值不会被移出，因此对 `new_unchecked` 的调用是安全的。<br>
        //
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Get a pinned reference from a static reference. <br>从固定引用中获取固定引用。<br>
    ///
    /// This is safe, because `T` is borrowed for the `'static` lifetime, which never ends. <br>这是安全的，因为 `T` 是 `'static` 生命周期的借用，而生命周期永远不会结束。<br>
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: The 'static borrow guarantees the data will not be moved/invalidated until it gets dropped (which is never). <br>静态借用保证数据在被丢弃之前不会被移动/失效 (永远不会)。<br>
        //
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<'a, P: DerefMut> Pin<&'a mut Pin<P>> {
    /// Gets a pinned mutable reference from this nested pinned pointer. <br>从此嵌套的固定指针获取固定的可变引用。<br>
    ///
    /// This is a generic method to go from `Pin<&mut Pin<Pointer<T>>>` to `Pin<&mut T>`. <br>这是从 `Pin<&mut Pin<Pointer<T>>>` 到 `Pin<&mut T>` 的泛型方法。<br>
    /// It is safe because the existence of a `Pin<Pointer<T>>` ensures that the pointee, `T`, cannot move in the future, and this method does not enable the pointee to move. <br>它是安全的，因为 `Pin<Pointer<T>>` 的存在确保了指向者 `T` 在 future 中不能移动，并且该方法不会使指向者移动。<br>
    ///
    /// "Malicious" implementations of `P::DerefMut` are likewise ruled out by the contract of `Pin::new_unchecked`. <br>`P::DerefMut` 的 "Malicious" 实现同样被 `Pin::new_unchecked` 的契约排除在外。<br>
    ///
    #[unstable(feature = "pin_deref_mut", issue = "86918")]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[inline(always)]
    pub fn as_deref_mut(self) -> Pin<&'a mut P::Target> {
        // SAFETY: What we're asserting here is that going from <br>我们在这里断言的是，从<br>
        //
        //     Pin<&mut Pin<P>>
        //
        // to
        //
        //     Pin<&mut P::Target>
        //
        // is safe. <br>是安全的。<br>
        //
        // We need to ensure that two things hold for that to be the case: <br>我们需要确保有两件事能够做到这一点：<br>
        //
        // 1) Once we give out a `Pin<&mut P::Target>`, an `&mut P::Target` will not be given out. <br>一旦我们发出 `Pin<&mut P::Target>`，就不会发出 `&mut P::Target`。<br>
        // 2) By giving out a `Pin<&mut P::Target>`, we do not risk of violating `Pin<&mut Pin<P>>` <br>通过发放 `Pin<&mut P::Target>`，我们没有违反 `Pin<&mut Pin<P>>` 的风险<br>
        //
        // The existence of `Pin<P>` is sufficient to guarantee #1: since we already have a `Pin<P>`, it must already uphold the pinning guarantees, which must mean that `Pin<&mut P::Target>` does as well, since `Pin::as_mut` is safe. <br>`Pin<P>` 的存在足以保证 #1: 因为我们已经有了 `Pin<P>`，它必须已经维护了固定保证，这意味着 `Pin<&mut P::Target>` 也可以，因为 `Pin::as_mut` 是安全的。<br>
        // We do not have to rely on the fact that P is _also_ pinned. <br>我们不必依赖 P 也被固定的事实。<br>
        //
        // For #2, we need to ensure that code given a `Pin<&mut P::Target>` cannot cause the `Pin<P>` to move? <br>对于 #2，我们需要确保给定 `Pin<&mut P::Target>` 的代码不会导致 `Pin<P>` 移动？<br> That is not possible, since `Pin<&mut P::Target>` no longer retains any access to the `P` itself, much less the `Pin<P>`. <br>这是不可能的，因为 `Pin<&mut P::Target>` 不再保留对 `P` 本身的任何访问权限，更不用说 `Pin<P>`。<br>
        //
        //
        //
        //
        unsafe { self.get_unchecked_mut() }.as_mut()
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Get a pinned mutable reference from a static mutable reference. <br>从静态变量引用中获取固定的变量引用。<br>
    ///
    /// This is safe, because `T` is borrowed for the `'static` lifetime, which never ends. <br>这是安全的，因为 `T` 是 `'static` 生命周期的借用，而生命周期永远不会结束。<br>
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: The 'static borrow guarantees the data will not be moved/invalidated until it gets dropped (which is never). <br>静态借用保证数据在被丢弃之前不会被移动/失效 (永远不会)。<br>
        //
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: this means that any impl of `CoerceUnsized` that allows coercing from a type that impls `Deref<Target=impl !Unpin>` to a type that impls `Deref<Target=Unpin>` is unsound. <br>这意味着 `CoerceUnsized` 允许从 `Deref<Target=impl !Unpin>` 的类型强制转换为 `Deref<Target=Unpin>` 的类型的任何隐含声音都是不正确的。<br>
// Any such impl would probably be unsound for other reasons, though, so we just need to take care not to allow such impls to land in std. <br>但是，由于其他原因，任何这样的提示可能都不合理，因此我们只需要注意不要让这样的提示降落在 std 中。<br>
//
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}
