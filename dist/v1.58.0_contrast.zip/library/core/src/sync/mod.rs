//! Synchronization primitives <br>同步原语<br>

#![stable(feature = "rust1", since = "1.0.0")]

pub mod atomic;
