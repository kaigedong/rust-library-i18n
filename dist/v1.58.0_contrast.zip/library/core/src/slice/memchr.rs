// Original implementation taken from rust-memchr. <br>原始实现来自 rust-memchr。<br>
// Copyright 2015 Andrew Gallant, bluss and Nicolas Koch <br>版权所有 2015 Andrew Gallant，bluss 和 Nicolas Koch<br>

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Use truncation. <br>使用截断。<br>
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Returns `true` if `x` contains any zero byte. <br>如果 `x` 包含任何零字节，则返回 `true`。<br>
///
/// From *Matters Computational*, J. <br>从 *Matters 计算*，J.<br> Arndt:
///
/// "The idea is to subtract one from each of the bytes and then look for bytes where the borrow propagated all the way to the most significant <br>` 这个想法是从每个字节中减去一个，然后寻找借用一直传播到最高有效位的字节。<br>
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Returns the first index matching the byte `x` in `text`. <br>返回与 `text` 中的字节 `x` 匹配的第一个索引。<br>
#[must_use]
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Fast path for small slices <br>小切片的快速路径<br>
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan for a single byte value by reading two `usize` words at a time. <br>通过一次读取两个 `usize` 字来扫描单个字节值。<br>
    //
    // Split `text` in three parts <br>将 `text` 分为三部分<br>
    // - unaligned initial part, before the first word aligned address in text <br>未对齐的初始部分，在文本中第一个单词对齐的地址之前<br>
    // - body, scan by 2 words at a time <br>身体，一次扫描 2 个字<br>
    // - the last remaining part, < 2 word size <br>最后剩下的部分，<2 字大小<br>

    // search up to an aligned boundary <br>搜索到对齐的边界<br>
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // search the body of the text <br>搜索正文<br>
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: the while's predicate guarantees a distance of at least 2 * usize_bytes between the offset and the end of the slice. <br>while 的谓词保证偏移量和切片末尾之间至少有 2 * usize_bytes 的距离。<br>
        //
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break if there is a matching byte <br>如果有匹配的字节则中断<br>
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Find the byte after the point the body loop stopped. <br>在主体循环停止的点之后找到字节。<br>
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Returns the last index matching the byte `x` in `text`. <br>返回与 `text` 中的字节 `x` 匹配的最后一个索引。<br>
#[must_use]
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan for a single byte value by reading two `usize` words at a time. <br>通过一次读取两个 `usize` 字来扫描单个字节值。<br>
    //
    // Split `text` in three parts: <br>将 `text` 分为三个部分：<br>
    // - unaligned tail, after the last word aligned address in text, <br>未对齐的尾部，在文本中最后一个单词对齐的地址之后，<br>
    // - body, scanned by 2 words at a time, <br>身体，一次扫描 2 个字，<br>
    // - the first remaining bytes, < 2 word size. <br>剩余的前一个字节，<2 个字长。<br>
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // We call this just to obtain the length of the prefix and suffix. <br>我们称其为仅仅是获得前缀和后缀的长度。<br>
        // In the middle we always process two chunks at once. <br>在中间，我们总是一次处理两个块。<br>
        // SAFETY: transmuting `[u8]` to `[usize]` is safe except for size differences which are handled by `align_to`. <br>将 `[u8]` 转换为 `[usize]` 是安全的，但 `align_to` 处理的大小差异除外。<br>
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Search the body of the text, make sure we don't cross min_aligned_offset. <br>搜索文本的正文，确保我们不跨越 min_aligned_offset。<br>
    // offset is always aligned, so just testing `>` is sufficient and avoids possible overflow. <br>偏移量总是对齐的，因此仅测试 `>` 就足够了，并避免了可能的溢出。<br>
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: offset starts at len - suffix.len(), as long as it is greater than min_aligned_offset (prefix.len()) the remaining distance is at least 2 * chunk_bytes. <br>偏移量从 len-suffix.len() 开始，只要大于 min_aligned_offset (prefix.len())，则剩余距离至少为 2 * chunk_bytes。<br>
        //
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Break if there is a matching byte. <br>如果有匹配的字节，则中断。<br>
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Find the byte before the point the body loop stopped. <br>在主体循环停止的点之前找到字节。<br>
    text[..offset].iter().rposition(|elt| *elt == x)
}
