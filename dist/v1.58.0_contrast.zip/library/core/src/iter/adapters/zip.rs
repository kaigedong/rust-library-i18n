use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// An iterator that iterates two other iterators simultaneously. <br>同时迭代其他两个迭代器的迭代器。<br>
///
/// This `struct` is created by [`zip`] or [`Iterator::zip`]. <br>这个 `struct` 是由 [`zip`] 或 [`Iterator::zip`] 创建的。<br>
/// See their documentation for more. <br>有关更多信息，请参见他们的文档。<br>
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len and a_len are only used by the specialized version of zip <br>index，len 和 a_len 仅由 zip 的专用版本使用<br>
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

/// Converts the arguments to iterators and zips them. <br>将参数转换为迭代器并压缩它们。<br>
///
/// See the documentation of [`Iterator::zip`] for more. <br>有关更多信息，请参见 [`Iterator::zip`] 的文档。<br>
///
/// # Examples
///
/// ```
/// #![feature(iter_zip)]
/// use std::iter::zip;
///
/// let xs = [1, 2, 3];
/// let ys = [4, 5, 6];
/// for (x, y) in zip(&xs, &ys) {
///     println!("x:{}, y:{}", x, y);
/// }
///
/// // Nested zips are also possible: <br>嵌套 zip 也可以：<br>
/// let zs = [7, 8, 9];
/// for ((x, y), z) in zip(zip(&xs, &ys), &zs) {
///     println!("x:{}, y:{}, z:{}", x, y, z);
/// }
/// ```
#[unstable(feature = "iter_zip", issue = "83574")]
pub fn zip<A, B>(a: A, b: B) -> Zip<A::IntoIter, B::IntoIter>
where
    A: IntoIterator,
    B: IntoIterator,
{
    ZipImpl::new(a.into_iter(), b.into_iter())
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccessNoCoerce,
    {
        // SAFETY: `ZipImpl::__iterator_get_unchecked` has same safety requirements as `Iterator::__iterator_get_unchecked`. <br>`ZipImpl::__iterator_get_unchecked` 与 `Iterator::__iterator_get_unchecked` 具有相同的安全要求。<br>
        //
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip specialization trait <br>Zip 专用 trait<br>
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // This has the same safety requirements as `Iterator::__iterator_get_unchecked` <br>与 `Iterator::__iterator_get_unchecked` 具有相同的安全要求<br>
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccessNoCoerce;
}

// Work around limitations of specialization, requiring `default` impls to be repeated in intermediary impls. <br>解决专业化的限制，要求在中间实现中重复 `default` 实现。<br>
//
macro_rules! zip_impl_general_defaults {
    () => {
        default fn new(a: A, b: B) -> Self {
            Zip {
                a,
                b,
                index: 0, // unused
                len: 0,   // unused
                a_len: 0, // unused
            }
        }

        #[inline]
        default fn next(&mut self) -> Option<(A::Item, B::Item)> {
            let x = self.a.next()?;
            let y = self.b.next()?;
            Some((x, y))
        }

        #[inline]
        default fn nth(&mut self, n: usize) -> Option<Self::Item> {
            self.super_nth(n)
        }

        #[inline]
        default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
        where
            A: DoubleEndedIterator + ExactSizeIterator,
            B: DoubleEndedIterator + ExactSizeIterator,
        {
            // The function body below only uses `self.a/b.len()` and `self.a/b.next_back()` and doesn’t call `next_back` too often, so this implementation is safe in the `TrustedRandomAccessNoCoerce` specialization <br>下面的函数体只使用 `self.a/b.len()` 和 `self.a/b.next_back()`，并不会经常调用 `next_back`，所以这个实现在 `TrustedRandomAccessNoCoerce` 专业化中是安全的<br>
            //
            //

            let a_sz = self.a.len();
            let b_sz = self.b.len();
            if a_sz != b_sz {
                // Adjust a, b to equal length <br>将 a，b 调整为相等的长度<br>
                if a_sz > b_sz {
                    for _ in 0..a_sz - b_sz {
                        self.a.next_back();
                    }
                } else {
                    for _ in 0..b_sz - a_sz {
                        self.b.next_back();
                    }
                }
            }
            match (self.a.next_back(), self.b.next_back()) {
                (Some(x), Some(y)) => Some((x, y)),
                (None, None) => None,
                _ => unreachable!(),
            }
        }
    };
}

// General Zip impl <br>通用 Zip 实现<br>
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    zip_impl_general_defaults! {}

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccessNoCoerce,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccessNoCoerce + Iterator,
    B: TrustedRandomAccessNoCoerce + Iterator,
{
    zip_impl_general_defaults! {}

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let size = cmp::min(self.a.size(), self.b.size());
        (size, Some(size))
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // SAFETY: the caller must uphold the contract for `Iterator::__iterator_get_unchecked`. <br>调用者必须遵守 `Iterator::__iterator_get_unchecked` 的契约。<br>
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            // since get_unchecked executes code which can panic we increment the counters beforehand so that the same index won't be accessed twice, as required by TrustedRandomAccess <br>由于 get_unchecked 执行可以 panic 的代码，因此我们事先增加了计数器，以便不会按照 TrustedRandomAccess 的要求访问相同的索引两次<br>
            //
            self.index += 1;
            // SAFETY: `i` is smaller than `self.len`, thus smaller than `self.a.len()` and `self.b.len()` <br>`i` 小于 `self.len`，因此小于 `self.a.len()` 和 `self.b.len()`<br>
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            // as above, increment before executing code that may panic <br>如上所述，在执行可能 panic 的代码之前递增<br>
            self.index += 1;
            self.len += 1;
            // match the base implementation's potential side effects <br>匹配基本实现的潜在副作用<br>
            // SAFETY: we just checked that `i` < `self.a.len()` <br>我们只是检查 `i` <`self.a.len()`<br>
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            // since get_unchecked executes code which can panic we increment the counters beforehand so that the same index won't be accessed twice, as required by TrustedRandomAccess <br>由于 get_unchecked 执行可以 panic 的代码，因此我们事先增加了计数器，以便不会按照 TrustedRandomAccess 的要求访问相同的索引两次<br>
            //
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // SAFETY: the usage of `cmp::min` to calculate `delta` ensures that `end` is smaller than or equal to `self.len`, so `i` is also smaller than `self.len`. <br>使用 `cmp::min` 计算 `delta` 可确保 `end` 小于或等于 `self.len`，因此 `i` 也小于 `self.len`。<br>
                //
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // SAFETY: same as above. <br>与上述相同。<br>
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // Adjust a, b to equal length, make sure that only the first call of `next_back` does this, otherwise we will break the restriction on calls to `self.next_back()` after calling `get_unchecked()`. <br>将 a，b 调整为相等的长度，确保只有 `next_back` 的第一个调用能够做到这一点，否则在调用 `get_unchecked()` 之后，我们将打破对 `self.next_back()` 的调用限制。<br>
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        // since next_back() may panic we increment the counters beforehand to keep Zip's state in sync with the underlying iterator source <br>由于 next_back() 可能 panic 我们预先增加计数器以保持 Zip 的状态与底层迭代器源同步<br>
                        //
                        self.a_len -= 1;
                        self.a.next_back();
                    }
                    debug_assert_eq!(self.a_len, self.len);
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            // since get_unchecked executes code which can panic we increment the counters beforehand so that the same index won't be accessed twice, as required by TrustedRandomAccess <br>由于 get_unchecked 执行可以 panic 的代码，因此我们事先增加了计数器，以便不会按照 TrustedRandomAccess 的要求访问相同的索引两次<br>
            //
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // SAFETY: `i` is smaller than the previous value of `self.len`, which is also smaller than or equal to `self.a.len()` and `self.b.len()` <br>`i` 小于 `self.len` 的前一个值，该值也小于或等于 `self.a.len()` 和 `self.b.len()`<br>
            //
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccessNoCoerce for Zip<A, B>
where
    A: TrustedRandomAccessNoCoerce,
    B: TrustedRandomAccessNoCoerce,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// Arbitrarily selects the left side of the zip iteration as extractable "source" it would require negative trait bounds to be able to try both <br>任意选择 zip 迭代的左侧作为可提取的 "source"，这将需要负 trait bounds 才能尝试<br>
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<A, B> SourceIter for Zip<A, B>
where
    A: SourceIter,
{
    type Source = A::Source;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut A::Source {
        // SAFETY: unsafe function forwarding to unsafe function with the same requirements <br>将不安全的函数转发到具有相同要求的不安全的函数<br>
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

// Since SourceIter forwards the left hand side we do the same here <br>由于 SourceIter 转发到了左侧，所以我们在这里也这样做<br>
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccessNoCoerce, B: Debug + TrustedRandomAccessNoCoerce> ZipFmt<A, B>
    for Zip<A, B>
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // It's *not safe* to call fmt on the contained iterators, since once we start iterating they're in strange, potentially unsafe, states. <br>在包含的迭代器上调用 fmt 是 *not 安全的*，因为一旦我们开始迭代，它们就处于奇怪的，可能不安全的状态。<br>
        //
        f.debug_struct("Zip").finish()
    }
}

/// An iterator whose items are random-accessible efficiently <br>一个迭代器，其项可以有效随机访问<br>
///
/// # Safety
///
/// The iterator's `size_hint` must be exact and cheap to call. <br>迭代器的 `size_hint` 必须精确且调用便宜。<br>
///
/// `TrustedRandomAccessNoCoerce::size` may not be overridden. <br>`TrustedRandomAccessNoCoerce::size` 不能被覆盖。<br>
///
/// All subtypes and all supertypes of `Self` must also implement `TrustedRandomAccess`. <br>`Self` 的所有子类型和所有超类型也必须实现 `TrustedRandomAccess`。<br>
/// In particular, this means that types with non-invariant parameters usually can not have an impl for `TrustedRandomAccess` that depends on any trait bounds on such parameters, except for bounds that come from the respective struct/enum definition itself, or bounds involving traits that themselves come with a guarantee similar to this one. <br>特别是，这意味着具有非不变参数的类型通常不能具有依赖于此类参数上的任何 trait bounds 的 `TrustedRandomAccess` 的 impl，除了来自相应 struct/enum 定义本身的边界，或涉及 traits 本身的边界与此类似的保证。<br>
///
///
/// If `Self: ExactSizeIterator` then `self.len()` must always produce results consistent with `self.size()`. <br>如果 `Self: ExactSizeIterator` 则 `self.len()` 必须始终产生与 `self.size()` 一致的结果。<br>
///
/// If `Self: Iterator`, then `<Self as Iterator>::__iterator_get_unchecked(&mut self, idx)` must be safe to call provided the following conditions are met. <br>如果是 `Self: Iterator`，那么只要满足以下条件，`<Self as Iterator>::__iterator_get_unchecked(&mut self, idx)` 就必须是安全的调用。<br>
///
/// 1. `0 <= idx` and `idx < self.size()`. <br>`0 <= idx` 和 `idx < self.size()`。<br>
/// 2. If `Self: !Clone`, then `self.__iterator_get_unchecked(idx)` is never called with the same index on `self` more than once. <br>如果是 `Self: !Clone`，则 `self.__iterator_get_unchecked(idx)` 永远不会在 `self` 上使用相同的索引多次调用。<br>
/// 3. After `self.__iterator_get_unchecked(idx)` has been called, then `self.next_back()` will only be called at most `self.size() - idx - 1` times. <br>`self.__iterator_get_unchecked(idx)` 被调用后，`self.next_back()` 最多只会被调用 `self.size() - idx - 1` 次。<br>
/// If `Self: Clone` and `self` is cloned, then this number is calculated for `self` and its clone individually, but `self.next_back()` calls that happened before the cloning count for both `self` and the clone. <br>如果克隆 `Self: Clone` 和 `self`，则分别为 `self` 及其克隆计算此数字，但 `self.next_back()` 调用发生在 `self` 和克隆的克隆计数之前。<br>
/// 4. After `self.__iterator_get_unchecked(idx)` has been called, then only the following methods will be called on `self` or on any new clones of `self`: <br>调用 `self.__iterator_get_unchecked(idx)` 后，将仅在 `self` 或 `self` 的任何新克隆上调用以下方法：<br>
///     * `std::clone::Clone::clone`
///     * `std::iter::Iterator::size_hint`
///     * `std::iter::DoubleEndedIterator::next_back`
///     * `std::iter::ExactSizeIterator::len`
///     * `std::iter::Iterator::__iterator_get_unchecked`
///     * `std::iter::TrustedRandomAccessNoCoerce::size`
/// 5. If `T` is a subtype of `Self`, then `self` is allowed to be coerced to `T`. <br>如果 `T` 是 `Self` 的子类型，则允许将 `self` 强制转换为 `T`。<br> If `self` is coerced to `T` after `self.__iterator_get_unchecked(idx)` has already been called, then no methods except for the ones listed under 4. <br>如果在 `self.__iterator_get_unchecked(idx)` 已经被调用之后 `self` 被强制为 `T`，那么除了 4.<br> are allowed to be called on the resulting value of type `T`, either. <br>也可以在 `T` 类型的结果值上调用。<br> Multiple such coercion steps are allowed. <br>允许多个这样的强制步骤。<br>
///    Regarding 2. <br>关于 2.<br> and 3., the number of times `__iterator_get_unchecked(idx)` or `next_back()` is called on `self` and the resulting value of type `T` (and on further coercion results with sub-subtypes) are added together and their sums must not exceed the specified bounds. <br>和 3.，在 `self` 上调用 `__iterator_get_unchecked(idx)` 或 `next_back()` 的次数和 `T` 类型的结果值 (以及子子类型的进一步强制结果) 相加，它们的总和不得超过指定的界限。<br>
///
/// Further, given that these conditions are met, it must guarantee that: <br>此外，考虑到这些条件，它必须保证：<br>
///
/// * It does not change the value returned from `size_hint` <br>它不会更改从 `size_hint` 返回的值<br>
/// * It must be safe to call the methods listed above on `self` after calling `self.__iterator_get_unchecked(idx)`, assuming that the required traits are implemented. <br>假设实现了所需的 traits，在调用 `self.__iterator_get_unchecked(idx)` 后，在 `self` 上调用上面列出的方法必须是安全的。<br>
/// * It must also be safe to drop `self` after calling `self.__iterator_get_unchecked(idx)`. <br>调用 `self.__iterator_get_unchecked(idx)` 后丢弃 `self` 也必须是安全的。<br>
/// * If `T` is a subtype of `Self`, then it must be safe to coerce `self` to `T`. <br>如果 `T` 是 `Self` 的子类型，那么将 `self` 强制转换为 `T` 必须是安全的。<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// FIXME: Clarify interaction with SourceIter/InPlaceIterable. <br>阐明与 SourceIter/InPlaceIterable 的交互。<br>
// Calling `SouceIter::as_inner` after `__iterator_get_unchecked` is supposed to be allowed. <br>应该允许在 `__iterator_get_unchecked` 之后调用 `SouceIter::as_inner`。<br>
//
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: TrustedRandomAccessNoCoerce {}

/// Like [`TrustedRandomAccess`] but without any of the requirements / guarantees around coercions to subtypes after `__iterator_get_unchecked` (they aren’t allowed here!), and without the requirement that subtypes / supertypes implement `TrustedRandomAccessNoCoerce`. <br>与 [`TrustedRandomAccess`] 类似，但没有任何要求 / 保证对 `__iterator_get_unchecked` 之后的子类型进行强制转换 (这里不允许！)，并且没有子类型 / 超类型实现 `TrustedRandomAccessNoCoerce` 的要求。<br>
///
///
/// This trait was created in PR #85874 to fix soundness issue #85873 without performance regressions. <br>这个 trait 是在 PR #85874 中创建的，以修复 issue #85873 的健全性而不会出现性能回归。<br>
/// It is subject to change as we might want to build a more generally useful (for performance optimizations) and more sophisticated trait or trait hierarchy that replaces or extends [`TrustedRandomAccess`] and `TrustedRandomAccessNoCoerce`. <br>它可能会发生变化，因为我们可能想要构建一个更普遍有用 (用于性能优化) 和更复杂的 trait 或 trait 层次结构来替换或扩展 [`TrustedRandomAccess`] 和 `TrustedRandomAccessNoCoerce`。<br>
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccessNoCoerce: Sized {
    // Convenience method. <br>方便的方法。<br>
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` if getting an iterator element may have side effects. <br>`true` 如果获取迭代器元素可能有副作用。<br>
    /// Remember to take inner iterators into account. <br>记住要考虑内部迭代器。<br>
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// Like `Iterator::__iterator_get_unchecked`, but doesn't require the compiler to know that `U: TrustedRandomAccess`. <br>类似于 `Iterator::__iterator_get_unchecked`，但不需要编译器知道 `U: TrustedRandomAccess`。<br>
///
///
/// ## Safety
///
/// Same requirements calling `get_unchecked` directly. <br>相同的要求直接调用 `get_unchecked`。<br>
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // SAFETY: the caller must uphold the contract for `Iterator::__iterator_get_unchecked`. <br>调用者必须遵守 `Iterator::__iterator_get_unchecked` 的契约。<br>
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// If `Self: TrustedRandomAccess`, it must be safe to call `Iterator::__iterator_get_unchecked(self, index)`. <br>如果是 `Self: TrustedRandomAccess`，调用 `Iterator::__iterator_get_unchecked(self, index)` 一定是安全的。<br>
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccessNoCoerce> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // SAFETY: the caller must uphold the contract for `Iterator::__iterator_get_unchecked`. <br>调用者必须遵守 `Iterator::__iterator_get_unchecked` 的契约。<br>
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}
