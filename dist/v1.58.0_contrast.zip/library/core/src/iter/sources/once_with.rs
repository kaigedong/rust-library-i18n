use crate::iter::{FusedIterator, TrustedLen};

/// Creates an iterator that lazily generates a value exactly once by invoking the provided closure. <br>创建一个迭代器，该迭代器通过调用提供的闭包来懒惰地一次生成一个值。<br>
///
/// This is commonly used to adapt a single value generator into a [`chain()`] of other kinds of iteration. <br>这通常用于使单个值生成器适应其他类型的迭代的 [`chain()`]。<br>
/// Maybe you have an iterator that covers almost everything, but you need an extra special case. <br>也许您有一个涵盖几乎所有内容的迭代器，但是您需要一个额外的特殊情况。<br>
/// Maybe you have a function which works on iterators, but you only need to process one value. <br>也许您有一个可在迭代器上使用的函数，但只需要处理一个值即可。<br>
///
/// Unlike [`once()`], this function will lazily generate the value on request. <br>与 [`once()`] 不同，此函数将根据要求延迟生成值。<br>
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::iter;
///
/// // one is the loneliest number <br>一个是最孤独的数字<br>
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // just one, that's all we get <br>只是一个，这就是我们得到的<br>
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining together with another iterator. <br>与另一个迭代器链接在一起。<br>
/// Let's say that we want to iterate over each file of the `.foo` directory, but also a configuration file, <br>假设我们要遍历 `.foo` 目录的每个文件，还要遍历一个配置文件，<br>
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // we need to convert from an iterator of DirEntry-s to an iterator of PathBufs, so we use map <br>我们需要将 DirEntry-s 的迭代器转换为 PathBufs 的迭代器，因此我们使用 map<br>
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // now, our iterator just for our config file <br>现在，我们的迭代器仅用于我们的配置文件<br>
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // chain the two iterators together into one big iterator <br>将两个迭代器链接到一个大迭代器中<br>
/// let files = dirs.chain(config);
///
/// // this will give us all of the files in .foo as well as .foorc <br>这将为我们提供 .foo 和 .foorc 中的所有文件<br>
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator that yields a single element of type `A` by applying the provided closure `F: FnOnce() -> A`. <br>通过应用提供的闭包 `F: FnOnce() -> A` 产生类型为 `A` 的单个元素的迭代器。<br>
///
///
/// This `struct` is created by the [`once_with()`] function. <br>该 `struct` 由 [`once_with()`] 函数创建。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}
