//! Character conversions. <br>字符转换。<br>

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Converts a `u32` to a `char`. <br>将 `u32` 转换为 `char`。<br>
///
/// Note that all [`char`]s are valid [`u32`]s, and can be cast to one with <br>请注意，所有 [`char`] 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为一个<br>
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// However, the reverse is not true: not all valid [`u32`]s are valid [`char`]s. <br>但是，事实并非如此：并非所有有效的 [u32] 都是有效的 [char]。<br>
/// `from_u32()` will return `None` if the input is not a valid value for a [`char`]. <br>如果输入不是 [`char`] 的有效值，`from_u32()` 将返回 `None`。<br>
///
/// For an unsafe version of this function which ignores these checks, see [`from_u32_unchecked`]. <br>有关忽略这些检查的该函数的不安全版本，请参见 [`from_u32_unchecked`]。<br>
///
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Returning `None` when the input is not a valid [`char`]: <br>当输入不是有效的 [`char`] 时返回 `None`：<br>
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[must_use]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
pub const fn from_u32(i: u32) -> Option<char> {
    // FIXME: once Result::ok is const fn, use it here <br>一旦 Result::ok 是 const fn，就在这里使用它<br>
    match char_try_from_u32(i) {
        Ok(c) => Some(c),
        Err(_) => None,
    }
}

/// Converts a `u32` to a `char`, ignoring validity. <br>将 `u32` 转换为 `char`，而忽略有效性。<br>
///
/// Note that all [`char`]s are valid [`u32`]s, and can be cast to one with <br>请注意，所有 [`char`] 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为一个<br>
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// However, the reverse is not true: not all valid [`u32`]s are valid [`char`]s. <br>但是，事实并非如此：并非所有有效的 [u32] 都是有效的 [char]。<br>
/// `from_u32_unchecked()` will ignore this, and blindly cast to [`char`], possibly creating an invalid one. <br>`from_u32_unchecked()` 将忽略这一点，并盲目地转换为 [`char`]，可能会创建一个无效的。<br>
///
///
/// # Safety
///
/// This function is unsafe, as it may construct invalid `char` values. <br>该函数是不安全的，因为它可能创建无效的 `char` 值。<br>
///
/// For a safe version of this function, see the [`from_u32`] function. <br>有关此函数的安全版本，请参见 [`from_u32`] 函数。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[must_use]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
#[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
pub const unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: the caller must guarantee that `i` is a valid char value. <br>调用者必须保证 `i` 是有效的 char 值。<br>
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u32 {
    /// Converts a [`char`] into a [`u32`]. <br>将 [`char`] 转换为 [`u32`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u64 {
    /// Converts a [`char`] into a [`u64`]. <br>将 [`char`] 转换为 [`u64`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The char is casted to the value of the code point, then zero-extended to 64 bit. <br>字符强制转换为代码点的值，然后零扩展为 64 位。<br>
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] <br>请参见 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]<br>
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<char> for u128 {
    /// Converts a [`char`] into a [`u128`]. <br>将 [`char`] 转换为 [`u128`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // The char is casted to the value of the code point, then zero-extended to 128 bit. <br>字符强制转换为代码点的值，然后零扩展为 128 位。<br>
        // See [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] <br>请参见 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]<br>
        c as u128
    }
}

/// Maps a byte in 0x00..=0xFF to a `char` whose code point has the same value, in U+0000..=U+00FF. <br>将 0x00..=0xFF 中的字节映射到 `char`，该 `char` 的代码点具有相同的值，即 U+0000..=U+00FF。<br>
///
/// Unicode is designed such that this effectively decodes bytes with the character encoding that IANA calls ISO-8859-1. <br>Unicode 的设计使其可以使用 IANA 称为 ISO-8859-1 的字符编码有效地解码字节。<br>
/// This encoding is compatible with ASCII. <br>此编码与 ASCII 兼容。<br>
///
/// Note that this is different from ISO/IEC 8859-1 a.k.a. <br>请注意，这与 ISO/IEC 8859-1 又名不同<br>
/// ISO 8859-1 (with one less hyphen), which leaves some "blanks", byte values that are not assigned to any character. <br>ISO 8859-1 (连字符少一个)，它留下了一些 "blanks" 字节值，这些值未分配给任何字符。<br>
/// ISO-8859-1 (the IANA one) assigns them to the C0 and C1 control codes. <br>ISO-8859-1 (属于 IANA) 将它们分配给 C0 和 C1 控制代码。<br>
///
/// Note that this is *also* different from Windows-1252 a.k.a. <br>请注意，这也与 Windows-1252 也不同<br>
/// code page 1252, which is a superset ISO/IEC 8859-1 that assigns some (not all!) blanks to punctuation and various Latin characters. <br>代码页 1252，它是 ISO/IEC 8859-1 的超集，它为标点符号和各种拉丁字符分配了一些 (不是全部) 空格。<br>
///
/// To confuse things further, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, and `windows-1252` are all aliases for a superset of Windows-1252 that fills the remaining blanks with corresponding C0 and C1 control codes. <br>为了进一步混淆，[在 Web 上](https://encoding.spec.whatwg.org/) `ascii`，`iso-8859-1` 和 `windows-1252` 都是 Windows-1252 超集的别名，该超集用相应的 C0 和 C1 控制代码填充了其余的空白。<br>
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<u8> for char {
    /// Converts a [`u8`] into a [`char`]. <br>将 [`u8`] 转换为 [`char`]。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// An error which can be returned when parsing a char. <br>解析 char 时可以返回的错误。<br>
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[inline]
const fn char_try_from_u32(i: u32) -> Result<char, CharTryFromError> {
    if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
        Err(CharTryFromError(()))
    } else {
        // SAFETY: checked that it's a legal unicode value <br>检查这是合法的 unicode 值<br>
        Ok(unsafe { transmute(i) })
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        char_try_from_u32(i)
    }
}

/// The error type returned when a conversion from u32 to char fails. <br>从 u32 转换为 char 失败时返回的错误类型。<br>
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Converts a digit in the given radix to a `char`. <br>将给定基数中的数字转换为 `char`。<br>
///
/// A 'radix' here is sometimes also called a 'base'. <br>这里的 'radix' 有时也称为 'base'。<br>
/// A radix of two indicates a binary number, a radix of ten, decimal, and a radix of sixteen, hexadecimal, to give some common values. <br>基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。<br>
///
/// Arbitrary radices are supported. <br>支持任意基数。<br>
///
/// `from_digit()` will return `None` if the input is not a digit in the given radix. <br>如果输入不是给定基数中的数字，`from_digit()` 将返回 `None`。<br>
///
/// # Panics
///
/// Panics if given a radix larger than 36. <br>如果给定的基数大于 36，就会出现 panics。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 is a single digit in base 16 <br>十进制 11 是以 16 为底的一位数字<br>
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Returning `None` when the input is not a digit: <br>当输入不是数字时返回 `None`：<br>
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passing a large radix, causing a panic: <br>传递较大的基数，导致 panic：<br>
///
/// ```should_panic
/// use std::char;
///
/// // this panics <br>这个 panics<br>
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_char_convert", issue = "89259")]
pub const fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}
