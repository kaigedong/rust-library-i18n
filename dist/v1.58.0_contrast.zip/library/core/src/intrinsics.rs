//! Compiler intrinsics. <br>编译器内部函数。<br>
//!
//! The corresponding definitions are in `compiler/rustc_codegen_llvm/src/intrinsic.rs`. <br>相应的定义在 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 中。<br>
//! The corresponding const implementations are in `compiler/rustc_mir/src/interpret/intrinsics.rs` <br>相应的 const 实现在 `compiler/rustc_mir/src/interpret/intrinsics.rs` 中<br>
//!
//! # Const intrinsics <br>常量内部函数<br>
//!
//! Note: any changes to the constness of intrinsics should be discussed with the language team. <br>对内部函数常量的任何更改都应与语言团队讨论。<br>
//! This includes changes in the stability of the constness. <br>这包括常量稳定性的变化。<br>
//!
//! In order to make an intrinsic usable at compile-time, one needs to copy the implementation from <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> to `compiler/rustc_mir/src/interpret/intrinsics.rs` and add a `#[rustc_const_unstable(feature = "foo", issue = "01234")]` to the intrinsic. <br>为了使内部函数在编译时可用，需要将实现从 <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> 复制到 `compiler/rustc_mir/src/interpret/intrinsics.rs` 并将 `#[rustc_const_unstable(feature = "foo", issue = "01234")]` 添加到内部函数。<br>
//!
//!
//! If an intrinsic is supposed to be used from a `const fn` with a `rustc_const_stable` attribute, the intrinsic's attribute must be `rustc_const_stable`, too. <br>如果应该从具有 `rustc_const_stable` 属性的 `const fn` 使用内部函数，则内部函数的属性也必须为 `rustc_const_stable`。<br>
//! Such a change should not be done without T-lang consultation, because it bakes a feature into the language that cannot be replicated in user code without compiler support. <br>如果没有 T-lang 协商会，就不应该进行此类更改，因为它把一个特性融入到语言中，如果没有编译器支持，就不能在用户代码中复制。<br>
//!
//! # Volatiles
//!
//! The volatile intrinsics provide operations intended to act on I/O memory, which are guaranteed to not be reordered by the compiler across other volatile intrinsics. <br>volatile 内部函数提供旨在作用于 I/O 内存的操作，并保证编译器不会在其他 volatile 内部函数之间对它们进行重新排序。<br> See the LLVM documentation on [[volatile]]. <br>请参见 [[volatile]] 上的 LLVM 文档。<br>
//!
//! [volatile]: https://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! The atomic intrinsics provide common atomic operations on machine words, with multiple possible memory orderings. <br>原子内部函数对机器字提供常见的原子操作，并具有多种可能的存储顺序。<br> They obey the same semantics as C++11. <br>它们遵循与 C++ 11 相同的语义。<br> See the LLVM documentation on [[atomics]]. <br>请参见 [[atomics]] 上的 LLVM 文档。<br>
//!
//! [atomics]: https://llvm.org/docs/Atomics.html
//!
//! A quick refresher on memory ordering: <br>关于内存排序的快速回顾：<br>
//!
//! * Acquire - a barrier for acquiring a lock. <br>获取 - 获取锁的障碍。<br> Subsequent reads and writes take place after the barrier. <br>屏障之后将进行后续的读取和写入。<br>
//! * Release - a barrier for releasing a lock. <br>释放 - 释放锁的障碍物。<br> Preceding reads and writes take place before the barrier. <br>之前的读取和写入发生在该屏障之前。<br>
//! * Sequentially consistent - sequentially consistent operations are guaranteed to happen in order. <br>顺序一致 - 顺序一致的操作可保证按顺序进行。<br> This is the standard mode for working with atomic types and is equivalent to Java's `volatile`. <br>这是处理原子类型的标准模式，等效于 Java 的 `volatile`。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// These imports are used for simplifying intra-doc links <br>这些导入用于简化文档内链接<br>
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETY: see `ptr::drop_in_place` <br>请参见 `ptr::drop_in_place`<br>
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // N.B., these intrinsics take raw pointers because they mutate aliased memory, which is not valid for either `&` or `&mut`. <br>注意，这些内部函数采用裸指针，因为它们会使别名内存发生可变的，这对于 `&` 或 `&mut` 均无效。<br>
    //

    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::SeqCst`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::Acquire`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::Acquire`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::Release`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::Release`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::AcqRel`] as the `success` and [`Ordering::Acquire`] as the `failure` parameters. <br>通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::Relaxed`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::SeqCst`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::SeqCst`] as the `success` and [`Ordering::Acquire`] as the `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::Acquire`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::Acquire`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange` method by passing [`Ordering::AcqRel`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange`]. <br>例如，[`AtomicBool::compare_exchange`]。<br>
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::SeqCst`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::Acquire`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::Acquire`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::Release`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::Release`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::AcqRel`] as the `success` and [`Ordering::Acquire`] as the `failure` parameters. <br>通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::Relaxed`] as both the `success` and `failure` parameters. <br>通过将 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    ///
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::SeqCst`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::SeqCst`] as the `success` and [`Ordering::Acquire`] as the `failure` parameters. <br>通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::Acquire`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::Acquire`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stores a value if the current value is the same as the `old` value. <br>如果当前值与 `old` 值相同，则存储一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `compare_exchange_weak` method by passing [`Ordering::AcqRel`] as the `success` and [`Ordering::Relaxed`] as the `failure` parameters. <br>通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::compare_exchange_weak`]. <br>例如，[`AtomicBool::compare_exchange_weak`]。<br>
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Loads the current value of the pointer. <br>加载指针的当前值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `load` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::load`]. <br>例如，[`AtomicBool::load`]。<br>
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Loads the current value of the pointer. <br>加载指针的当前值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `load` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::load`]. <br>例如，[`AtomicBool::load`]。<br>
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Loads the current value of the pointer. <br>加载指针的当前值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `load` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::load`]. <br>例如，[`AtomicBool::load`]。<br>
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stores the value at the specified memory location. <br>将值存储在指定的存储位置。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `store` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::store`]. <br>例如，[`AtomicBool::store`]。<br>
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stores the value at the specified memory location. <br>将值存储在指定的存储位置。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `store` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::store`]. <br>例如，[`AtomicBool::store`]。<br>
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stores the value at the specified memory location. <br>将值存储在指定的存储位置。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `store` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::store`]. <br>例如，[`AtomicBool::store`]。<br>
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stores the value at the specified memory location, returning the old value. <br>将值存储在指定的内存位置，并返回旧值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `swap` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::swap`]. <br>例如，[`AtomicBool::swap`]。<br>
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores the value at the specified memory location, returning the old value. <br>将值存储在指定的内存位置，并返回旧值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `swap` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::swap`]. <br>例如，[`AtomicBool::swap`]。<br>
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores the value at the specified memory location, returning the old value. <br>将值存储在指定的内存位置，并返回旧值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `swap` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::swap`]. <br>例如，[`AtomicBool::swap`]。<br>
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores the value at the specified memory location, returning the old value. <br>将值存储在指定的内存位置，并返回旧值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `swap` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::swap`]. <br>例如，[`AtomicBool::swap`]。<br>
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stores the value at the specified memory location, returning the old value. <br>将值存储在指定的内存位置，并返回旧值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `swap` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::swap`]. <br>例如，[`AtomicBool::swap`]。<br>
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Adds to the current value, returning the previous value. <br>加到当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_add` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_add`]. <br>例如，[`AtomicIsize::fetch_add`]。<br>
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adds to the current value, returning the previous value. <br>加到当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_add` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_add`]. <br>例如，[`AtomicIsize::fetch_add`]。<br>
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adds to the current value, returning the previous value. <br>加到当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_add` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_add`]. <br>例如，[`AtomicIsize::fetch_add`]。<br>
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adds to the current value, returning the previous value. <br>加到当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_add` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_add`]. <br>例如，[`AtomicIsize::fetch_add`]。<br>
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Adds to the current value, returning the previous value. <br>加到当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_add` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_add`]. <br>例如，[`AtomicIsize::fetch_add`]。<br>
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Subtract from the current value, returning the previous value. <br>从当前值减去，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_sub` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_sub`]. <br>例如，[`AtomicIsize::fetch_sub`]。<br>
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtract from the current value, returning the previous value. <br>从当前值减去，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_sub` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_sub`]. <br>例如，[`AtomicIsize::fetch_sub`]。<br>
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtract from the current value, returning the previous value. <br>从当前值减去，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_sub` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_sub`]. <br>例如，[`AtomicIsize::fetch_sub`]。<br>
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtract from the current value, returning the previous value. <br>从当前值减去，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_sub` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_sub`]. <br>例如，[`AtomicIsize::fetch_sub`]。<br>
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtract from the current value, returning the previous value. <br>从当前值减去，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_sub` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicIsize::fetch_sub`]. <br>例如，[`AtomicIsize::fetch_sub`]。<br>
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise and with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_and` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_and`]. <br>例如，[`AtomicBool::fetch_and`]。<br>
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise and with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_and` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_and`]. <br>例如，[`AtomicBool::fetch_and`]。<br>
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise and with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_and` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_and`]. <br>例如，[`AtomicBool::fetch_and`]。<br>
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise and with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_and` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_and`]. <br>例如，[`AtomicBool::fetch_and`]。<br>
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise and with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_and` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_and`]. <br>例如，[`AtomicBool::fetch_and`]。<br>
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`AtomicBool`] type via the `fetch_nand` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_nand`]. <br>例如，[`AtomicBool::fetch_nand`]。<br>
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`AtomicBool`] type via the `fetch_nand` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_nand`]. <br>例如，[`AtomicBool::fetch_nand`]。<br>
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`AtomicBool`] type via the `fetch_nand` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_nand`]. <br>例如，[`AtomicBool::fetch_nand`]。<br>
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`AtomicBool`] type via the `fetch_nand` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_nand`]. <br>例如，[`AtomicBool::fetch_nand`]。<br>
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand with the current value, returning the previous value. <br>对当前值按位与，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`AtomicBool`] type via the `fetch_nand` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_nand`]. <br>例如，[`AtomicBool::fetch_nand`]。<br>
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise or with the current value, returning the previous value. <br>按位或具有当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_or` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_or`]. <br>例如，[`AtomicBool::fetch_or`]。<br>
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise or with the current value, returning the previous value. <br>按位或具有当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_or` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_or`]. <br>例如，[`AtomicBool::fetch_or`]。<br>
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise or with the current value, returning the previous value. <br>按位或具有当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_or` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_or`]. <br>例如，[`AtomicBool::fetch_or`]。<br>
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise or with the current value, returning the previous value. <br>按位或具有当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_or` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_or`]. <br>例如，[`AtomicBool::fetch_or`]。<br>
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise or with the current value, returning the previous value. <br>按位或具有当前值，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_or` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_or`]. <br>例如，[`AtomicBool::fetch_or`]。<br>
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor with the current value, returning the previous value. <br>与当前值按位异或，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_xor` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_xor`]. <br>例如，[`AtomicBool::fetch_xor`]。<br>
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor with the current value, returning the previous value. <br>与当前值按位异或，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_xor` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_xor`]. <br>例如，[`AtomicBool::fetch_xor`]。<br>
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor with the current value, returning the previous value. <br>与当前值按位异或，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_xor` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_xor`]. <br>例如，[`AtomicBool::fetch_xor`]。<br>
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor with the current value, returning the previous value. <br>与当前值按位异或，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_xor` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_xor`]. <br>例如，[`AtomicBool::fetch_xor`]。<br>
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor with the current value, returning the previous value. <br>与当前值按位异或，返回前一个值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] types via the `fetch_xor` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicBool::fetch_xor`]. <br>例如，[`AtomicBool::fetch_xor`]。<br>
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_max` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_max`]. <br>例如，[`AtomicI32::fetch_max`]。<br>
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_max` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_max`]. <br>例如，[`AtomicI32::fetch_max`]。<br>
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_max` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_max`]. <br>例如，[`AtomicI32::fetch_max`]。<br>
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_max` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_max`]. <br>例如，[`AtomicI32::fetch_max`]。<br>
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value. <br>当前值的最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_max` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_max`]. <br>例如，[`AtomicI32::fetch_max`]。<br>
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_min` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_min`]. <br>例如，[`AtomicI32::fetch_min`]。<br>
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_min` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_min`]. <br>例如，[`AtomicI32::fetch_min`]。<br>
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_min` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_min`]. <br>例如，[`AtomicI32::fetch_min`]。<br>
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_min` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_min`]. <br>例如，[`AtomicI32::fetch_min`]。<br>
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using a signed comparison. <br>使用带符号的比较将当前值设为最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] signed integer types via the `fetch_min` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicI32::fetch_min`]. <br>例如，[`AtomicI32::fetch_min`]。<br>
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum with the current value using an unsigned comparison. <br>使用无符号比较，使用当前值的最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_min` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_min`]. <br>例如，[`AtomicU32::fetch_min`]。<br>
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using an unsigned comparison. <br>使用无符号比较，使用当前值的最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_min` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_min`]. <br>例如，[`AtomicU32::fetch_min`]。<br>
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using an unsigned comparison. <br>使用无符号比较，使用当前值的最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_min` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_min`]. <br>例如，[`AtomicU32::fetch_min`]。<br>
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using an unsigned comparison. <br>使用无符号比较，使用当前值的最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_min` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_min`]. <br>例如，[`AtomicU32::fetch_min`]。<br>
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum with the current value using an unsigned comparison. <br>使用无符号比较，使用当前值的最小值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_min` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_min`]. <br>例如，[`AtomicU32::fetch_min`]。<br>
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum with the current value using an unsigned comparison. <br>使用无符号比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_max` method by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_max`]. <br>例如，[`AtomicU32::fetch_max`]。<br>
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using an unsigned comparison. <br>使用无符号比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_max` method by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_max`]. <br>例如，[`AtomicU32::fetch_max`]。<br>
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using an unsigned comparison. <br>使用无符号比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_max` method by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_max`]. <br>例如，[`AtomicU32::fetch_max`]。<br>
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using an unsigned comparison. <br>使用无符号比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_max` method by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_max`]. <br>例如，[`AtomicU32::fetch_max`]。<br>
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum with the current value using an unsigned comparison. <br>使用无符号比较将当前值设为最大值。<br>
    ///
    /// The stabilized version of this intrinsic is available on the [`atomic`] unsigned integer types via the `fetch_max` method by passing [`Ordering::Relaxed`] as the `order`. <br>通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。<br>
    /// For example, [`AtomicU32::fetch_max`]. <br>例如，[`AtomicU32::fetch_max`]。<br>
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// The `prefetch` intrinsic is a hint to the code generator to insert a prefetch instruction if supported; <br>`prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。<br> otherwise, it is a no-op. <br>否则，它是无操作的。<br>
    /// Prefetches have no effect on the behavior of the program but can change its performance characteristics. <br>预取对程序的行为没有影响，但可以更改其性能特征。<br>
    ///
    /// The `locality` argument must be a constant integer and is a temporal locality specifier ranging from (0) - no locality, to (3) - extremely local keep in cache. <br>`locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic is a hint to the code generator to insert a prefetch instruction if supported; <br>`prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。<br> otherwise, it is a no-op. <br>否则，它是无操作的。<br>
    /// Prefetches have no effect on the behavior of the program but can change its performance characteristics. <br>预取对程序的行为没有影响，但可以更改其性能特征。<br>
    ///
    /// The `locality` argument must be a constant integer and is a temporal locality specifier ranging from (0) - no locality, to (3) - extremely local keep in cache. <br>`locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic is a hint to the code generator to insert a prefetch instruction if supported; <br>`prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。<br> otherwise, it is a no-op. <br>否则，它是无操作的。<br>
    /// Prefetches have no effect on the behavior of the program but can change its performance characteristics. <br>预取对程序的行为没有影响，但可以更改其性能特征。<br>
    ///
    /// The `locality` argument must be a constant integer and is a temporal locality specifier ranging from (0) - no locality, to (3) - extremely local keep in cache. <br>`locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic is a hint to the code generator to insert a prefetch instruction if supported; <br>`prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。<br> otherwise, it is a no-op. <br>否则，它是无操作的。<br>
    /// Prefetches have no effect on the behavior of the program but can change its performance characteristics. <br>预取对程序的行为没有影响，但可以更改其性能特征。<br>
    ///
    /// The `locality` argument must be a constant integer and is a temporal locality specifier ranging from (0) - no locality, to (3) - extremely local keep in cache. <br>`locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// An atomic fence. <br>原子栅栏。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::fence`] by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    pub fn atomic_fence();
    /// An atomic fence. <br>原子栅栏。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::fence`] by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    pub fn atomic_fence_acq();
    /// An atomic fence. <br>原子栅栏。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::fence`] by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    pub fn atomic_fence_rel();
    /// An atomic fence. <br>原子栅栏。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::fence`] by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A compiler-only memory barrier. <br>仅编译器的内存屏障。<br>
    ///
    /// Memory accesses will never be reordered across this barrier by the compiler, but no instructions will be emitted for it. <br>编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。<br>
    /// This is appropriate for operations on the same thread that may be preempted, such as when interacting with signal handlers. <br>这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::compiler_fence`] by passing [`Ordering::SeqCst`] as the `order`. <br>通过将 [`Ordering::SeqCst`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A compiler-only memory barrier. <br>仅编译器的内存屏障。<br>
    ///
    /// Memory accesses will never be reordered across this barrier by the compiler, but no instructions will be emitted for it. <br>编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。<br>
    /// This is appropriate for operations on the same thread that may be preempted, such as when interacting with signal handlers. <br>这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::compiler_fence`] by passing [`Ordering::Acquire`] as the `order`. <br>通过将 [`Ordering::Acquire`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A compiler-only memory barrier. <br>仅编译器的内存屏障。<br>
    ///
    /// Memory accesses will never be reordered across this barrier by the compiler, but no instructions will be emitted for it. <br>编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。<br>
    /// This is appropriate for operations on the same thread that may be preempted, such as when interacting with signal handlers. <br>这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::compiler_fence`] by passing [`Ordering::Release`] as the `order`. <br>通过将 [`Ordering::Release`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A compiler-only memory barrier. <br>仅编译器的内存屏障。<br>
    ///
    /// Memory accesses will never be reordered across this barrier by the compiler, but no instructions will be emitted for it. <br>编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。<br>
    /// This is appropriate for operations on the same thread that may be preempted, such as when interacting with signal handlers. <br>这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。<br>
    ///
    /// The stabilized version of this intrinsic is available in [`atomic::compiler_fence`] by passing [`Ordering::AcqRel`] as the `order`. <br>通过将 [`Ordering::AcqRel`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。<br>
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic intrinsic that derives its meaning from attributes attached to the function. <br>从函数附带的属性中获取其含义的 magic 内部函数。<br>
    ///
    /// For example, dataflow uses this to inject static assertions so that `rustc_peek(potentially_uninitialized)` would actually double-check that dataflow did indeed compute that it is uninitialized at that point in the control flow. <br>例如，数据流使用它来注入静态断言，以便 `rustc_peek(potentially_uninitialized)` 实际上会再次检查数据流确实确实计算出该数据流在控制流中未初始化。<br>
    ///
    ///
    /// This intrinsic should not be used outside of the compiler. <br>不应在编译器外部使用此内部函数。<br>
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts the execution of the process. <br>中止进程的执行。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// [`std::process::abort`](../../std/process/fn.abort.html) is to be preferred if possible, as its behavior is more user-friendly and more stable. <br>如果可能，[`std::process::abort`](../../std/process/fn.abort.html) 如果可能的话是首选的，因为它的行为更方便用户，也更稳定。<br>
    ///
    ///
    /// The current implementation of `intrinsics::abort` is to invoke an invalid instruction, on most platforms. <br>`intrinsics::abort` 的当前实现是在大多数平台上调用无效指令。<br>
    /// On Unix, the process will probably terminate with a signal like `SIGABRT`, `SIGILL`, `SIGTRAP`, `SIGSEGV` or `SIGBUS`. <br>在 Unix 上，进程可能会以 `SIGABRT`、`SIGILL`、`SIGTRAP`、`SIGSEGV` 或 `SIGBUS` 之类的信号终止。<br>
    /// The precise behaviour is not guaranteed and not stable. <br>不能保证精确的行为并且不稳定。<br>
    ///
    ///
    ///
    pub fn abort() -> !;

    /// Informs the optimizer that this point in the code is not reachable, enabling further optimizations. <br>通知优化器代码中的这一点不可访问，从而可以进行进一步的优化。<br>
    ///
    /// N.B., this is very different from the `unreachable!()` macro: Unlike the macro, which panics when it is executed, it is *undefined behavior* to reach code marked with this function. <br>注意，这与 `unreachable!()` 宏非常不同：与执行 panics 的宏不同，到达带有此函数标记的代码是 *undefined 行为*。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`core::hint::unreachable_unchecked`]. <br>这个 intrinsic 的稳定版本是 [`core::hint::unreachable_unchecked`]。<br>
    ///
    ///
    #[rustc_const_stable(feature = "const_unreachable_unchecked", since = "1.57.0")]
    pub fn unreachable() -> !;

    /// Informs the optimizer that a condition is always true. <br>通知优化器某个条件始终为 true。<br>
    /// If the condition is false, the behavior is undefined. <br>如果条件为 false，则行为未定义的。<br>
    ///
    /// No code is generated for this intrinsic, but the optimizer will try to preserve it (and its condition) between passes, which may interfere with optimization of surrounding code and reduce performance. <br>没有为该内部函数生成任何代码，但是优化器将尝试在通过之间保留它 (及其条件)，这可能会干扰周围代码的优化并降低性能。<br>
    /// It should not be used if the invariant can be discovered by the optimizer on its own, or if it does not enable any significant optimizations. <br>如果优化器可以自己发现不变量，或者它没有启用任何重要的优化，则不应使用它。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Hints to the compiler that branch condition is likely to be true. <br>提示编译器分支条件很可能是正确的。<br>
    /// Returns the value passed to it. <br>返回传递给它的值。<br>
    ///
    /// Any use other than with `if` statements will probably not have an effect. <br>除与 `if` 语句一起使用外，其他任何使用都可能无效。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hints to the compiler that branch condition is likely to be false. <br>提示编译器分支条件可能为 false。<br>
    /// Returns the value passed to it. <br>返回传递给它的值。<br>
    ///
    /// Any use other than with `if` statements will probably not have an effect. <br>除与 `if` 语句一起使用外，其他任何使用都可能无效。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executes a breakpoint trap, for inspection by a debugger. <br>执行一个断点陷阱，以供调试器检查。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn breakpoint();

    /// The size of a type in bytes. <br>类型的大小 (以字节为单位)。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// More specifically, this is the offset in bytes between successive items of the same type, including alignment padding. <br>更具体地说，这是相同类型的连续项之间的字节偏移量，包括对齐填充。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`core::mem::size_of`]. <br>这个 intrinsic 的稳定版本是 [`core::mem::size_of`]。<br>
    ///
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// The minimum alignment of a type. <br>类型的最小对齐方式。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`core::mem::align_of`]. <br>这个 intrinsic 的稳定版本是 [`core::mem::align_of`]。<br>
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// The preferred alignment of a type. <br>类型的首选对齐方式。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// The size of the referenced value in bytes. <br>引用值的大小 (以字节为单位)。<br>
    ///
    /// The stabilized version of this intrinsic is [`mem::size_of_val`]. <br>此内部函数的稳定版本为 [`mem::size_of_val`]。<br>
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// The required alignment of the referenced value. <br>参考值的所需对齐方式。<br>
    ///
    /// The stabilized version of this intrinsic is [`core::mem::align_of_val`]. <br>这个 intrinsic 的稳定版本是 [`core::mem::align_of_val`]。<br>
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Gets a static string slice containing the name of a type. <br>获取包含类型名称的静态字符串切片。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`core::any::type_name`]. <br>这个 intrinsic 的稳定版本是 [`core::any::type_name`]。<br>
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Gets an identifier which is globally unique to the specified type. <br>获取一个标识符，该标识符对于指定的类型是全局唯一的。<br>
    /// This function will return the same value for a type regardless of whichever crate it is invoked in. <br>无论调用哪个 crate，此函数都将为类型返回相同的值。<br>
    ///
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized version of this intrinsic is [`core::any::TypeId::of`]. <br>这个 intrinsic 的稳定版本是 [`core::any::TypeId::of`]。<br>
    ///
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A guard for unsafe functions that cannot ever be executed if `T` is uninhabited: <br>如果 `T` 未定义，则无法执行的不安全函数的守卫：<br>
    /// This will statically either panic, or do nothing. <br>这将静态地为 panic，或者什么也不做。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A guard for unsafe functions that cannot ever be executed if `T` does not permit zero-initialization: This will statically either panic, or do nothing. <br>如果 `T` 不允许零初始化，则永远不能执行的不安全函数的守卫：这将静态 panic，或者什么也不做。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn assert_zero_valid<T>();

    /// A guard for unsafe functions that cannot ever be executed if `T` has invalid bit patterns: This will statically either panic, or do nothing. <br>如果 `T` 具有无效的位模式，则永远不能执行的不安全函数的守卫：这将静态地 panic，或者什么也不做。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn assert_uninit_valid<T>();

    /// Gets a reference to a static `Location` indicating where it was called. <br>获取对静态 `Location` 的引用，以指示在何处调用了它。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// Consider using [`core::panic::Location::caller`] instead. <br>可以考虑使用 [`core::panic::Location::caller`]。<br>
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Moves a value out of scope without running drop glue. <br>将值移出作用域。而无需运行丢弃守卫。<br>
    ///
    /// This exists solely for [`mem::forget_unsized`]; <br>这仅适用于 [`mem::forget_unsized`]。<br> normal `forget` uses `ManuallyDrop` instead. <br>正常情况下，请改用 `forget` 为 `ManuallyDrop`。<br>
    ///
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets the bits of a value of one type as another type. <br>将一种类型的值的位重新解释为另一种类型。<br>
    ///
    /// Both types must have the same size. <br>两种类型都必须具有相同的大小。<br>
    /// Neither the original, nor the result, may be an [invalid value](../../nomicon/what-unsafe-does.html). <br>[invalid value](../../nomicon/what-unsafe-does.html) 既不是原始版本，也不是结果。<br>
    ///
    /// `transmute` is semantically equivalent to a bitwise move of one type into another. <br>`transmute` 在语义上等同于将一种类型按位移动到另一种类型。<br> It copies the bits from the source value into the destination value, then forgets the original. <br>它将位从源值复制到目标值，然后忘记原始值。<br>
    /// It's equivalent to C's `memcpy` under the hood, just like `transmute_copy`. <br>就像 `transmute_copy` 一样，它等同于 C 的引擎盖下的 `memcpy`。<br>
    ///
    /// Because `transmute` is a by-value operation, alignment of the *transmuted values themselves* is not a concern. <br>由于 `transmute` 是按值运算，因此不必担心 *transmuted values 本身的对齐*。<br>
    /// As with any other function, the compiler already ensures both `T` and `U` are properly aligned. <br>与任何其他函数一样，编译器已经确保 `T` 和 `U` 都正确对齐。<br>
    /// However, when transmuting values that *point elsewhere* (such as pointers, references, boxes…), the caller has to ensure proper alignment of the pointed-to values. <br>但是，当将 *point 的值转换为其他位置*(例如指针，引用，boxes…) 时，调用者必须确保所指向的值正确对齐。<br>
    ///
    /// `transmute` is **incredibly** unsafe. <br>`transmute` 是极其不安全的。<br> There are a vast number of ways to cause [undefined behavior][ub] with this function. <br>有很多方法可以使用此函数来导致 [未定义的行为][ub]。<br> `transmute` should be the absolute last resort. <br>`transmute` 应该是绝对不得已的方法。<br>
    ///
    /// Transmuting pointers to integers in a `const` context is [undefined behavior][ub]. <br>在 `const` 上下文中转换指向整数的指针是 [未定义的行为][ub]。<br>
    /// Any attempt to use the resulting value for integer operations will abort const-evaluation. <br>任何将结果值用于整数运算的尝试都将终止常量评估。<br>
    ///
    /// The [nomicon](../../nomicon/transmutes.html) has additional documentation. <br>[nomicon](../../nomicon/transmutes.html) 具有其他文档。<br>
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// There are a few things that `transmute` is really useful for. <br>`transmute` 确实有一些用途。<br>
    ///
    /// Turning a pointer into a function pointer. <br>将指针转换为函数指针。<br> This is *not* portable to machines where function pointers and data pointers have different sizes. <br>对于函数指针和数据指针具有不同大小的机器，这不是可移植的。<br>
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Extending a lifetime, or shortening an invariant lifetime. <br>延长生命周期或缩短不变的生命周期。<br> This is advanced, very unsafe Rust! <br>这是高级的，非常不安全的 Rust!<br>
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Don't despair: many uses of `transmute` can be achieved through other means. <br>不要失望: `transmute` 的许多用途可以通过其他方式实现。<br>
    /// Below are common applications of `transmute` which can be replaced with safer constructs. <br>以下是 `transmute` 的常见应用程序，可以用更安全的结构替换它。<br>
    ///
    /// Turning raw bytes(`&[u8]`) to `u32`, `f64`, etc.: <br>将原始 bytes(`&[u8]`) 转换为 `u32`，`f64` 等：<br>
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // use `u32::from_ne_bytes` instead <br>请改用 `u32::from_ne_bytes`<br>
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // or use `u32::from_le_bytes` or `u32::from_be_bytes` to specify the endianness <br>或使用 `u32::from_le_bytes` 或 `u32::from_be_bytes` 指定字节顺序<br>
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Turning a pointer into a `usize`: <br>将指针变成 `usize`：<br>
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Use an `as` cast instead <br>请改用 `as` cast<br>
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Turning a `*mut T` into an `&mut T`: <br>将 `*mut T` 变成 `&mut T`：<br>
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Use a reborrow instead <br>请改用 reborrow<br>
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Turning an `&mut T` into an `&mut U`: <br>将 `&mut T` 变成 `&mut U`：<br>
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Now, put together `as` and reborrowing - note the chaining of `as` `as` is not transitive <br>现在，将 `as` 和 reborrowing 放在一起 - 请注意，`as` `as` 的链接是不可传递的<br>
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Turning an `&str` into a `&[u8]`: <br>将 `&str` 变成 `&[u8]`：<br>
    ///
    /// ```
    /// // this is not a good way to do this. <br>这不是执行此操作的好方法。<br>
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // You could use `str::as_bytes` <br>您可以使用 `str::as_bytes`<br>
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Or, just use a byte string, if you have control over the string literal <br>或者，如果您可以控制字符串，则只需使用字节字符串即可。<br>
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Turning a `Vec<&T>` into a `Vec<Option<&T>>`. <br>将 `Vec<&T>` 变成 `Vec<Option<&T>>`。<br>
    ///
    /// To transmute the inner type of the contents of a container, you must make sure to not violate any of the container's invariants. <br>要转换容器内容的内部类型，必须确保不违反容器的任何不变量。<br>
    /// For `Vec`, this means that both the size *and alignment* of the inner types have to match. <br>对于 `Vec`，这意味着内部类型的大小和对齐方式都必须匹配。<br>
    /// Other containers might rely on the size of the type, alignment, or even the `TypeId`, in which case transmuting wouldn't be possible at all without violating the container invariants. <br>其他容器可能依赖于类型，对齐方式甚至 `TypeId` 的大小，在这种情况下，在不违反容器不变量的情况下根本不可能进行转换。<br>
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone the vector as we will reuse them later <br>克隆 vector，因为稍后我们将重用它们<br>
    /// let v_clone = v_orig.clone();
    ///
    /// // Using transmute: this relies on the unspecified data layout of `Vec`, which is a bad idea and could cause Undefined Behavior. <br>使用 transmute: 这依赖于 `Vec` 的未指定数据布局，这是一个坏主意，并可能导致未定义的行为。<br>
    /////
    /// // However, it is no-copy. <br>但是，它不是 copy 的。<br>
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // This is the suggested, safe way. <br>这是建议的安全方法。<br>
    /// // It does copy the entire vector, though, into a new array. <br>但是，它确实将整个 vector 复制到一个新数组中。<br>
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // This is the proper no-copy, unsafe way of "transmuting" a `Vec`, without relying on the data layout. <br>这是 "transmuting" 和 `Vec` 的正确无复制，不安全的方式，而无需依赖数据布局。<br>
    /// // Instead of literally calling `transmute`, we perform a pointer cast, but in terms of converting the original inner type (`&i32`) to the new one (`Option<&i32>`), this has all the same caveats. <br>我们不执行字面上的调用 `transmute`，而是执行指针强制转换，但是就将原始内部类型 (`&i32`) 转换为新的 (`Option<&i32>`) 而言，这具有所有相同的警告。<br>
    /////
    /// // Besides the information provided above, also consult the [`from_raw_parts`] documentation. <br>除了上面提供的信息之外，还请查阅 [`from_raw_parts`] 文档。<br>
    /////
    /// let v_from_raw = unsafe {
    // FIXME Update this when vec_into_raw_parts is stabilized <br>在 vec_into_raw_parts 稳定后更新它<br>
    ///     // Ensure the original vector is not dropped. <br>确保原始 vector 没有被丢弃。<br>
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementing `split_at_mut`: <br>实现 `split_at_mut`：<br>
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // There are multiple ways to do this, and there are multiple problems with the following (transmute) way. <br>有多种方法可以执行此操作，并且以下 (transmute) 方法存在多个问题。<br>
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // first: transmute is not type safe; <br>第一：transmute 不是类型安全的；<br> all it checks is that T and U are of the same size. <br>它只检查 T 和 U 的大小是否相同。<br>
    ///         // Second, right here, you have two mutable references pointing to the same memory. <br>其次，在这里，您有两个指向同一内存的可变引用。<br>
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // This gets rid of the type safety problems; <br>这消除了类型安全问题；<br> `&mut *` will *only* give you an `&mut T` from an `&mut T` or `*mut T`. <br>`&mut *`* 仅 *将为您提供 `&mut T` 或 `*mut T` 的 `&mut T`。<br>
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // however, you still have two mutable references pointing to the same memory. <br>但是，您仍然有两个指向同一内存的可变引用。<br>
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // This is how the standard library does it. <br>这就是标准库的工作方式。<br>
    /// // This is the best method, if you need to do something like this <br>如果您需要执行以下操作，这是最好的方法<br>
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // This now has three mutable references pointing at the same memory. <br>现在，它具有三个指向同一内存的可变引用。<br> `slice`, the rvalue ret.0, and the rvalue ret.1. <br>`slice`，右值 ret.0 和右值 ret.1。<br>
    ///         // `slice` is never used after `let ptr = ...`, and so one can treat it as "dead", and therefore, you only have two real mutable slices. <br>`slice` 在 `let ptr = ...` 之后就不再使用了，所以可以把它当作 "dead" 来对待，所以，您只有两个真正的可变切片。<br>
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Returns `true` if the actual type given as `T` requires drop glue; <br>如果 `T` 给出的实际类型需要丢弃 glue，则返回 `true`。<br> returns `false` if the actual type provided for `T` implements `Copy`. <br>如果为 `T` 提供的实际类型实现 `Copy`，则返回 `false`。<br>
    ///
    ///
    /// If the actual type neither requires drop glue nor implements `Copy`, then the return value of this function is unspecified. <br>如果实际类型既不需要丢弃 glue 也不需要实现 `Copy`，则该函数的返回值不确定。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized version of this intrinsic is [`mem::needs_drop`](crate::mem::needs_drop). <br>此内部函数的稳定版本为 [`mem::needs_drop`](crate::mem::needs_drop)。<br>
    ///
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calculates the offset from a pointer. <br>计算与指针的偏移量。<br>
    ///
    /// This is implemented as an intrinsic to avoid converting to and from an integer, since the conversion would throw away aliasing information. <br>这被实现为内部函数，以避免与整数进行转换，因为转换会丢弃别名信息。<br>
    ///
    /// # Safety
    ///
    /// Both the starting and resulting pointer must be either in bounds or one byte past the end of an allocated object. <br>起始指针和结果指针都必须在已分配对象末尾的范围之内或一个字节内。<br>
    /// If either pointer is out of bounds or arithmetic overflow occurs then any further use of the returned value will result in undefined behavior. <br>如果指针越界或发生算术溢出，则进一步使用返回值将导致不确定的行为。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`pointer::offset`]. <br>此内部函数的稳定版本为 [`pointer::offset`]。<br>
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calculates the offset from a pointer, potentially wrapping. <br>计算与指针的偏移量 (可能会自动换行)。<br>
    ///
    /// This is implemented as an intrinsic to avoid converting to and from an integer, since the conversion inhibits certain optimizations. <br>这被实现为内部函数，以避免与整数进行相互转换，因为该转换会禁止某些优化。<br>
    ///
    /// # Safety
    ///
    /// Unlike the `offset` intrinsic, this intrinsic does not restrict the resulting pointer to point into or one byte past the end of an allocated object, and it wraps with two's complement arithmetic. <br>与 `offset` 内部函数不同，此内部函数不会限制结果指针指向已分配对象的末尾或指向该对象末尾一个字节，并且使用二进制补码算法进行换行。<br>
    /// The resulting value is not necessarily valid to be used to actually access memory. <br>结果值不一定有效地用于实际访问内存。<br>
    ///
    /// The stabilized version of this intrinsic is [`pointer::wrapping_offset`]. <br>此内部函数的稳定版本为 [`pointer::wrapping_offset`]。<br>
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalent to the appropriate `llvm.memcpy.p0i8.0i8.*` intrinsic, with a size of `count` * `size_of::<T>()` and an alignment of `min_align_of::<T>()` <br>相当于适当的 `llvm.memcpy.p0i8.0i8.*` 内部函数，大小为 `count` * `size_of::<T>()`，对齐方式为 `min_align_of::<T>()`<br>
    ///
    ///
    /// The volatile parameter is set to `true`, so it will not be optimized out unless size is equal to zero. <br>volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalent to the appropriate `llvm.memmove.p0i8.0i8.*` intrinsic, with a size of `count * size_of::<T>()` and an alignment of `min_align_of::<T>()` <br>相当于适当的 `llvm.memmove.p0i8.0i8.*` 内部函数，大小为 `count * size_of::<T>()`，对齐方式为 `min_align_of::<T>()`<br>
    ///
    ///
    /// The volatile parameter is set to `true`, so it will not be optimized out unless size is equal to zero. <br>volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalent to the appropriate `llvm.memset.p0i8.*` intrinsic, with a size of `count * size_of::<T>()` and an alignment of `min_align_of::<T>()`. <br>等效于适当的 `llvm.memset.p0i8.*` 内部函数，其大小为 `count* size_of::<T>()`，并且对齐方式为 `min_align_of::<T>()`。<br>
    ///
    ///
    /// The volatile parameter is set to `true`, so it will not be optimized out unless size is equal to zero. <br>volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Performs a volatile load from the `src` pointer. <br>从 `src` 指针执行易失性加载。<br>
    ///
    /// The stabilized version of this intrinsic is [`core::ptr::read_volatile`]. <br>这个 intrinsic 的稳定版本是 [`core::ptr::read_volatile`]。<br>
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Performs a volatile store to the `dst` pointer. <br>对 `dst` 指针执行易失性存储。<br>
    ///
    /// The stabilized version of this intrinsic is [`core::ptr::write_volatile`]. <br>这个 intrinsic 的稳定版本是 [`core::ptr::write_volatile`]。<br>
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Performs a volatile load from the `src` pointer The pointer is not required to be aligned. <br>从 `src` 指针执行易失性加载不需要将指针对齐。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Performs a volatile store to the `dst` pointer. <br>对 `dst` 指针执行易失性存储。<br>
    /// The pointer is not required to be aligned. <br>指针不需要对齐。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Returns the square root of an `f32` <br>返回 `f32` 的平方根<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Returns the square root of an `f64` <br>返回 `f64` 的平方根<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Raises an `f32` to an integer power. <br>将 `f32` 提升为整数幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Raises an `f64` to an integer power. <br>将 `f64` 提升为整数幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Returns the sine of an `f32`. <br>返回 `f32` 的正弦值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Returns the sine of an `f64`. <br>返回 `f64` 的正弦值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Returns the cosine of an `f32`. <br>返回 `f32` 的余弦值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Returns the cosine of an `f64`. <br>返回 `f64` 的余弦值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Raises an `f32` to an `f32` power. <br>将 `f32` 提升到 `f32` 的幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Raises an `f64` to an `f64` power. <br>将 `f64` 提升到 `f64` 的幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Returns the exponential of an `f32`. <br>返回 `f32` 的指数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Returns the exponential of an `f64`. <br>返回 `f64` 的指数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returns 2 raised to the power of an `f32`. <br>返回 2 乘以 `f32` 的幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returns 2 raised to the power of an `f64`. <br>返回 2 乘以 `f64` 的幂。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Returns the natural logarithm of an `f32`. <br>返回 `f32` 的自然对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Returns the natural logarithm of an `f64`. <br>返回 `f64` 的自然对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Returns the base 10 logarithm of an `f32`. <br>返回 `f32` 的以 10 为底的对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Returns the base 10 logarithm of an `f64`. <br>返回 `f64` 的以 10 为底的对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Returns the base 2 logarithm of an `f32`. <br>返回 `f32` 的以 2 为底的对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Returns the base 2 logarithm of an `f64`. <br>返回 `f64` 的以 2 为底的对数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Returns `a * b + c` for `f32` values. <br>为 `f32` 值返回 `a * b + c`。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Returns `a * b + c` for `f64` values. <br>为 `f64` 值返回 `a * b + c`。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Returns the absolute value of an `f32`. <br>返回 `f32` 的绝对值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Returns the absolute value of an `f64`. <br>返回 `f64` 的绝对值。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Returns the minimum of two `f32` values. <br>返回两个 `f32` 值中的最小值。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Returns the minimum of two `f64` values. <br>返回两个 `f64` 值中的最小值。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Returns the maximum of two `f32` values. <br>返回两个 `f32` 值的最大值。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Returns the maximum of two `f64` values. <br>返回两个 `f64` 值的最大值。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copies the sign from `y` to `x` for `f32` values. <br>将 `f32` 值的符号从 `y` 复制到 `x`。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copies the sign from `y` to `x` for `f64` values. <br>将 `f64` 值的符号从 `y` 复制到 `x`。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Returns the largest integer less than or equal to an `f32`. <br>返回小于或等于 `f32` 的最大整数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Returns the largest integer less than or equal to an `f64`. <br>返回小于或等于 `f64` 的最大整数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Returns the smallest integer greater than or equal to an `f32`. <br>返回大于或等于 `f32` 的最小整数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Returns the smallest integer greater than or equal to an `f64`. <br>返回大于或等于 `f64` 的最小整数。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Returns the integer part of an `f32`. <br>返回 `f32` 的整数部分。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Returns the integer part of an `f64`. <br>返回 `f64` 的整数部分。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Returns the nearest integer to an `f32`. <br>返回最接近 `f32` 的整数。<br>
    /// May raise an inexact floating-point exception if the argument is not an integer. <br>如果参数不是整数，则可能会引发不精确的浮点异常。<br>
    pub fn rintf32(x: f32) -> f32;
    /// Returns the nearest integer to an `f64`. <br>返回最接近 `f64` 的整数。<br>
    /// May raise an inexact floating-point exception if the argument is not an integer. <br>如果参数不是整数，则可能会引发不精确的浮点异常。<br>
    pub fn rintf64(x: f64) -> f64;

    /// Returns the nearest integer to an `f32`. <br>返回最接近 `f32` 的整数。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn nearbyintf32(x: f32) -> f32;
    /// Returns the nearest integer to an `f64`. <br>返回最接近 `f64` 的整数。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn nearbyintf64(x: f64) -> f64;

    /// Returns the nearest integer to an `f32`. <br>返回最接近 `f32` 的整数。<br> Rounds half-way cases away from zero. <br>在离零一半的情况下进行舍入。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Returns the nearest integer to an `f64`. <br>返回最接近 `f64` 的整数。<br> Rounds half-way cases away from zero. <br>在离零一半的情况下进行舍入。<br>
    ///
    /// The stabilized version of this intrinsic is <br>此内部函数的稳定版本是<br>
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float addition that allows optimizations based on algebraic rules. <br>浮点数加法允许基于代数规则进行优化。<br>
    /// May assume inputs are finite. <br>可以假设输入是有限的。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float subtraction that allows optimizations based on algebraic rules. <br>浮点减法允许基于代数规则进行优化。<br>
    /// May assume inputs are finite. <br>可以假设输入是有限的。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float multiplication that allows optimizations based on algebraic rules. <br>浮点乘法允许基于代数规则进行优化。<br>
    /// May assume inputs are finite. <br>可以假设输入是有限的。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float division that allows optimizations based on algebraic rules. <br>浮点除法允许基于代数规则进行优化。<br>
    /// May assume inputs are finite. <br>可以假设输入是有限的。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float remainder that allows optimizations based on algebraic rules. <br>浮余数允许基于代数规则进行优化。<br>
    /// May assume inputs are finite. <br>可以假设输入是有限的。<br>
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convert with LLVM’s fptoui/fptosi, which may return undef for values out of range <br>使用 LLVM 的 fptoui/fptosi 进行转换，对于越界的值可能会返回 undef<br>
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilized as [`f32::to_int_unchecked`] and [`f64::to_int_unchecked`]. <br>稳定为 [`f32::to_int_unchecked`] 和 [`f64::to_int_unchecked`]。<br>
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Returns the number of bits set in an integer type `T` <br>返回整数类型 `T` 中设置的位数<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `count_ones` method. <br>可通过 `count_ones` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Returns the number of leading unset bits (zeroes) in an integer type `T`. <br>返回整数类型 `T` 的前导未设置位 (zeroes) 的数量。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `leading_zeros` method. <br>可通过 `leading_zeros` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// An `x` with value `0` will return the bit width of `T`. <br>值为 `0` 的 `x` 将返回 `T` 的位宽。<br>
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Like `ctlz`, but extra-unsafe as it returns `undef` when given an `x` with value `0`. <br>类似于 `ctlz`，但是非常不安全，因为当给定值 `0` 的 `x` 时，它返回 `undef`。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Returns the number of trailing unset bits (zeroes) in an integer type `T`. <br>返回整数类型 `T` 的尾随未设置位 (zeroes) 的数量。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `trailing_zeros` method. <br>可通过 `trailing_zeros` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// An `x` with value `0` will return the bit width of `T`: <br>值为 `0` 的 `x` 将返回 `T` 的位宽：<br>
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Like `cttz`, but extra-unsafe as it returns `undef` when given an `x` with value `0`. <br>类似于 `cttz`，但是非常不安全，因为当给定值 `0` 的 `x` 时，它返回 `undef`。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.53.0")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverses the bytes in an integer type `T`. <br>反转整数类型 `T` 中的字节。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `swap_bytes` method. <br>可通过 `swap_bytes` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses the bits in an integer type `T`. <br>反转整数类型 `T` 中的位。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `reverse_bits` method. <br>可通过 `reverse_bits` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Performs checked integer addition. <br>执行检查的整数加法。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `overflowing_add` method. <br>可通过 `overflowing_add` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Performs checked integer subtraction <br>执行检查的整数减法<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `overflowing_sub` method. <br>可通过 `overflowing_sub` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Performs checked integer multiplication <br>执行检查的整数乘法<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `overflowing_mul` method. <br>可通过 `overflowing_mul` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Performs an exact division, resulting in undefined behavior where `x % y != 0` or `y == 0` or `x == T::MIN && y == -1` <br>执行精确除法，从而导致 `x % y != 0` 或 `y == 0` 或 `x == T::MIN && y == -1` 出现不确定的行为<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Performs an unchecked division, resulting in undefined behavior where `y == 0` or `x == T::MIN && y == -1` <br>执行未经检查的除法，从而导致 `y == 0` 或 `x == T::MIN && y == -1` 出现不确定的行为<br>
    ///
    ///
    /// Safe wrappers for this intrinsic are available on the integer primitives via the `checked_div` method. <br>可通过 `checked_div` 方法在整数原语上使用此内部函数的安全包装。<br>
    /// For example, <br>例如，<br>
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Returns the remainder of an unchecked division, resulting in undefined behavior when `y == 0` or `x == T::MIN && y == -1` <br>返回未经检查的除法的其余部分，从而在 `y == 0` 或 `x == T::MIN && y == -1` 时导致未定义的行为<br>
    ///
    ///
    /// Safe wrappers for this intrinsic are available on the integer primitives via the `checked_rem` method. <br>可通过 `checked_rem` 方法在整数原语上使用此内部函数的安全包装。<br>
    /// For example, <br>例如，<br>
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Performs an unchecked left shift, resulting in undefined behavior when `y < 0` or `y >= N`, where N is the width of T in bits. <br>执行未经检查的左移，导致 `y < 0` 或 `y >= N` 出现不确定的行为，其中 N 是 T 的宽度 (以位为单位)。<br>
    ///
    ///
    /// Safe wrappers for this intrinsic are available on the integer primitives via the `checked_shl` method. <br>可通过 `checked_shl` 方法在整数原语上使用此内部函数的安全包装。<br>
    /// For example, <br>例如，<br>
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Performs an unchecked right shift, resulting in undefined behavior when `y < 0` or `y >= N`, where N is the width of T in bits. <br>执行未经检查的右移，导致 `y < 0` 或 `y >= N` 出现不确定的行为，其中 N 是 T 的宽度 (以位为单位)。<br>
    ///
    ///
    /// Safe wrappers for this intrinsic are available on the integer primitives via the `checked_shr` method. <br>可通过 `checked_shr` 方法在整数原语上使用此内部函数的安全包装。<br>
    /// For example, <br>例如，<br>
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Returns the result of an unchecked addition, resulting in undefined behavior when `x + y > T::MAX` or `x + y < T::MIN`. <br>返回未经检查的加法运算的结果，导致 `x + y > T::MAX` 或 `x + y < T::MIN` 出现不确定的行为。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Returns the result of an unchecked subtraction, resulting in undefined behavior when `x - y > T::MAX` or `x - y < T::MIN`. <br>返回未经检查的减法的结果，当 `x - y > T::MAX` 或 `x - y < T::MIN` 时导致未定义的行为。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Returns the result of an unchecked multiplication, resulting in undefined behavior when `x * y > T::MAX` or `x * y < T::MIN`. <br>返回未经检查的乘法的结果，当 `x *y > T::MAX` 或 `x* y < T::MIN` 时导致未定义的行为。<br>
    ///
    ///
    /// This intrinsic does not have a stable counterpart. <br>此内部函数没有稳定的对应对象。<br>
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Performs rotate left. <br>向左旋转。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `rotate_left` method. <br>可通过 `rotate_left` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Performs rotate right. <br>向右旋转。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `rotate_right` method. <br>可通过 `rotate_right` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) mod 2<sup>N</sup>, where N is the width of T in bits. <br>返回 (a + b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `wrapping_add` method. <br>可通过 `wrapping_add` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a - b) mod 2<sup>N</sup>, where N is the width of T in bits. <br>返回 (a-b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `wrapping_sub` method. <br>可通过 `wrapping_sub` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (a * b) mod 2<sup>N</sup>, where N is the width of T in bits. <br>返回 (a * b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `wrapping_mul` method. <br>可通过 `wrapping_mul` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating at numeric bounds. <br>计算 `a + b`，在数字范围内达到饱和。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `saturating_add` method. <br>可通过 `saturating_add` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, saturating at numeric bounds. <br>计算 `a - b`，在数字范围内达到饱和。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    /// The stabilized versions of this intrinsic are available on the integer primitives via the `saturating_sub` method. <br>可通过 `saturating_sub` 方法在整数原语上使用此内部函数的稳定版本。<br>
    ///
    /// For example, <br>例如，<br>
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Returns the value of the discriminant for the variant in 'v'; <br>返回 'v' 中变体的判别式的值；<br>
    /// if `T` has no discriminant, returns `0`. <br>如果 `T` 没有判别，则返回 `0`。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The stabilized version of this intrinsic is [`core::mem::discriminant`]. <br>这个 intrinsic 的稳定版本是 [`core::mem::discriminant`]。<br>
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Returns the number of variants of the type `T` cast to a `usize`; <br>返回 `T` 类型强制转换为 `usize` 的变体的数量；<br>
    /// if `T` has no variants, returns `0`. <br>如果 `T` 没有变体，则返回 `0`。<br> Uninhabited variants will be counted. <br>无人居住的变体将被计算在内。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    ///
    /// The to-be-stabilized version of this intrinsic is [`mem::variant_count`]. <br>此内部函数的稳定版本为 [`mem::variant_count`]。<br>
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" construct which invokes the function pointer `try_fn` with the data pointer `data`. <br>Rust 的 "try catch" 构造使用数据指针 `data` 调用函数指针 `try_fn`。<br>
    ///
    /// The third argument is a function called if a panic occurs. <br>第三个参数是如果发生 panic 时调用的函数。<br>
    /// This function takes the data pointer and a pointer to the target-specific exception object that was caught. <br>此函数采用数据指针和指向所捕获的特定于目标的异常对象的指针。<br>
    ///
    /// For more information see the compiler's source as well as std's catch implementation. <br>有关更多信息，请参见编译器的源代码以及 std 的 catch 实现。<br>
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emits a `!nontemporal` store according to LLVM (see their docs). <br>根据 LLVM 发出 `!nontemporal` 存储 (请参见其文档)。<br>
    /// Probably will never become stable. <br>可能永远都不会变得稳定。<br>
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// See documentation of `<*const T>::offset_from` for details. <br>有关详细信息，请参见 `<*const T>::offset_from` 的文档。<br>
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// See documentation of `<*const T>::guaranteed_eq` for details. <br>有关详细信息，请参见 `<*const T>::guaranteed_eq` 的文档。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// See documentation of `<*const T>::guaranteed_ne` for details. <br>有关详细信息，请参见 `<*const T>::guaranteed_ne` 的文档。<br>
    ///
    /// Note that, unlike most intrinsics, this is safe to call; <br>请注意，与大多数内部函数不同，这对调用是安全的；<br>
    /// it does not require an `unsafe` block. <br>它不需要 `unsafe` 块。<br>
    /// Therefore, implementations must not require the user to uphold any safety invariants. <br>因此，实现不得要求用户维护任何安全不变量。<br>
    ///
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Allocate at compile time. <br>在编译时分配。<br> Should not be called at runtime. <br>不应在运行时调用。<br>
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;

    /// Determines whether the raw bytes of the two values are equal. <br>确定两个值的原始字节是否相等。<br>
    ///
    /// The is particularly handy for arrays, since it allows things like just comparing `i96`s instead of forcing `alloca`s for `[6 x i16]`. <br>这对于数组来说特别方便，因为它允许只比较 i96 而不是对 `[6 x i16]` 强制使用 alloca。<br>
    ///
    /// Above some backend-decided threshold this will emit calls to `memcmp`, like slice equality does, instead of causing massive code size. <br>在某些后端决定的之上，这将发出 `memcmp` 调用，就像对相等阈值所做的那样，而不是导致大量代码大小。<br>
    ///
    /// # Safety
    ///
    /// It's UB to call this if any of the *bytes* in `*a` or `*b` are uninitialized. <br>如果 `*a` 或 `*b` 中的任何 *bytes* 未初始化，这是 UB 到调用 this。<br>
    /// Note that this is a stricter criterion than just the *values* being fully-initialized: if `T` has padding, it's UB to call this intrinsic. <br>请注意，这是一个比完全初始化 *values* 更严格的标准：如果 `T` 有填充，它是 UB 到调用这个内部函数。<br>
    ///
    ///
    /// (The implementation is allowed to branch on the results of comparisons, which is UB if any of their inputs are `undef`.) <br>(该实现允许在比较结果上进行分支，如果它们的任何输入为 `undef`，则为 UB。)<br>
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_raw_eq", issue = "none")]
    pub fn raw_eq<T>(a: &T, b: &T) -> bool;

    /// See documentation of [`std::hint::black_box`] for details. <br>有关详细信息，请参见 [`std::hint::black_box`] 的文档。<br>
    ///
    /// [`std::hint::black_box`]: crate::hint::black_box
    pub fn black_box<T>(dummy: T) -> T;
}

// Some functions are defined here because they accidentally got made available in this module on stable. <br>之所以在这里定义一些函数，是因为它们意外地在稳定模块中可用。<br>
// See <https://github.com/rust-lang/rust/issues/15702>. <br>请参见 <https://github.com/rust-lang/rust/issues/15702>。<br>
// (`transmute` also falls into this category, but it cannot be wrapped due to the check that `T` and `U` have the same size.) <br>(`transmute` 也属于此类别，但是由于检查 `T` 和 `U` 具有相同的大小，因此无法将其包装。)<br>
//

/// Checks whether `ptr` is properly aligned with respect to `align_of::<T>()`. <br>检查 `ptr` 是否相对于 `align_of::<T>()` 正确对齐。<br>
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Checks whether the regions of memory starting at `src` and `dst` of size `count * size_of::<T>()` do *not* overlap. <br>检查从 `src` 和 `dst` 开始、大小为 `count * size_of::<T>()` 的内存区域是否*不*重叠。<br>
///
#[cfg(debug_assertions)]
pub(crate) fn is_nonoverlapping<T>(src: *const T, dst: *const T, count: usize) -> bool {
    let src_usize = src as usize;
    let dst_usize = dst as usize;
    let size = mem::size_of::<T>().checked_mul(count).unwrap();
    let diff = if src_usize > dst_usize { src_usize - dst_usize } else { dst_usize - src_usize };
    // If the absolute distance between the ptrs is at least as big as the size of the buffer, they do not overlap. <br>如果 ptr 之间的绝对距离至少与缓冲区的大小一样大，则它们不会重叠。<br>
    //
    diff >= size
}

/// Copies `count * size_of::<T>()` bytes from `src` to `dst`. <br>将 `count * size_of::<T>()` 字节从 `src` 复制到 `dst`。<br> The source and destination must *not* overlap. <br>源和目标必须不重叠。<br>
///
/// For regions of memory which might overlap, use [`copy`] instead. <br>对于可能重叠的内存区域，请改用 [`copy`]。<br>
///
/// `copy_nonoverlapping` is semantically equivalent to C's [`memcpy`], but with the argument order swapped. <br>`copy_nonoverlapping` 在语义上等同于 C 的 [`memcpy`]，但交换了参数顺序。<br>
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads of `count * size_of::<T>()` bytes. <br>对于 `count * size_of::<T>()` 字节的读取，`src` 必须是 [valid]。<br>
///
/// * `dst` must be [valid] for writes of `count * size_of::<T>()` bytes. <br>对于 `count * size_of::<T>()` 字节的写入，`dst` 必须是 [valid]。<br>
///
/// * Both `src` and `dst` must be properly aligned. <br>`src` 和 `dst` 必须正确对齐。<br>
///
/// * The region of memory beginning at `src` with a size of `count <br>从 `src` 开始的内存区域，大小为 `count<br> *
///   size_of::<T>()` bytes must *not* overlap with the region of memory beginning at `dst` with the same size. <br>size_of::<T> () ` 字节不得与以 `dst` 开始且大小相同的内存区域重叠。<br>
///
/// Like [`read`], `copy_nonoverlapping` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`copy_nonoverlapping` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using *both* the values in the region beginning at `*src` and the region beginning at `*dst` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则使用两个以 `*src` 开头的区域和以 `*dst` 开头的区域中的值可以 [违反内存安全][read-ownership]。<br>
///
///
/// Note that even if the effectively copied size (`count * size_of::<T>()`) is `0`, the pointers must be non-null and properly aligned. <br>请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。<br>
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manually implement [`Vec::append`]: <br>手动实现 [`Vec::append`]：<br>
///
/// ```
/// use std::ptr;
///
/// /// Moves all the elements of `src` into `dst`, leaving `src` empty. <br>将 `src` 的所有元素移到 `dst`，将 `src` 留空。<br>
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Ensure that `dst` has enough capacity to hold all of `src`. <br>确保 `dst` 具有足够的容量来容纳所有 `src`。<br>
///     dst.reserve(src_len);
///
///     unsafe {
///         // The call to offset is always safe because `Vec` will never allocate more than `isize::MAX` bytes. <br>偏移的调用始终是安全的，因为 `Vec` 分配的字节数永远不会超过 `isize::MAX` 字节。<br>
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` without dropping its contents. <br>截断 `src` 而不丢弃其内容。<br>
///         // We do this first, to avoid problems in case something further down panics. <br>我们首先执行此操作，以避免在 panics 处出现问题时避免出现问题。<br>
///         src.set_len(0);
///
///         // The two regions cannot overlap because mutable references do not alias, and two different vectors cannot own the same memory. <br>这两个区域不能重叠，因为可变引用没有别名，并且两个不同的 vectors 不能拥有相同的内存。<br>
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notify `dst` that it now holds the contents of `src`. <br>通知 `dst` 现在包含 `src` 的内容。<br>
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        pub fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    #[cfg(debug_assertions)]
    fn runtime_check<T>(src: *const T, dst: *mut T, count: usize) {
        if !is_aligned_and_not_null(src)
            || !is_aligned_and_not_null(dst)
            || !is_nonoverlapping(src, dst, count)
        {
            // Not panicking to keep codegen impact smaller. <br>不要 panic，以保持代码生成的影响较小。<br>
            abort();
        }
    }
    #[cfg(debug_assertions)]
    const fn compiletime_check<T>(_src: *const T, _dst: *mut T, _count: usize) {}
    #[cfg(debug_assertions)]
    // SAFETY: runtime debug-assertions are a best-effort basis; <br>运行时调试断言是最好的努力基础；<br> it's fine to not do them during compile time <br>在编译时不执行这些操作也没关系<br>
    //
    unsafe {
        const_eval_select((src, dst, count), compiletime_check, runtime_check);
    }

    // SAFETY: the safety contract for `copy_nonoverlapping` must be upheld by the caller. <br>调用者必须遵守 `copy_nonoverlapping` 的安全保证。<br>
    //
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copies `count * size_of::<T>()` bytes from `src` to `dst`. <br>将 `count * size_of::<T>()` 字节从 `src` 复制到 `dst`。<br> The source and destination may overlap. <br>源和目标可能会重叠。<br>
///
/// If the source and destination will *never* overlap, [`copy_nonoverlapping`] can be used instead. <br>如果源和目标永远不会重叠，则可以改用 [`copy_nonoverlapping`]。<br>
///
/// `copy` is semantically equivalent to C's [`memmove`], but with the argument order swapped. <br>`copy` 在语义上等同于 C 的 [`memmove`]，但交换了参数顺序。<br>
/// Copying takes place as if the bytes were copied from `src` to a temporary array and then copied from the array to `dst`. <br>就像将字节从 `src` 复制到临时数组，然后从数组复制到 `dst` 一样进行复制。<br>
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `src` must be [valid] for reads of `count * size_of::<T>()` bytes. <br>对于 `count * size_of::<T>()` 字节的读取，`src` 必须是 [valid]。<br>
///
/// * `dst` must be [valid] for writes of `count * size_of::<T>()` bytes. <br>对于 `count * size_of::<T>()` 字节的写入，`dst` 必须是 [valid]。<br>
///
/// * Both `src` and `dst` must be properly aligned. <br>`src` 和 `dst` 必须正确对齐。<br>
///
/// Like [`read`], `copy` creates a bitwise copy of `T`, regardless of whether `T` is [`Copy`]. <br>与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`copy` 都会创建 `T` 的按位副本。<br>
/// If `T` is not [`Copy`], using both the values in the region beginning at `*src` and the region beginning at `*dst` can [violate memory safety][read-ownership]. <br>如果 `T` 不是 [`Copy`]，则可以同时使用以 `*src` 开头的区域和以 `* dst` 开头的区域中的值。<br>
///
///
/// Note that even if the effectively copied size (`count * size_of::<T>()`) is `0`, the pointers must be non-null and properly aligned. <br>请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。<br>
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efficiently create a Rust vector from an unsafe buffer: <br>从不安全的缓冲区有效地创建 Rust vector：<br>
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` must be correctly aligned for its type and non-zero. <br>`ptr` 必须与其类型正确对齐且非零。<br>
/// /// * `ptr` must be valid for reads of `elts` contiguous elements of type `T`. <br>`ptr` 必须对 `T` 类型的 `elts` 连续元素的读取有效。<br>
/// /// * Those elements must not be used after calling this function unless `T: Copy`. <br>除非 `T: Copy`，否则在调用此函数后不得使用这些元素。<br>
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: Our precondition ensures the source is aligned and valid, and `Vec::with_capacity` ensures that we have usable space to write them. <br>我们的前提条件是确保源文件对齐和有效，而 `Vec::with_capacity` 确保我们有可用的空间来编写它们。<br>
/////
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: We created it with this much capacity earlier, and the previous `copy` has initialized these elements. <br>我们之前已经用这么大的容量创建了它，而以前的 `copy` 已经初始化了这些元素。<br>
/////
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    #[cfg(debug_assertions)]
    fn runtime_check<T>(src: *const T, dst: *mut T) {
        if !is_aligned_and_not_null(src) || !is_aligned_and_not_null(dst) {
            // Not panicking to keep codegen impact smaller. <br>不要 panic，以保持代码生成的影响较小。<br>
            abort();
        }
    }
    #[cfg(debug_assertions)]
    const fn compiletime_check<T>(_src: *const T, _dst: *mut T) {}
    #[cfg(debug_assertions)]
    // SAFETY: runtime debug-assertions are a best-effort basis; <br>运行时调试断言是最好的努力基础；<br> it's fine to not do them during compile time <br>在编译时不执行这些操作也没关系<br>
    //
    unsafe {
        const_eval_select((src, dst), compiletime_check, runtime_check);
    }

    // SAFETY: the safety contract for `copy` must be upheld by the caller. <br>调用者必须遵守 `copy` 的安全保证。<br>
    unsafe { copy(src, dst, count) }
}

/// Sets `count * size_of::<T>()` bytes of memory starting at `dst` to `val`. <br>将从 `dst` 开始的 `count * size_of::<T>()` 内存字节设置为 `val`。<br>
///
/// `write_bytes` is similar to C's [`memset`], but sets `count * size_of::<T>()` bytes to `val`. <br>`write_bytes` 类似于 C 的 [`memset`]，但将 `count * size_of::<T>()` 字节设置为 `val`。<br>
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Behavior is undefined if any of the following conditions are violated: <br>如果违反以下任一条件，则行为是未定义的：<br>
///
/// * `dst` must be [valid] for writes of `count * size_of::<T>()` bytes. <br>对于 `count * size_of::<T>()` 字节的写入，`dst` 必须是 [valid]。<br>
///
/// * `dst` must be properly aligned. <br>`dst` 必须正确对齐。<br>
///
/// Additionally, the caller must ensure that writing `count * size_of::<T>()` bytes to the given region of memory results in a valid value of `T`. <br>此外，调用者必须确保将 `count * size_of::<T>()` 字节写入给定的内存区域会导致 `T` 的有效值。<br>
/// Using a region of memory typed as a `T` that contains an invalid value of `T` is undefined behavior. <br>使用类型为 `T` 的内存区域包含无效的 `T` 值是未定义的行为。<br>
///
/// Note that even if the effectively copied size (`count * size_of::<T>()`) is `0`, the pointer must be non-null and properly aligned. <br>请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。<br>
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creating an invalid value: <br>创建一个无效值：<br>
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Leaks the previously held value by overwriting the `Box<T>` with a null pointer. <br>通过使用空指针覆盖 `Box<T>`，泄漏先前保留的值。<br>
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // At this point, using or dropping `v` results in undefined behavior. <br>此时，使用或丢弃 `v` 会导致未定义的行为。<br>
/// // drop(v); // ERROR <br>// 错误<br>
///
/// // Even leaking `v` "uses" it, and hence is undefined behavior. <br>即使 `v` "uses" 泄漏了它，因此也是未定义的行为。<br>
/// // mem::forget(v);  // ERROR <br>// 错误<br>
///
/// // In fact, `v` is invalid according to basic type layout invariants, so *any* operation touching it is undefined behavior. <br>事实上，根据原始类型布局不变性，`v` 是无效的，因此，任何触及它的操作都是未定义的行为。<br>
/////
/// // let v2 = v; // ERROR
///
/// unsafe {
///     // Let us instead put in a valid value <br>让我们输入一个有效值<br>
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Now the box is fine <br>现在 box 很好<br>
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: the safety contract for `write_bytes` must be upheld by the caller. <br>调用者必须遵守 `write_bytes` 的安全保证。<br>
    unsafe { write_bytes(dst, val, count) }
}

/// Selects which function to call depending on the context. <br>根据上下文选择要调用的函数。<br>
///
/// If this function is evaluated at compile-time, then a call to this intrinsic will be replaced with a call to `called_in_const`. <br>如果在编译时对该函数求值，那么这个内部函数的调用将被替换为 `called_in_const` 的调用。<br>
/// It gets replaced with a call to `called_at_rt` otherwise. <br>否则，它会被替换为对 `called_at_rt` 的调用。<br>
///
/// # Type Requirements <br>类型要求<br>
///
/// The two functions must be both function items. <br>这两个函数必须都是函数项。<br> They cannot be function pointers or closures. <br>它们不能是函数指针或闭包。<br>
///
/// `arg` will be the arguments that will be passed to either one of the two functions, therefore, both functions must accept the same type of arguments. <br>`arg` 将是传递给两个函数之一的参数，因此，两个函数必须接受相同类型的参数。<br>
/// Both functions must return RET. <br>两个函数都必须返回 RET。<br>
///
/// # Safety
///
/// This intrinsic allows breaking [referential transparency] in `const fn` and is therefore `unsafe`. <br>这个内部函数允许在 `const fn` 中破坏 [引用透明性][referential transparency]，因此是 `unsafe` 的。<br>
///
/// Code that uses this intrinsic must be extremely careful to ensure that `const fn`s remain referentially-transparent independently of when they are evaluated. <br>使用这个内部函数的代码必须非常小心，以确保 `const fn` 在它们被评估时保持引用透明。<br>
///
///
/// The Rust compiler assumes that it is sound to replace a call to a `const fn` with the result produced by evaluating it at compile-time. <br>Rust 编译器假定将调用替换为 `const fn` 是合理的，它是在编译时对其求值所产生的结果。<br>
/// If evaluating the function at run-time were to produce a different result, or have any other observable side-effects, the behavior is undefined. <br>如果在运行时评估函数会产生不同的结果，或者有任何其他可观察到的副作用，则行为是未定义的。<br>
///
/// [referential transparency]: https://en.wikipedia.org/wiki/Referential_transparency
///
///
///
///
///
///
///
#[unstable(
    feature = "const_eval_select",
    issue = "none",
    reason = "const_eval_select will never be stable"
)]
#[rustc_const_unstable(feature = "const_eval_select", issue = "none")]
#[lang = "const_eval_select"]
#[rustc_do_not_const_check]
pub const unsafe fn const_eval_select<ARG, F, G, RET>(
    arg: ARG,
    _called_in_const: F,
    called_at_rt: G,
) -> RET
where
    F: ~const FnOnce<ARG, Output = RET>,
    G: FnOnce<ARG, Output = RET> + ~const Drop,
{
    called_at_rt.call_once(arg)
}

#[unstable(
    feature = "const_eval_select",
    issue = "none",
    reason = "const_eval_select will never be stable"
)]
#[rustc_const_unstable(feature = "const_eval_select", issue = "none")]
#[lang = "const_eval_select_ct"]
pub const unsafe fn const_eval_select_ct<ARG, F, G, RET>(
    arg: ARG,
    called_in_const: F,
    _called_at_rt: G,
) -> RET
where
    F: ~const FnOnce<ARG, Output = RET>,
    G: FnOnce<ARG, Output = RET> + ~const Drop,
{
    called_in_const.call_once(arg)
}
