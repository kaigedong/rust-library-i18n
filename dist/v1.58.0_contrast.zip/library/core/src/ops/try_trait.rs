use crate::ops::ControlFlow;

/// The `?` operator and `try {}` blocks. <br>`?` 运算符和 `try {}` 块。<br>
///
/// `try_*` methods typically involve a type implementing this trait. <br>`try_*` 方法通常涉及实现此 trait 的类型。<br> For example, the closures passed to [`Iterator::try_fold`] and [`Iterator::try_for_each`] must return such a type. <br>例如，传递给 [`Iterator::try_fold`] 和 [`Iterator::try_for_each`] 的闭包必须返回这样的类型。<br>
///
/// `Try` types are typically those containing two or more categories of values, some subset of which are so commonly handled via early returns that it's worth providing a terse (but still visible) syntax to make that easy. <br>`Try` 类型通常是那些包含两个或更多类别值的类型，其中一些子集通常通过早期返回处理，因此值得提供一个简洁 (但仍然可见) 的语法来简化它。<br>
///
///
/// This is most often seen for error handling with [`Result`] and [`Option`]. <br>这在 [`Result`] 和 [`Option`] 的错误处理中最常见。<br>
/// The quintessential implementation of this trait is on [`ControlFlow`]. <br>这个 trait 的典型实现是在 [`ControlFlow`] 上。<br>
///
/// # Using `Try` in Generic Code <br>在泛型代码中使用 `Try`<br>
///
/// `Iterator::try_fold` was stabilized to call back in Rust 1.27, but this trait is much newer. <br>`Iterator::try_fold` 在 Rust 1.27 中稳定到调用，但是这个 trait 更新很多。<br> To illustrate the various associated types and methods, let's implement our own version. <br>为了说明各种关联类型和方法，让我们实现我们自己的版本。<br>
///
/// As a reminder, an infallible version of a fold looks something like this: <br>提醒一下，一个可靠的折叠版本看起来像这样：<br>
///
/// ```
/// fn simple_fold<A, T>(
///     iter: impl Iterator<Item = T>,
///     mut accum: A,
///     mut f: impl FnMut(A, T) -> A,
/// ) -> A {
///     for x in iter {
///         accum = f(accum, x);
///     }
///     accum
/// }
/// ```
///
/// So instead of `f` returning just an `A`, we'll need it to return some other type that produces an `A` in the "don't short circuit" path. <br>因此，不是 `f` 只返回一个 `A`，我们需要它返回一些在不要短路路径中产生一个 `A` 的其他类型。<br>
/// Conveniently, that's also the type we need to return from the function. <br>方便的是，这也是我们需要从函数返回的类型。<br>
///
/// Let's add a new generic parameter `R` for that type, and bound it to the output type that we want: <br>让我们为该类型添加一个新的泛型参数 `R`，并将其绑定到我们想要的输出类型：<br>
///
/// ```
/// # #![feature(try_trait_v2)]
/// # use std::ops::Try;
/// fn simple_try_fold_1<A, T, R: Try<Output = A>>(
///     iter: impl Iterator<Item = T>,
///     mut accum: A,
///     mut f: impl FnMut(A, T) -> R,
/// ) -> R {
///     todo!()
/// }
/// ```
///
/// If we get through the entire iterator, we need to wrap up the accumulator into the return type using [`Try::from_output`]: <br>如果我们遍历整个迭代器，我们需要使用 [`Try::from_output`] 将累加器包装成返回类型：<br>
///
/// ```
/// # #![feature(try_trait_v2)]
/// # use std::ops::{ControlFlow, Try};
/// fn simple_try_fold_2<A, T, R: Try<Output = A>>(
///     iter: impl Iterator<Item = T>,
///     mut accum: A,
///     mut f: impl FnMut(A, T) -> R,
/// ) -> R {
///     for x in iter {
///         let cf = f(accum, x).branch();
///         match cf {
///             ControlFlow::Continue(a) => accum = a,
///             ControlFlow::Break(_) => todo!(),
///         }
///     }
///     R::from_output(accum)
/// }
/// ```
///
/// We'll also need [`FromResidual::from_residual`] to turn the residual back into the original type. <br>我们还需要 [`FromResidual::from_residual`] 将 residual 恢复为原始类型。<br> But because it's a supertrait of `Try`, we don't need to mention it in the bounds. <br>但因为它是 `Try` 的一个 super trait，所以我们不必在界限内提及它。<br>
/// All types which implement `Try` can be recreated from their corresponding residual, so we'll just call it: <br>所有实现 `Try` 的类型都可以从它们对应的 residual 中重新创建，所以我们将调用它：<br>
///
/// ```
/// # #![feature(try_trait_v2)]
/// # use std::ops::{ControlFlow, Try};
/// pub fn simple_try_fold_3<A, T, R: Try<Output = A>>(
///     iter: impl Iterator<Item = T>,
///     mut accum: A,
///     mut f: impl FnMut(A, T) -> R,
/// ) -> R {
///     for x in iter {
///         let cf = f(accum, x).branch();
///         match cf {
///             ControlFlow::Continue(a) => accum = a,
///             ControlFlow::Break(r) => return R::from_residual(r),
///         }
///     }
///     R::from_output(accum)
/// }
/// ```
///
/// But this "call `branch`, then `match` on it, and `return` if it was a `Break`" is exactly what happens inside the `?` operator. <br>但是这个 "调用`branch`，然后在它上面进行 `match`，如果它是 `Break`，则 `return`" 正是在 `?` 操作符内部发生的事情。<br> So rather than do all this manually, we can just use `?` instead: <br>因此，我们可以使用 `?` 代替手动完成所有这些操作：<br>
///
/// ```
/// # #![feature(try_trait_v2)]
/// # use std::ops::Try;
/// fn simple_try_fold<A, T, R: Try<Output = A>>(
///     iter: impl Iterator<Item = T>,
///     mut accum: A,
///     mut f: impl FnMut(A, T) -> R,
/// ) -> R {
///     for x in iter {
///         accum = f(accum, x)?;
///     }
///     R::from_output(accum)
/// }
/// ```
///
///
///
///
///
///
///
#[unstable(feature = "try_trait_v2", issue = "84277")]
#[rustc_on_unimplemented(
    on(
        all(from_method = "from_output", from_desugaring = "TryBlock"),
        message = "a `try` block must return `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "could not wrap the final value of the block as `{Self}` doesn't implement `Try`",
    ),
    on(
        all(from_method = "branch", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "Try"]
pub trait Try: FromResidual {
    /// The type of the value produced by `?` when *not* short-circuiting. <br>当不短路时，`?` 产生的值的类型。<br>
    #[unstable(feature = "try_trait_v2", issue = "84277")]
    type Output;

    /// The type of the value passed to [`FromResidual::from_residual`] as part of `?` when short-circuiting. <br>短路时作为 `?` 的一部分传递给 [`FromResidual::from_residual`] 的值的类型。<br>
    ///
    /// This represents the possible values of the `Self` type which are *not* represented by the `Output` type. <br>这表示 `Self` 类型的可能值，而不是 `Output` 类型所表示的值。<br>
    ///
    /// # Note to Implementors <br>实现者注意<br>
    ///
    /// The choice of this type is critical to interconversion. <br>这种类型的选择对于相互转化至关重要。<br>
    /// Unlike the `Output` type, which will often be a raw generic type, this type is typically a newtype of some sort to "color" the type so that it's distinguishable from the residuals of other types. <br>与 `Output` 类型不同，它通常是原始泛型类型，这种类型通常是某种类型的 newtype 到 "color" 类型，以便与其他类型的 residual 区别开来。<br>
    ///
    /// This is why `Result<T, E>::Residual` is not `E`, but `Result<Infallible, E>`. <br>这就是为什么 `Result<T, E>::Residual` 不是 `E`，而是 `Result<Infallible, E>`。<br>
    /// That way it's distinct from `ControlFlow<E>::Residual`, for example, and thus `?` on `ControlFlow` cannot be used in a method returning `Result`. <br>例如，这样它就不同于 `ControlFlow<E>::Residual`，因此 `ControlFlow` 上的 `?` 不能用于返回 `Result` 的方法中。<br>
    ///
    /// If you're making a generic type `Foo<T>` that implements `Try<Output = T>`, then typically you can use `Foo<std::convert::Infallible>` as its `Residual` type: that type will have a "hole" in the correct place, and will maintain the "foo-ness" of the residual so other types need to opt-in to interconversion. <br>如果您正在创建实现 `Try<Output = T>` 的泛型 `Foo<T>`，那么通常您可以使用 `Foo<std::convert::Infallible>` 作为它的 `Residual` 类型：该类型将在正确位置有一个 "hole"，并将保留 residual 的 "foo-ness"，因此其他类型需要选择加入到相互转换中。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "try_trait_v2", issue = "84277")]
    type Residual;

    /// Constructs the type from its `Output` type. <br>从它的 `Output` 类型构造类型。<br>
    ///
    /// This should be implemented consistently with the `branch` method such that applying the `?` operator will get back the original value: `Try::from_output(x).branch() --> ControlFlow::Continue(x)`. <br>这应该与 `branch` 方法一致地实现，以便应用 `?` 运算符将返回原始值: `Try::from_output(x).branch() --> ControlFlow::Continue(x)`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_trait_v2)]
    /// use std::ops::Try;
    ///
    /// assert_eq!(<Result<_, String> as Try>::from_output(3), Ok(3));
    /// assert_eq!(<Option<_> as Try>::from_output(4), Some(4));
    /// assert_eq!(
    ///     <std::ops::ControlFlow<String, _> as Try>::from_output(5),
    ///     std::ops::ControlFlow::Continue(5),
    /// );
    ///
    /// # fn make_question_mark_work() -> Option<()> {
    /// assert_eq!(Option::from_output(4)?, 4);
    /// # None }
    /// # make_question_mark_work();
    ///
    /// // This is used, for example, on the accumulator in `try_fold`: <br>例如，这用于 `try_fold` 中的累加器：<br>
    /// let r = std::iter::empty().try_fold(4, |_, ()| -> Option<_> { unreachable!() });
    /// assert_eq!(r, Some(4));
    /// ```
    ///
    #[lang = "from_output"]
    #[unstable(feature = "try_trait_v2", issue = "84277")]
    fn from_output(output: Self::Output) -> Self;

    /// Used in `?` to decide whether the operator should produce a value (because this returned [`ControlFlow::Continue`]) or propagate a value back to the caller (because this returned [`ControlFlow::Break`]). <br>在 `?` 来决定操作符是应该生成一个值 (因为它返回了 [`ControlFlow::Continue`])，还是将一个值传播回调用者 (因为它返回了 [`ControlFlow::Break`])。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_trait_v2)]
    /// use std::ops::{ControlFlow, Try};
    ///
    /// assert_eq!(Ok::<_, String>(3).branch(), ControlFlow::Continue(3));
    /// assert_eq!(Err::<String, _>(3).branch(), ControlFlow::Break(Err(3)));
    ///
    /// assert_eq!(Some(3).branch(), ControlFlow::Continue(3));
    /// assert_eq!(None::<String>.branch(), ControlFlow::Break(None));
    ///
    /// assert_eq!(ControlFlow::<String, _>::Continue(3).branch(), ControlFlow::Continue(3));
    /// assert_eq!(
    ///     ControlFlow::<_, String>::Break(3).branch(),
    ///     ControlFlow::Break(ControlFlow::Break(3)),
    /// );
    /// ```
    ///
    ///
    #[lang = "branch"]
    #[unstable(feature = "try_trait_v2", issue = "84277")]
    fn branch(self) -> ControlFlow<Self::Residual, Self::Output>;
}

/// Used to specify which residuals can be converted into which [`crate::ops::Try`] types. <br>用于指定哪些残差可以转换为哪些 [`crate::ops::Try`] 类型。<br>
///
/// Every `Try` type needs to be recreatable from its own associated `Residual` type, but can also have additional `FromResidual` implementations to support interconversion with other `Try` types. <br>每个 `Try` 类型都需要从它自己关联的 `Residual` 类型重新创建，但也可以有额外的 `FromResidual` 实现来支持与其他 `Try` 类型的相互转换。<br>
///
///
#[rustc_on_unimplemented(
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::result::Result<T, E>",
            R = "std::option::Option<std::convert::Infallible>"
        ),
        message = "the `?` operator can only be used on `Result`s, not `Option`s, \
            in {ItemContext} that returns `Result`",
        label = "use `.ok_or(...)?` to provide an error compatible with `{Self}`",
        enclosing_scope = "this function returns a `Result`"
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::result::Result<T, E>",
        ),
        // There's a special error message in the trait selection code for `From` in `?`, so this is not shown for result-in-result errors, and thus it can be phrased more strongly than `ControlFlow`'s. <br>在 `?` 中 `From` 的 trait 选择代码中有一条特殊的错误消息，因此对于结果中的错误没有显示，因此它可以比 `ControlFlow` 更强烈地表达。<br>
        //
        //
        message = "the `?` operator can only be used on `Result`s \
            in {ItemContext} that returns `Result`",
        label = "this `?` produces `{R}`, which is incompatible with `{Self}`",
        enclosing_scope = "this function returns a `Result`"
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::option::Option<T>",
            R = "std::result::Result<T, E>",
        ),
        message = "the `?` operator can only be used on `Option`s, not `Result`s, \
            in {ItemContext} that returns `Option`",
        label = "use `.ok()?` if you want to discard the `{R}` error information",
        enclosing_scope = "this function returns an `Option`"
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::option::Option<T>",
        ),
        // `Option`-in-`Option` always works, as there's only one possible residual, so this can also be phrased strongly. <br>`Option`-in-`Option` 总是有效，因为只有一种可能的残差，所以这也可以用强烈的措辞表达。<br>
        //
        message = "the `?` operator can only be used on `Option`s \
            in {ItemContext} that returns `Option`",
        label = "this `?` produces `{R}`, which is incompatible with `{Self}`",
        enclosing_scope = "this function returns an `Option`"
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::ops::ControlFlow<B, C>",
            R = "std::ops::ControlFlow<B, C>",
        ),
        message = "the `?` operator in {ItemContext} that returns `ControlFlow<B, _>` \
            can only be used on other `ControlFlow<B, _>`s (with the same Break type)",
        label = "this `?` produces `{R}`, which is incompatible with `{Self}`",
        enclosing_scope = "this function returns a `ControlFlow`",
        note = "unlike `Result`, there's no `From`-conversion performed for `ControlFlow`"
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark",
            _Self = "std::ops::ControlFlow<B, C>",
            // `R` is not a `ControlFlow`, as that case was matched previously <br>`R` 不是 `ControlFlow`，因为以前匹配过这种情况<br>
        ),
        message = "the `?` operator can only be used on `ControlFlow`s \
            in {ItemContext} that returns `ControlFlow`",
        label = "this `?` produces `{R}`, which is incompatible with `{Self}`",
        enclosing_scope = "this function returns a `ControlFlow`",
    ),
    on(
        all(
            from_method = "from_residual",
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{FromResidual}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
)]
#[unstable(feature = "try_trait_v2", issue = "84277")]
pub trait FromResidual<R = <Self as Try>::Residual> {
    /// Constructs the type from a compatible `Residual` type. <br>从兼容的 `Residual` 类型构造类型。<br>
    ///
    /// This should be implemented consistently with the `branch` method such that applying the `?` operator will get back an equivalent residual: `FromResidual::from_residual(r).branch() --> ControlFlow::Break(r)`. <br>这应该与 `branch` 方法一致地实现，以便应用 `?` 运算符将返回等效的残差: `FromResidual::from_residual(r).branch() --> ControlFlow::Break(r)`。<br>
    ///
    /// (It must not be an *identical* residual when interconversion is involved.) <br>(当涉及相互转换时，它不能是*相同的*残差。)<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_trait_v2)]
    /// use std::ops::{ControlFlow, FromResidual};
    ///
    /// assert_eq!(Result::<String, i64>::from_residual(Err(3_u8)), Err(3));
    /// assert_eq!(Option::<String>::from_residual(None), None);
    /// assert_eq!(
    ///     ControlFlow::<_, String>::from_residual(ControlFlow::Break(5)),
    ///     ControlFlow::Break(5),
    /// );
    /// ```
    ///
    #[lang = "from_residual"]
    #[unstable(feature = "try_trait_v2", issue = "84277")]
    fn from_residual(residual: R) -> Self;
}
