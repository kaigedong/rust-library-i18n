use crate::marker::Unsize;

/// Trait that indicates that this is a pointer or a wrapper for one, where unsizing can be performed on the pointee. <br>一个 trait，指示这是一个指针或一个包装器，其中可以对指针调整大小。<br>
///
/// See the [DST coercion RFC][dst-coerce] and [the nomicon entry on coercion][nomicon-coerce] for more details. <br>有关更多详细信息，请参见 [DST 强制 RFC][dst-coerce] 和 [关于强制的 nomicon 入口][nomicon-coerce]。<br>
///
/// For builtin pointer types, pointers to `T` will coerce to pointers to `U` if `T: Unsize<U>` by converting from a thin pointer to a fat pointer. <br>对于内置指针类型，如果 `T: Unsize<U>` 通过从精简指针转换为胖指针，则指向 `T` 的指针将强制指向指向 `U` 的指针。<br>
///
/// For custom types, the coercion here works by coercing `Foo<T>` to `Foo<U>` provided an impl of `CoerceUnsized<Foo<U>> for Foo<T>` exists. <br>对于自定义类型，这里的强制通过将 `Foo<T>` 强制为 `Foo<U>` 来工作 (如果存在 `CoerceUnsized<Foo<U>> for Foo<T>` 的实现)。<br>
/// Such an impl can only be written if `Foo<T>` has only a single non-phantomdata field involving `T`. <br>仅当 `Foo<T>` 仅具有涉及 `T` 的单个非虚拟数据字段时，才可以写这样的 impl。<br>
/// If the type of that field is `Bar<T>`, an implementation of `CoerceUnsized<Bar<U>> for Bar<T>` must exist. <br>如果该字段的类型为 `Bar<T>`，则必须存在 `CoerceUnsized<Bar<U>> for Bar<T>` 的实现。<br>
/// The coercion will work by coercing the `Bar<T>` field into `Bar<U>` and filling in the rest of the fields from `Foo<T>` to create a `Foo<U>`. <br>coercion 将通过将 `Bar<T>` 字段强制转换为 `Bar<U>` 并填充 `Foo<T>` 的其余字段以创建 `Foo<U>` 来起作用。<br>
/// This will effectively drill down to a pointer field and coerce that. <br>这将有效地向下钻取指针字段并将其强制。<br>
///
/// Generally, for smart pointers you will implement `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, with an optional `?Sized` bound on `T` itself. <br>通常，对于智能指针，您将实现 `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`，并在 `T` 本身上绑定了可选的 `?Sized`。<br>
/// For wrapper types that directly embed `T` like `Cell<T>` and `RefCell<T>`, you can directly implement `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`. <br>对于直接嵌入 `T` 的包装器类型 (例如 `Cell<T>` 和 `RefCell<T>`)，您可以直接实现 `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`。<br>
///
/// This will let coercions of types like `Cell<Box<T>>` work. <br>这将使像 `Cell<Box<T>>` 这样的强制类型起作用。<br>
///
/// [`Unsize`][unsize] is used to mark types which can be coerced to DSTs if behind pointers. <br>[`Unsize`][unsize] 用于标记在指针后面可以强制转换为 DST 的类型。<br> It is implemented automatically by the compiler. <br>它由编译器自动实现。<br>
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T -> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T -> *mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T -> *mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// This is used for object safety, to check that a method's receiver type can be dispatched on. <br>这用于对象安全，以检查是否可以分派方法的接收者类型。<br>
///
/// An example implementation of the trait: <br>trait 的一个示例实现：<br>
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T -> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T -> *const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T -> *mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}
