use crate::marker::Unpin;
use crate::pin::Pin;

/// The result of a generator resumption. <br>恢复生成器的结果。<br>
///
/// This enum is returned from the `Generator::resume` method and indicates the possible return values of a generator. <br>该枚举从 `Generator::resume` 方法返回，并指示生成器的可能返回值。<br>
/// Currently this corresponds to either a suspension point (`Yielded`) or a termination point (`Complete`). <br>当前，这对应于悬挂点 (`Yielded`) 或终止点 (`Complete`)。<br>
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// The generator suspended with a value. <br>生成器挂起了一个值。<br>
    ///
    /// This state indicates that a generator has been suspended, and typically corresponds to a `yield` statement. <br>此状态表明生成器已被挂起，并且通常对应于 `yield` 语句。<br>
    /// The value provided in this variant corresponds to the expression passed to `yield` and allows generators to provide a value each time they yield. <br>该变体中提供的值对应于传递给 `yield` 的表达式，并允许生成器在每次产生时提供一个值。<br>
    ///
    ///
    Yielded(Y),

    /// The generator completed with a return value. <br>生成器完成并返回一个值。<br>
    ///
    /// This state indicates that a generator has finished execution with the provided value. <br>此状态表明生成器已使用提供的值完成了执行。<br>
    /// Once a generator has returned `Complete` it is considered a programmer error to call `resume` again. <br>生成器返回 `Complete` 后，再次调用 `resume` 将被视为程序员错误。<br>
    ///
    Complete(R),
}

/// The trait implemented by builtin generator types. <br>由内置生成器类型实现的 trait。<br>
///
/// Generators, also commonly referred to as coroutines, are currently an experimental language feature in Rust. <br>生成器，通常也称为协程，目前是 Rust 中的一个实验性语言特性。<br>
/// Added in [RFC 2033] generators are currently intended to primarily provide a building block for async/await syntax but will likely extend to also providing an ergonomic definition for iterators and other primitives. <br>[RFC 2033] 中添加的生成器目前主要用于为 async/await 语法提供构建块，但可能会扩展为还为迭代器和其他原语提供符合人体工程学的定义。<br>
///
///
/// The syntax and semantics for generators is unstable and will require a further RFC for stabilization. <br>生成器的语法和语义不稳定，将需要进一步的 RFC 来稳定。<br> At this time, though, the syntax is closure-like: <br>但是，此时的语法类似于闭包：<br>
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// More documentation of generators can be found in the unstable book. <br>在不稳定的书中可以找到有关生成器的更多文档。<br>
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// The type of value this generator yields. <br>此生成器产生的值的类型。<br>
    ///
    /// This associated type corresponds to the `yield` expression and the values which are allowed to be returned each time a generator yields. <br>此关联类型对应于 `yield` 表达式以及每次生成器产生时都允许返回的值。<br>
    ///
    /// For example an iterator-as-a-generator would likely have this type as `T`, the type being iterated over. <br>例如，作为一个迭代器的迭代器可能将这种类型作为 `T` 进行迭代。<br>
    ///
    type Yield;

    /// The type of value this generator returns. <br>此生成器返回的值的类型。<br>
    ///
    /// This corresponds to the type returned from a generator either with a `return` statement or implicitly as the last expression of a generator literal. <br>这对应于使用 `return` 语句从生成器返回的类型，或隐式作为生成器字面量的最后一个表达式返回的类型。<br>
    /// For example futures would use this as `Result<T, E>` as it represents a completed future. <br>例如，futures 将其用作 `Result<T, E>`，因为它代表完整的 future。<br>
    ///
    ///
    #[cfg_attr(not(bootstrap), lang = "generator_return")]
    type Return;

    /// Resumes the execution of this generator. <br>恢复此生成器的执行。<br>
    ///
    /// This function will resume execution of the generator or start execution if it hasn't already. <br>此函数将恢复生成器的执行，如果尚未生成，则开始执行。<br>
    /// This call will return back into the generator's last suspension point, resuming execution from the latest `yield`. <br>该调用将返回到生成器的最后一个暂停点，从最新的 `yield` 恢复执行。<br>
    /// The generator will continue executing until it either yields or returns, at which point this function will return. <br>生成器将继续执行，直到它产生或返回，此时该函数将返回。<br>
    ///
    /// # Return value <br>返回值<br>
    ///
    /// The `GeneratorState` enum returned from this function indicates what state the generator is in upon returning. <br>从此函数返回的 `GeneratorState` 枚举指示生成器在返回时处于什么状态。<br>
    /// If the `Yielded` variant is returned then the generator has reached a suspension point and a value has been yielded out. <br>如果返回了 `Yielded` 变体，则生成器已达到暂停点，并且已产生一个值。<br>
    /// Generators in this state are available for resumption at a later point. <br>此状态下的生成器可在稍后恢复。<br>
    ///
    /// If `Complete` is returned then the generator has completely finished with the value provided. <br>如果返回 `Complete`，则生成器将完全完成所提供的值。<br> It is invalid for the generator to be resumed again. <br>再次恢复生成器是无效的。<br>
    ///
    /// # Panics
    ///
    /// This function may panic if it is called after the `Complete` variant has been returned previously. <br>如果先前已返回 `Complete` 变体后调用此函数，就可能会出现 panic。<br>
    /// While generator literals in the language are guaranteed to panic on resuming after `Complete`, this is not guaranteed for all implementations of the `Generator` trait. <br>尽管在 `Complete` 之后恢复时，将语言中的生成器字面量保证为 panic，但对于 `Generator` trait 的所有实现均不能保证。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}
