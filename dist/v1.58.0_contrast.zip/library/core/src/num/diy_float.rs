//! Extended precision "soft float", for internal use only. <br>扩展精度 "soft float"，仅供内部使用。<br>

// This module is only for dec2flt and flt2dec, and only public because of coretests. <br>该模块仅用于 dec2flt 和 flt2dec，并且由于 coretests 而仅用于公共模块。<br>
// It is not intended to ever be stabilized. <br>它永远都不会稳定下来。<br>
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// A custom 64-bit floating point type, representing `f * 2^e`. <br>自定义的 64 位浮点类型，表示 `f * 2^e`。<br>
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// The integer mantissa. <br>整数尾数。<br>
    pub f: u64,
    /// The exponent in base 2. <br>以 2 为底的指数。<br>
    pub e: i16,
}

impl Fp {
    /// Returns a correctly rounded product of itself and `other`. <br>返回其自身和 `other` 的正确舍入乘积。<br>
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// Normalizes itself so that the resulting mantissa is at least `2^63`. <br>对其自身进行规范化，以使所得的尾数至少为 `2^63`。<br>
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 << 63));
        Fp { f, e }
    }

    /// Normalizes itself to have the shared exponent. <br>标准化自己以具有共享指数。<br>
    /// It can only decrease the exponent (and thus increase the mantissa). <br>它只能减少指数 (从而增加尾数)。<br>
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}
