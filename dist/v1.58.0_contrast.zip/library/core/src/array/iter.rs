//! Defines the `IntoIter` owned iterator for arrays. <br>为数组定义 `IntoIter` 拥有的迭代器。<br>

use crate::{
    fmt,
    iter::{self, ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A by-value [array] iterator. <br>一个按值的 [array] 迭代器。<br>
#[stable(feature = "array_value_iter", since = "1.51.0")]
#[rustc_insignificant_dtor]
pub struct IntoIter<T, const N: usize> {
    /// This is the array we are iterating over. <br>这是我们要遍历的数组。<br>
    ///
    /// Elements with index `i` where `alive.start <= i < alive.end` have not been yielded yet and are valid array entries. <br>索引为 `i` 的元素 (尚未生成 `alive.start <= i < alive.end`) 是有效的数组条目。<br>
    /// Elements with indices `i < alive.start` or `i >= alive.end` have been yielded already and must not be accessed anymore! <br>索引为 `i < alive.start` 或 `i >= alive.end` 的元素已经产生，不能再访问了！<br> Those dead elements might even be in a completely uninitialized state! <br>那些死元素甚至可能处于完全未初始化的状态！<br>
    ///
    ///
    /// So the invariants are: <br>因此，不变量是：<br>
    /// - `data[alive]` is alive (i.e. contains valid elements) <br>`data[alive]` 是活动的 (即包含有效元素)<br>
    /// - `data[..alive.start]` and `data[alive.end..]` are dead (i.e. the elements were already read and must not be touched anymore!) <br>`data[..alive.start]` 和 `data[alive.end..]` 已经失效 (即元素已被读取，不能再被触碰！)<br>
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// The elements in `data` that have not been yielded yet. <br>`data` 中尚未产生的元素。<br>
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Creates a new iterator over the given `array`. <br>在给定的 `array` 上创建一个新的迭代器。<br>
    ///
    /// *Note*: this method might be deprecated in the future, since [`IntoIterator`] is now implemented for arrays. <br>这种方法将来可能会被弃用，因为现在已经为数组实现了 [`IntoIterator`]。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // The type of `value` is an `i32` here, instead of `&i32` <br>这里 `value` 的类型是 `i32`，而不是 `&i32`<br>
    ///     let _: i32 = value;
    /// }
    ///
    /// // Since Rust 1.53, arrays implement IntoIterator directly: <br>从 Rust 1.53 开始，数组直接实现了 IntoIterator：<br>
    /// for value in [1, 2, 3, 4, 5] {
    ///     // The type of `value` is an `i32` here, instead of `&i32` <br>这里 `value` 的类型是 `i32`，而不是 `&i32`<br>
    ///     let _: i32 = value;
    /// }
    /// ```
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: The transmute here is actually safe. <br>此处的转换实际上是安全的。<br> The docs of `MaybeUninit` promise: <br>`MaybeUninit` promise 的文档：<br>
        //
        // > `MaybeUninit<T>` is guaranteed to have the same size and alignment <br>`MaybeUninit<T>` 保证具有相同的大小和对齐方式<br>
        // > as `T`. <br>作为 `T`。<br>
        //
        // The docs even show a transmute from an array of `MaybeUninit<T>` to an array of `T`. <br>该文档甚至显示了从 `MaybeUninit<T>` 数组到 `T` 数组的转换。<br>
        //
        //
        // With that, this initialization satisfies the invariants. <br>这样，该初始化就满足了不变性。<br>
        //

        // FIXME(LukasKalbertodt): actually use `mem::transmute` here, once it works with const generics:     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)` <br>在这里实际使用 `mem::transmute`，一旦它与 const 泛型一起工作: `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`<br>
        //
        //
        // Until then, we can use `mem::transmute_copy` to create a bitwise copy as a different type, then forget `array` so that it is not dropped. <br>在此之前，我们可以使用 `mem::transmute_copy` 创建不同类型的按位副本，然后忘记 `array`，这样它就不会被丢弃。<br>
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Returns an immutable slice of all elements that have not been yielded yet. <br>返回尚未产生的所有元素的不可变切片。<br>
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: We know that all elements within `alive` are properly initialized. <br>我们知道 `alive` 中的所有元素都已正确初始化。<br>
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returns a mutable slice of all elements that have not been yielded yet. <br>返回尚未生成的所有元素的可变切片。<br>
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: We know that all elements within `alive` are properly initialized. <br>我们知道 `alive` 中的所有元素都已正确初始化。<br>
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Get the next index from the front. <br>从前面获取下一个索引。<br>
        //
        // Increasing `alive.start` by 1 maintains the invariant regarding `alive`. <br>`alive.start` 增加 1 将保持 `alive` 的不变性。<br>
        // However, due to this change, for a short time, the alive zone is not `data[alive]` anymore, but `data[idx..alive.end]`. <br>但是，由于此更改，在短时间内，活动区域不再是 `data[alive]`，而是 `data[idx..alive.end]`。<br>
        //
        self.alive.next().map(|idx| {
            // Read the element from the array. <br>从数组中读取元素。<br>
            // SAFETY: `idx` is an index into the former "alive" region of the array. <br>`idx` 是数组前 "alive" 区域的索引。<br>
            // Reading this element means that `data[idx]` is regarded as dead now (i.e. <br>读取此元素意味着 `data[idx]` 现在被视为已失效 (即<br>
            // do not touch). <br>请勿触摸)。<br>
            // As `idx` was the start of the alive-zone, the alive zone is now `data[alive]` again, restoring all invariants. <br>由于 `idx` 是活动区域的开始，因此活动区域现在又是 `data[alive]`，恢复了所有不变量。<br>
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    #[inline]
    fn fold<Acc, Fold>(mut self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let data = &mut self.data;
        self.alive.by_ref().fold(init, |acc, idx| {
            // SAFETY: idx is obtained by folding over the `alive` range, which implies the value is currently considered alive but as the range is being consumed each value we read here will only be read once and then considered dead. <br>idx 是通过折叠 `alive` 范围获得的，这意味着该值当前被认为是活动的，但是随着范围被消耗，我们在这里读取的每个值只会被读取一次，然后被认为是死的。<br>
            //
            //
            fold(acc, unsafe { data.get_unchecked(idx).assume_init_read() })
        })
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Get the next index from the back. <br>从后面获取下一个索引。<br>
        //
        // Decreasing `alive.end` by 1 maintains the invariant regarding `alive`. <br>`alive.end` 减 1 保持 `alive` 不变。<br>
        // However, due to this change, for a short time, the alive zone is not `data[alive]` anymore, but `data[alive.start..=idx]`. <br>但是，由于此更改，在短时间内，活动区域不再是 `data[alive]`，而是 `data[alive.start..=idx]`。<br>
        //
        self.alive.next_back().map(|idx| {
            // Read the element from the array. <br>从数组中读取元素。<br>
            // SAFETY: `idx` is an index into the former "alive" region of the array. <br>`idx` 是数组前 "alive" 区域的索引。<br>
            // Reading this element means that `data[idx]` is regarded as dead now (i.e. <br>读取此元素意味着 `data[idx]` 现在被视为已失效 (即<br>
            // do not touch). <br>请勿触摸)。<br>
            // As `idx` was the end of the alive-zone, the alive zone is now `data[alive]` again, restoring all invariants. <br>由于 `idx` 是活动区域的结尾，因此活动区域现在又是 `data[alive]`，还原了所有不变量。<br>
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: This is safe: `as_mut_slice` returns exactly the sub-slice of elements that have not been moved out yet and that remain to be dropped. <br>这是安全的: `as_mut_slice` 精确地返回尚未移出但仍要丢弃的元素的子切片。<br>
        //
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Will never underflow due to the invariant `alive.start <= alive.end`. <br>不会因 `alive.start <= alive.end` 不变而下溢。<br>
        //
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// The iterator indeed reports the correct length. <br>迭代器确实报告了正确的长度。<br>
// The number of "alive" elements (that will still be yielded) is the length of the range `alive`. <br>"alive" 元素的数量 (仍将产生) 是 `alive` 范围的长度。<br>
// This range is decremented in length in either `next` or `next_back`. <br>在 `next` 或 `next_back` 中，此范围的长度减小。<br>
// It is always decremented by 1 in those methods, but only if `Some(_)` is returned. <br>在这些方法中，它总是减 1，但前提是要返回 `Some(_)`。<br>
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Note, we don't really need to match the exact same alive range, so we can just clone into offset 0 regardless of where `self` is. <br>注意，我们实际上并不需要完全匹配相同的有效范围，因此无论 `self` 在哪里，我们都可以克隆到偏移量 0 中。<br>
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone all alive elements. <br>克隆所有活动元素。<br>
        for (src, dst) in iter::zip(self.as_slice(), &mut new.data) {
            // Write a clone into the new array, then update its alive range. <br>将克隆写入新阵列，然后更新其有效范围。<br>
            // If cloning panics, we'll correctly drop the previous items. <br>如果克隆发生 panics，我们将正确丢弃前一个项。<br>
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Only print the elements that were not yielded yet: we cannot access the yielded elements anymore. <br>只打印尚未产生的元素：我们不能再访问产生的元素。<br>
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}
