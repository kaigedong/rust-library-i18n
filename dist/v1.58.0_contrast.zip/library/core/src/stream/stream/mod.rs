use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// An interface for dealing with asynchronous iterators. <br>用于处理异步迭代器的接口。<br>
///
/// This is the main stream trait. <br>这是主流 trait。<br>
/// For more about the concept of streams generally, please see the [module-level documentation]. <br>有关一般的流概念的更多信息，请参见 [模块级文档][module-level documentation]。<br>
/// In particular, you may want to know how to [implement `Stream`][impl]. <br>特别是，您可能想知道如何 [实现 `Stream`][impl]。<br>
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// The type of items yielded by the stream. <br>流产生的项的类型。<br>
    type Item;

    /// Attempt to pull out the next value of this stream, registering the current task for wakeup if the value is not yet available, and returning `None` if the stream is exhausted. <br>尝试拉出该流的下一个值，如果该值尚不可用，则注册当前任务以进行唤醒，如果流已用尽，则返回 `None`。<br>
    ///
    /// # Return value <br>返回值<br>
    ///
    /// There are several possible return values, each indicating a distinct stream state: <br>有几个可能的返回值，每个返回值指示不同的流状态：<br>
    ///
    /// - `Poll::Pending` means that this stream's next value is not ready yet. <br>`Poll::Pending` 意味着这个流的下一个值还没有准备好。<br> Implementations will ensure that the current task will be notified when the next value may be ready. <br>实现将确保在准备好下一个值时将通知当前任务。<br>
    ///
    /// - `Poll::Ready(Some(val))` means that the stream has successfully produced a value, `val`, and may produce further values on subsequent `poll_next` calls. <br>`Poll::Ready(Some(val))` 表示流已成功生成值 `val`，并且可能会在后续 `poll_next` 调用中生成更多值。<br>
    ///
    /// - `Poll::Ready(None)` means that the stream has terminated, and `poll_next` should not be invoked again. <br>`Poll::Ready(None)` 表示流已终止，不应再次调用 `poll_next`。<br>
    ///
    /// # Panics
    ///
    /// Once a stream has finished (returned `Ready(None)` from `poll_next`), calling its `poll_next` method again may panic, block forever, or cause other kinds of problems; <br>流完成后 (从 `poll_next` 返回 `Ready(None)`)，再次调用其 `poll_next` 方法可能会 panic，永远阻塞或引起其他类型的问题。<br> the `Stream` trait places no requirements on the effects of such a call. <br>`Stream` trait 对这种调用的效果没有任何要求。<br>
    ///
    /// However, as the `poll_next` method is not marked `unsafe`, Rust's usual rules apply: calls must never cause undefined behavior (memory corruption, incorrect use of `unsafe` functions, or the like), regardless of the stream's state. <br>但是，由于 `poll_next` 方法未标记为 `unsafe`，因此适用 Rust 的通常规则：调用决不能引起未定义的行为 (内存损坏，对 `unsafe` 函数的错误使用等)，而与流的状态无关。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Returns the bounds on the remaining length of the stream. <br>返回流剩余长度上的边界。<br>
    ///
    /// Specifically, `size_hint()` returns a tuple where the first element is the lower bound, and the second element is the upper bound. <br>具体来说，`size_hint()` 返回一个元组，其中第一个元素是下界，第二个元素是上界。<br>
    ///
    /// The second half of the tuple that is returned is an <code>[Option]<[usize]></code>. <br>返回的元组的后半部分是 <code>[Option]<[usize]></code>。<br>
    /// A [`None`] here means that either there is no known upper bound, or the upper bound is larger than [`usize`]. <br>这里的 [`None`] 表示没有已知的上限，或者该上限大于 [`usize`]。<br>
    ///
    /// # Implementation notes <br>实现说明<br>
    ///
    /// It is not enforced that a stream implementation yields the declared number of elements. <br>流实现不会产生声明数量的元素，这不是强制性的。<br> A buggy stream may yield less than the lower bound or more than the upper bound of elements. <br>buggy 流产生的值可能小于元素的下限，也可能大于元素的上限。<br>
    ///
    /// `size_hint()` is primarily intended to be used for optimizations such as reserving space for the elements of the stream, but must not be trusted to e.g., omit bounds checks in unsafe code. <br>`size_hint()` 主要用于优化，例如为流的元素保留空间，但不能被信任，例如省略不安全代码中的边界检查。<br>
    /// An incorrect implementation of `size_hint()` should not lead to memory safety violations. <br>`size_hint()` 的不正确实现不应导致违反内存安全性。<br>
    ///
    /// That said, the implementation should provide a correct estimation, because otherwise it would be a violation of the trait's protocol. <br>也就是说，该实现应提供正确的估计，因为否则将违反 trait 的协议。<br>
    ///
    /// The default implementation returns <code>(0, [None])</code> which is correct for any stream. <br>默认实现返回了 <code>(0, [None])</code>，这对于任何流都是正确的。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}
