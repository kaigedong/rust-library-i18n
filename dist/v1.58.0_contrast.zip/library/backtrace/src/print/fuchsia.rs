use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr takes a callback that will receive a dl_phdr_info pointer for every DSO that has been linked into the process. <br>dl_iterate_phdr 进行回调，该回调将为已链接到该进程的每个 DSO 接收 dl_phdr_info 指针。<br>
    // dl_iterate_phdr also ensures that the dynamic linker is locked from start to finish of the iteration. <br>dl_iterate_phdr 还可以确保动态链接器从迭代的开始到结束都被锁定。<br>
    // If the callback returns a non-zero value the iteration is terminated early. <br>如果回调返回非零值，则迭代会提前终止。<br>
    // 'data' will be passed as the third argument to the callback on each call. <br>'data' 将作为第三个参数在每次调用时传递给回调函数。<br>
    // 'size' gives the size of the dl_phdr_info. <br>'size' 给出了 dl_phdr_info 的大小。<br>
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// We need to parse out the build ID and some basic program header data which means that we need a bit of stuff from the ELF spec as well. <br>我们需要解析出构建 ID 和一些基本程序头数据，这意味着我们也需要 ELF 规范中的一些内容。<br>
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Now we have to replicate, bit for bit, the structure of the dl_phdr_info type used by fuchsia's current dynamic linker. <br>现在，我们必须一点一点地复制 Fuchsia 的当前动态链接器使用的 dl_phdr_info 类型的结构体。<br>
// Chromium also has this ABI boundary as well as crashpad. <br>Chromium 也具有此 ABI 边界以及崩溃垫。<br>
// Eventully we'd like to move these cases to use elf-search but we'd need to provide that in the SDK and that has not yet been done. <br>最终，我们希望将这些案例移至使用 elf-search，但我们需要在 SDK 中提供它，但尚未完成。<br>
//
// Thus we (and they) are stuck having to use this method which incurs a tight coupling with the fuchsia libc. <br>因此，我们 (和他们) 不得不使用此方法，而该方法会导致与 Fuchsia libc 紧密耦合。<br>
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // We have no way of knowing of checking if e_phoff and e_phnum are valid. <br>我们无法知道检查 e_phoff 和 e_phnum 是否有效。<br>
    // libc should ensure this for us however so it's safe to form a slice here. <br>libc 应该为我们确保这一点，因此在这里形成切片是安全的。<br>
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr represents a 64-bit ELF program header in the endianness of the target architecture. <br>Elf_Phdr 以目标体系结构的字节序表示一个 64 位的 ELF 程序头。<br>
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr represents a valid ELF program header and its contents. <br>Phdr 表示有效的 ELF 程序标头及其内容。<br>
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // We have no way of checking if p_addr or p_memsz are valid. <br>我们无法检查 p_addr 或 p_memsz 是否有效。<br>
    // Fuchsia's libc parses the notes first however so by virtue of being here these headers must be valid. <br>Fuchsia 的 libc 首先解析了 note，因此这些 header 既然出现在这里，就一定是有效的。<br>
    //
    // NoteIter does not require the underlying data to be valid but it does require the bounds to be valid. <br>注意 Iter 不需要底层数据有效，但是它要求边界有效。<br>
    // We trust that libc has ensured that this is the case for us here. <br>我们相信 libc 确保在这里对我们而言就是这种情况。<br>
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// The note type for build IDs. <br>构建 ID 的 note 类型。<br>
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr represents an ELF note header in the endianness of the target. <br>Elf_Nhdr 表示目标字节序中的 ELF note 头。<br>
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note represents an ELF note (header + contents). <br>Note 表示 ELF note (标题 + 内容)。<br>
// The name is left as a u8 slice because it is not always null terminated and rust makes it easy enough to check that the bytes match eitherway. <br>该名称保留为 u8 切片，因为它并不总是以 null 结尾，并且 rust 使得检查字节是否匹配仍然足够容易。<br>
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter lets you safely iterate over a note segment. <br>NoteIter 使您可以安全地遍历笔记段。<br>
// It terminates as soon as an error occurs or there are no more notes. <br>一旦发生错误或没有更多 note，它将终止。<br>
// If you iterate over invalid data it will function as though no notes were found. <br>如果您遍历无效数据，它将像没有找到 note 的情况一样起作用。<br>
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // It is an invariant of function that the pointer and size given denote a valid range of bytes that can all be read. <br>给定的指针和大小表示可以读取的有效字节范围，这是函数的一个不变量。<br>
    // The contents of these bytes can be anything but the range must be valid for this to be safe. <br>这些字节的内容可以是任何东西，但范围必须是有效的，以确保安全。<br>
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment assuming 'to' is a power of 2. <br>假设 '`to` 为 2 的幂，align_to 将 'x' 对齐为 `to` 字节对齐。<br>
// This follows a standard pattern in C/C++ ELF parsing code where (x + to - 1) & -to is used. <br>这遵循 C/C++ ELF 解析代码中的标准模式，其中使用 (x + 到 - 1) &-to。<br>
// Rust does not let you negate usize so I use <br>Rust 不允许您否定 usize，所以我用<br>
// 2's-complement conversion to recreate that. <br>2 的补码转换来重新创建它。<br>
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consumes num bytes from the slice (if present) and additionally ensures that the final slice is properlly aligned. <br>take_bytes_align4 从切片 (如果存在) 中消耗 num 个字节，并另外确保最终切片正确对齐。<br>
// If an either the number of bytes requested is too large or the slice can't be realigned afterwards due to not enough remaining bytes existing, None is returned and the slice is not modified. <br>如果请求的字节数太大或由于剩余字节数不足而无法在之后重新对齐切片，则将返回 None 且不对切片进行修改。<br>
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// This function has no real invariants the caller must uphold other than perhaps that 'bytes' should be aligned for performance (and on some architectures correctness). <br>这个函数没有调用者必须维护的真正的不变量，除了 'bytes' 应该针对性能 (以及某些体系结构的正确性) 进行对齐之外。<br>
// The values in the Elf_Nhdr fields might be nonsense but this function ensures no such thing. <br>Elf_Nhdr 字段中的值可能是无意义的，但此函数可确保不会出现这种情况。<br>
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // This is safe as long as there is enough space and we just confirmed that in the if statement above so this should not be unsafe. <br>只要有足够的空间，这是安全的，并且我们只是在上面的 if 语句中确认了这一点，所以这应该不是不安全的。<br>
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Note that sice_of::<Elf_Nhdr>() is always 4-byte aligned. <br>请注意 sice_of::<Elf_Nhdr> () 始终 4 字节对齐。<br>
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Check if we've reached the end. <br>检查我们是否到达终点。<br>
        if self.base.len() == 0 || self.error {
            return None;
        }
        // We transmute out an nhdr but we carefully consider the resulting struct. <br>我们转换了 nhdr，但我们仔细考虑了生成的结构体。<br>
        // We don't trust the namesz or descsz and we make no unsafe decisions based on the type. <br>我们不信任 namez 或 descsz，也不会根据类型做出不安全的决定。<br>
        //
        // So even if we get out complete garbage we should still be safe. <br>因此，即使我们丢掉了完整的垃圾，我们仍然应该是安全的。<br>
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indicates that a segment is executable. <br>指示段是可执行的。<br>
const PERM_X: u32 = 0b00000001;
/// Indicates that a segment is writable. <br>指示段是可写的。<br>
const PERM_W: u32 = 0b00000010;
/// Indicates that a segment is readable. <br>指示段是可读的。<br>
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Represents an ELF segment at runtime. <br>表示运行时的 ELF 段。<br>
struct Segment {
    /// Gives the runtime virtual address of this segment's contents. <br>提供此段内容的运行时虚拟地址。<br>
    addr: usize,
    /// Gives the memory size of this segment's contents. <br>给出此段内容的内存大小。<br>
    size: usize,
    /// Gives the module virtual address of this segment with the ELF file. <br>使用 ELF 文件为该段提供模块的虚拟地址。<br>
    mod_rel_addr: usize,
    /// Gives the permissions found in the ELF file. <br>提供在 ELF 文件中找到的权限。<br>
    /// These permissions are not necessarily the permissions present at runtime however. <br>但是，这些权限不一定是运行时存在的权限。<br>
    flags: Perm,
}

/// Lets one iterate over Segments from a DSO. <br>让一个 DSO 遍历细分。<br>
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Represents an ELF DSO (Dynamic Shared Object). <br>表示 ELF DSO (动态共享对象)。<br>
/// This type references the data stored in the actual DSO rather than making its own copy. <br>此类型引用存储在实际 DSO 中的数据，而不是制作其自己的副本。<br>
struct Dso<'a> {
    /// The dynamic linker always gives us a name, even if the name is empty. <br>即使名称为空，动态链接器也始终为我们提供一个名称。<br>
    /// In the case of the main executable this name will be empty. <br>对于主可执行文件，此名称将为空。<br>
    /// In the case of a shared object it will be the soname (see DT_SONAME). <br>如果是共享的对象，则为 soname (请参见 DT_SONAME)。<br>
    name: &'a str,
    /// On Fuchsia virtually all binaries have build IDs but this is not a strict requierment. <br>在 Fuchsia 上，几乎所有的二进制文件都有构建 ID，但这并不是一个严格的要求。<br>
    /// There's no way to match up DSO information with a real ELF file afterwards if there is no build_id so we require that every DSO have one here. <br>如果没有 build_id，那么以后就无法将 DSO 信息与真实的 ELF 文件进行匹配，因此我们要求每个 DSO 在此处都具有一个。<br>
    ///
    /// DSO's without a build_id are ignored. <br>没有 build_id 的 DSO 将被忽略。<br>
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Returns an iterator over Segments in this DSO. <br>返回此 DSO 中的细分上的迭代器。<br>
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// These errors encode issues that arise while parsing information about each DSO. <br>这些错误编码了在解析有关每个 DSO 的信息时出现的问题。<br>
///
enum Error {
    /// NameError means that an error occurred while converting a C style string into a rust string. <br>NameError 表示将 C 样式字符串转换为 rust 字符串时发生错误。<br>
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError means that we didn't find a build ID. <br>BuildIDError 表示我们找不到构建 ID。<br>
    /// This could either be because the DSO had no build ID or because the segment containing the build ID was malformed. <br>这可能是因为 DSO 没有构建 ID，或者是因为包含构建 ID 的段格式错误。<br>
    ///
    BuildIDError,
}

/// Calls either 'dso' or 'error' for each DSO linked into the process by the dynamic linker. <br>对于由动态链接器链接到进程的每个 DSO，调用 'dso' 或 'error'。<br>
///
///
/// # Arguments
///
/// * `visitor` - A DsoPrinter that will have one of eats methods called foreach DSO. <br>`visitor` - 一个 DsoPrinter，它将拥有一种称为 foreach DSO 的 Eats 方法。<br>
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ensures that info.name will point to a valid location. <br>dl_iterate_phdr 确保 info.name 指向有效位置。<br>
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// This function prints the Fuchsia symbolizer markup for all information contained in a DSO. <br>此函数为 DSO 中包含的所有信息打印 Fuchsia 符号器标记。<br>
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}
