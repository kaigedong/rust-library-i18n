//! Implementation of Rust panics via process aborts <br>通过进程中止实现 Rust panics<br>
//!
//! When compared to the implementation via unwinding, this crate is *much* simpler! <br>与通过展开的实现相比，此 crate 简单得多！<br> That being said, it's not quite as versatile, but here goes! <br>话虽这么说，它不是很通用，但是可以了！<br>
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/")]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]
#![feature(c_unwind)]

#[cfg(target_os = "android")]
mod android;

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" the payload and shim to the relevant abort on the platform in question. <br>将有效载荷和 shim 泄漏到相关平台上的相关中止。<br>
#[rustc_std_internal_symbol]
pub unsafe extern "C-unwind" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    // Android has the ability to attach a message as part of the abort. <br>Android 有能力附加一条消息作为中止的一部分。<br>
    #[cfg(target_os = "android")]
    android::android_set_abort_message(_payload);

    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            target_os = "solid_asp3",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // call std::sys::abort_internal <br>调用 std::sys::abort_internal<br>
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // On Windows, use the processor-specific __fastfail mechanism. <br>在 Windows 上，使用特定于处理器的 __fastfail 机制。<br> In Windows 8 and later, this will terminate the process immediately without running any in-process exception handlers. <br>在 Windows 8 和更高版本中，这将立即终止进程，而无需运行任何进程内异常处理程序。<br>
            // In earlier versions of Windows, this sequence of instructions will be treated as an access violation, terminating the process but without necessarily bypassing all exception handlers. <br>在 Windows 的早期版本中，此指令序列将被视为访问冲突，从而终止进程，但不必绕过所有异常处理程序。<br>
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: this is the same implementation as in libstd's `abort_internal` <br>这与 libstd `abort_internal` 中的实现相同<br>
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// This... is a bit of an oddity. <br>这... 有点奇怪。<br> The tl;dr;  is that this is required to link correctly, the longer explanation is below. <br>这是正确链接所必需的，下面将给出更详细的解释。<br>
//
// Right now the binaries of libcore/libstd that we ship are all compiled with `-C panic=unwind`. <br>现在，我们出厂的 libcore/libstd 二进制文件都已用 `-C panic=unwind` 编译。<br> This is done to ensure that the binaries are maximally compatible with as many situations as possible. <br>这样做是为了确保二进制文件最大程度地与尽可能多的情况兼容。<br>
// The compiler, however, requires a "personality function" for all functions compiled with `-C panic=unwind`. <br>但是，对于使用 `-C panic=unwind` 编译的所有函数，编译器都需要 "personality function"。<br> This personality function is hardcoded to the symbol `rust_eh_personality` and is defined by the `eh_personality` lang item. <br>这个 personality 函数被硬编码为符号 `rust_eh_personality`，并由 `eh_personality` lang 项定义。<br>
//
// So...
// why not just define that lang item here? <br>为什么不在这里定义该 lang 项？<br> Good question! <br>好问题！<br> The way that panic runtimes are linked in is actually a little subtle in that they're "sort of" in the compiler's crate store, but only actually linked if another isn't actually linked. <br>panic 运行时的链接方式实际上有点微妙，因为它们某种程度上在编译器的 crate 存储中，但是只有在另一个没有被链接的情况下才会被链接。<br>
//
// This ends up meaning that both this crate and the panic_unwind crate can appear in the compiler's crate store, and if both define the `eh_personality` lang item then that'll hit an error. <br>结束意味着这 crate 和 panic_unwind crate 都可以出现在编译器的 crate 存储中，如果两者都定义了 `eh_personality` lang 项，那么将报错。<br>
//
// To handle this the compiler only requires the `eh_personality` is defined if the panic runtime being linked in is the unwinding runtime, and otherwise it's not required to be defined (rightfully so). <br>要解决此问题，如果链接到的 panic 运行时是展开运行时，则仅要求定义 `eh_personality`，否则就不需要定义 (正确地如此)。<br>
// In this case, however, this library just defines this symbol so there's at least some personality somewhere. <br>但是，在这种情况下，这个库只是定义了这个符号，所以在某些地方至少有一些 personality。<br>
//
// Essentially this symbol is just defined to get wired up to libcore/libstd binaries, but it should never be called as we don't link in an unwinding runtime at all. <br>本质上，此符号只是为了连接到 libcore/libstd 二进制文件而定义的，但由于我们根本不在展开运行时中链接，因此永远不应调用它。<br>
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_family = "wasm", not(target_os = "emscripten")),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // On x86_64-pc-windows-gnu we use our own personality function that needs to return `ExceptionContinueSearch` as we're passing on all our frames. <br>在 x86_64-pc-windows-gnu 上，我们使用自己的 personality 函数，当我们传递所有帧时，该函数需要返回 `ExceptionContinueSearch`。<br>
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Similar to above, this corresponds to the `eh_catch_typeinfo` lang item that's only used on Emscripten currently. <br>与上面类似，这对应于当前仅在 Emscripten 上使用的 `eh_catch_typeinfo` lang 项。<br>
    //
    // Since panics don't generate exceptions and foreign exceptions are currently UB with -C panic=abort (although this may be subject to change), any catch_unwind calls will never use this typeinfo. <br>由于 panics 不会生成异常，并且外部异常当前是 -C panic = 终止的 UB (尽管可能会更改)，所以任何 catch_unwind 调用将永远不会使用此 typeinfo。<br>
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // These two are called by our startup objects on i686-pc-windows-gnu, but they don't need to do anything so the bodies are nops. <br>我们的启动对象在 i686-pc-windows-gnu 上调用了这两个对象，但是它们不需要执行任何操作，因此它们的主体是点头的。<br>
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}
